# Initialize


```R
# Change directory to where the files are

HMR_DIR=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/
METH_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/
BW_DIR=${METH_DIR}bigWigs/
mkdir -p ${BW_DIR}
BG_DIR=${METH_DIR}bedGraphs/
mkdir -p ${BG_DIR}

HMR_COMB_DIR=${METH_DIR}HMR_Master/

CTCF_DIR=${METH_DIR}CTCF_Encode_V3/

MPD_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/

echo "Done"
```

    Done



```R
HMR_DIR=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/
METH_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/
HMR_COMB_DIR=${METH_DIR}HMR_Master/
mkdir -p ${HMR_COMB_DIR}

ADR_FILE=${HMR_DIR}Adrenal.minsize50.filtforrefseqTSSexons.txt
BCL_FILE=${HMR_DIR}Bcell.minsize50.filtforrefseqTSSexons.txt
fHT_FILE=${HMR_DIR}fHeart.minsize50.filtforrefseqTSSexons.txt
fSP_FILE=${HMR_DIR}fSpinal.minsize50.filtforrefseqTSSexons.txt
ESC_FILE=${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt
HSC_FILE=${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt
LIV_FILE=${HMR_DIR}Liver.minsize50.filtforrefseqTSSexons.txt
MAC_FILE=${HMR_DIR}Macrophage.minsize50.filtforrefseqTSSexons.txt
NEUT_FILE=${HMR_DIR}Neutrophil.minsize50.filtforrefseqTSSexons.txt
TCL_FILE=${HMR_DIR}Tcell.minsize50.filtforrefseqTSSexons.txt

echo "Initialized."
```

    Initialized.


## Download


```R
cd $BW_DIR

# Download
wget http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_Neut/tracks_hg19/Human_Neut.meth.bw




cd $BW_DIR

# Download
wget http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_Neut/tracks_hg19/Human_Neut.read.bw
```

    --2023-07-14 17:33:33--  http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_Neut/tracks_hg19/Human_Neut.meth.bw
    Resolving smithdata.usc.edu (smithdata.usc.edu)... 68.181.32.56
    Connecting to smithdata.usc.edu (smithdata.usc.edu)|68.181.32.56|:80... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 605565860 (578M)
    Saving to: ‘Human_Neut.meth.bw’
    
    100%[======================================>] 605,565,860  684KB/s   in 19m 18s
    
    2023-07-14 17:52:55 (511 KB/s) - ‘Human_Neut.meth.bw’ saved [605565860/605565860]
    
    --2023-07-14 17:52:55--  http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_Neut/tracks_hg19/Human_Neut.read.bw
    Resolving smithdata.usc.edu (smithdata.usc.edu)... 68.181.32.56
    Connecting to smithdata.usc.edu (smithdata.usc.edu)|68.181.32.56|:80... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 605565860 (578M)
    Saving to: ‘Human_Neut.read.bw’
    
    100%[======================================>] 605,565,860  441KB/s   in 19m 18s
    
    2023-07-14 18:12:16 (511 KB/s) - ‘Human_Neut.read.bw’ saved [605565860/605565860]
    



```R
cd $BW_DIR

# Download
# H1ESC
wget http://smithdata.usc.edu/methbase/data/Lister-ESC-2009/Human_H1ESC/tracks_hg19/Human_H1ESC.meth.bw
# fHeart
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Fetal-Heart/tracks_hg19/Human_Fetal-Heart.meth.bw
echo "Downloaded 2."
# fSpinal
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Fetal-Spinal-Cord/tracks_hg19/Human_Fetal-Spinal-Cord.meth.bw
# Liver
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Liver/tracks_hg19/Human_Liver.meth.bw
# Adrenal
echo "Downloaded 4."
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Adrenal-gland/tracks_hg19/Human_Adrenal-gland.meth.bw
# B cell
wget http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_BCell/tracks_hg19/Human_BCell.meth.bw
# T cell
echo "Downloaded 6."
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Tcell/tracks_hg19/Human_Tcell.meth.bw
# HSPC
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_HSC/tracks_hg19/Human_HSC.meth.bw
# Macrophage
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Macrophage/tracks_hg19/Human_Macrophage.meth.bw
echo "Done."




cd $BW_DIR

# Download
# H1ESC
wget http://smithdata.usc.edu/methbase/data/Lister-ESC-2009/Human_H1ESC/tracks_hg19/Human_H1ESC.read.bw
# fHeart
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Fetal-Heart/tracks_hg19/Human_Fetal-Heart.read.bw
echo "Downloaded 2."
# fSpinal
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Fetal-Spinal-Cord/tracks_hg19/Human_Fetal-Spinal-Cord.read.bw
# Liver
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Liver/tracks_hg19/Human_Liver.read.bw
# Adrenal
echo "Downloaded 4."
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Adrenal-gland/tracks_hg19/Human_Adrenal-gland.read.bw
# B cell
wget http://smithdata.usc.edu/methbase/data/Hodges-Human-2011/Human_BCell/tracks_hg19/Human_BCell.read.bw
# T cell
echo "Downloaded 6."
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Tcell/tracks_hg19/Human_Tcell.read.bw
# HSPC
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_HSC/tracks_hg19/Human_HSC.read.bw
# Macrophage
wget http://smithdata.usc.edu/methbase/data/Roadmap-Human-2015/Human_Macrophage/tracks_hg19/Human_Macrophage.read.bw
echo "Done."

```


```R
cd $BW_DIR
wget http://hgdownload.soe.ucsc.edu/admin/exe/linux.x86_64/bigWigToBedGraph
chmod +x ./bigWigToBedGraph
```

    --2023-07-14 18:12:19--  http://hgdownload.soe.ucsc.edu/admin/exe/linux.x86_64/bigWigToBedGraph
    Resolving hgdownload.soe.ucsc.edu (hgdownload.soe.ucsc.edu)... 128.114.119.163
    Connecting to hgdownload.soe.ucsc.edu (hgdownload.soe.ucsc.edu)|128.114.119.163|:80... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 5600072 (5.3M)
    Saving to: ‘bigWigToBedGraph.1’
    
    100%[======================================>] 5,600,072   8.08MB/s   in 0.7s   
    
    2023-07-14 18:12:20 (8.08 MB/s) - ‘bigWigToBedGraph.1’ saved [5600072/5600072]
    



```R
echo "Starting."
./bigWigToBedGraph Human_Neut.meth.bw Human_Neut.meth.bedGraph
echo "Done."

./bigWigToBedGraph Human_Neut.read.bw Human_Neut.read.bedGraph
echo "Done."
```

    Starting.
    Done.
    Done.



```R
# Check for same length
echo "Starting."
wc -l ${BW_DIR}Human_Neut.meth.bedGraph 
echo "Done counting."
wc -l ${BW_DIR}Human_Neut.read.bedGraph
echo "Done counting."
```

    Starting.
    28299638 /data/hodges_lab/Tim/MethylationHeatmap_paper/bigWigs/Human_Neut.meth.bedGraph
    Done counting.
    28299638 /data/hodges_lab/Tim/MethylationHeatmap_paper/bigWigs/Human_Neut.read.bedGraph
    Done counting.


# Make a master HMR file 


```R
echo "Started."

cat ${ESC_FILE} ${fHT_FILE} ${fSP_FILE} ${ADR_FILE} ${LIV_FILE} ${HSC_FILE}  ${MAC_FILE} ${NEUT_FILE} ${TCL_FILE} ${BCL_FILE}  | bedtools sort -i - | bedtools merge -i - > ${HMR_COMB_DIR}master_hmr_file_10ct.txt

echo "Ended."
```

    Started.
    Ended.


## Find # HMRs and average length


```R
wc -l ${HMR_COMB_DIR}master_hmr_file_10ct.txt
```

    126104 /data/hodges_lab/Tim/MethylationHeatmap_paper/HMR_Master/master_hmr_file_10ct.txt



```R
wc -l ${HMR_COMB_DIR}master_hmr_file_9ct.txt
```

    121885 /data/hodges_lab/Tim/MethylationHeatmap_paper/HMR_Master/master_hmr_file_9ct.txt



```R
# Total length of HMRs, Avg length of HMRs
awk 'BEGIN{OFS=FS="\t";sumval=0}{sumval = (sumval + ($3-$2))}END{print sumval,(sumval/NR)}' ${HMR_COMB_DIR}master_hmr_file_10ct.txt 
```

    109203735	865.982



```R
awk 'BEGIN{OFS=FS="\t";sumval=0}{sumval = (sumval + ($3-$2))}END{print sumval,(sumval/NR)}' ${HMR_COMB_DIR}master_hmr_file_9ct.txt 
```

    105680885	867.054


# Map methylation per cell type 


```R
MASTER_HMR_FILE=${HMR_COMB_DIR}master_hmr_file_10ct.txt
BG_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/bigWigs/
MPD_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/
mkdir -p ${MPD_DIR}

# (2) Map each celltype to this master file from (1)
for CELLTYPE in Human_H1ESC Human_Fetal-Heart Human_Fetal-Spinal-Cord Human_Adrenal-gland Human_Liver Human_HSC Human_Macrophage Human_Neut Human_BCell Human_Tcell 
do
echo "Processing: " ${CELLTYPE} 
bedtools map -a ${MASTER_HMR_FILE} -b ${BG_DIR}${CELLTYPE}.meth.bedGraph -c 4 -o mean > ${MPD_DIR}master_HMRs.noCTCFfilter.${CELLTYPE}.meanMeth.10ct.txt
echo "Done with: " ${CELLTYPE} 
done

echo "Done."

```

    Processing:  Human_H1ESC
    Done with:  Human_H1ESC
    Processing:  Human_Fetal-Heart
    Done with:  Human_Fetal-Heart
    Processing:  Human_Fetal-Spinal-Cord
    Done with:  Human_Fetal-Spinal-Cord
    Processing:  Human_Adrenal-gland
    Done with:  Human_Adrenal-gland
    Processing:  Human_Liver
    Done with:  Human_Liver
    Processing:  Human_HSC
    Done with:  Human_HSC
    Processing:  Human_Macrophage
    Done with:  Human_Macrophage
    Processing:  Human_Neut
    Done with:  Human_Neut
    Processing:  Human_BCell
    Done with:  Human_BCell
    Processing:  Human_Tcell
    Done with:  Human_Tcell
    Done.


# Merge 


```R
# Isolate
for CELLTYPE in Human_H1ESC Human_Fetal-Heart Human_Fetal-Spinal-Cord Human_Adrenal-gland Human_Liver Human_HSC Human_Macrophage Human_Neut Human_BCell Human_Tcell
do
awk '{print $4}' ${MPD_DIR}master_HMRs.noCTCFfilter.${CELLTYPE}.meanMeth.10ct.txt > ${MPD_DIR}master_HMRs.noCTCFfilter.${CELLTYPE}.meanMeth.10ct.ValueColOnly.txt
done

echo "Done."

# Combine
paste ${MPD_DIR}master_HMRs.noCTCFfilter.Human_H1ESC.meanMeth.10ct.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Fetal-Spinal-Cord.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Fetal-Heart.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Adrenal-gland.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Liver.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_HSC.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Macrophage.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Neut.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_Tcell.meanMeth.10ct.ValueColOnly.txt \
${MPD_DIR}master_HMRs.noCTCFfilter.Human_BCell.meanMeth.10ct.ValueColOnly.txt \
> ${MPD_DIR}masterHMRs_methMatrix.noCTCFfilter.10ct.txt

echo "Done."

# Clean
# (4) Also, create a numerical matrix version
awk 'BEGIN{OFS=FS="\t"}{print $4,$5,$6,$7,$8,$9,$10,$11,$12,$13}' ${MPD_DIR}masterHMRs_methMatrix.noCTCFfilter.10ct.txt > ${MPD_DIR}masterHMRs_methMatrix.noCTCFfilter.10ct.numerical.txt

head  ${MPD_DIR}masterHMRs_methMatrix.noCTCFfilter.10ct.txt

echo "Done."
```

    Done.
    Done.
    chr1	20043	20480	0	0.3986132222	0.758924	0	0	0.8683217778	0.8967626667	0	0.8804616667	0
    chr1	28432	30155	0	0.0003370410853	0.001232707752	0	0.007751937984	0.0079365	0.002717391304	0.006459945736	0.01086956522	0.007751937984
    chr1	51441	51734	0.4309162778	0.8629746111	0.9130141111	0.6243886111	0.1238756111	0.7918531111	0.8466523889	0.9675926111	0.8787037222	0.4907407778
    chr1	91118	91684	0.30741762	0.23571346	0.24045331	0.16995105	0.0333333	0.13726615	0.27230077	0.2233333	0.2252412	0.2166667
    chr1	96558	96806	0.6666666667	0.6592395	0.4992063333	0.2916666667	0	0.84375	0	0	0.6732621667	0.3333333333
    chr1	137353	137404	0	0.9381945	0	0	0	0.9583333333	0.861111	0	0.9391535	0
    chr1	235927	237877	0.2303665	0.3951615769	0.4366992731	0.2813650385	0.2827484269	0.6262035526	0.5063650167	0.1336004231	0.6000363947	0.1332417308
    chr1	241322	243648	0.1899192941	0.3622291765	0.31507	0.2271455294	0.1880142353	0.9375	0.1525632727	0.1448178824	0.5542327778	0.1738905882
    chr1	250304	250571	0.7246156	0.8092892	0.7738602	0.7713828	0.627394	0.8387412	0.1794516	0.175	0.6795918	0.5373738
    chr1	435874	436666	0	0	0	0	0	0.2	.	0	.	0
    Done.


# R 

## Load libraries


```R
library(tidyverse)
library(ggplot2)
library(RColorBrewer)
library(pheatmap)
library(cluster)
library("corrplot")

print("Libraries loaded.")
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    
    corrplot 0.92 loaded
    


    [1] "Libraries loaded."



```R
sessionInfo()
```


    R version 4.1.2 (2021-11-01)
    Platform: x86_64-conda-linux-gnu (64-bit)
    Running under: CentOS Linux 7 (Core)
    
    Matrix products: default
    BLAS/LAPACK: /gpfs52/data/hodges_lab/Tim/.conda/envs/jupyter/lib/libopenblasp-r0.3.18.so
    
    locale:
     [1] LC_CTYPE=en_US.UTF-8       LC_NUMERIC=C              
     [3] LC_TIME=en_US.UTF-8        LC_COLLATE=en_US.UTF-8    
     [5] LC_MONETARY=en_US.UTF-8    LC_MESSAGES=en_US.UTF-8   
     [7] LC_PAPER=en_US.UTF-8       LC_NAME=C                 
     [9] LC_ADDRESS=C               LC_TELEPHONE=C            
    [11] LC_MEASUREMENT=en_US.UTF-8 LC_IDENTIFICATION=C       
    
    attached base packages:
    [1] stats     graphics  grDevices utils     datasets  methods   base     
    
    other attached packages:
     [1] corrplot_0.92      cluster_2.1.2      pheatmap_1.0.12    RColorBrewer_1.1-3
     [5] forcats_0.5.1      stringr_1.5.0      dplyr_1.1.1        purrr_1.0.1       
     [9] readr_2.1.2        tidyr_1.3.0        tibble_3.2.1       ggplot2_3.3.6     
    [13] tidyverse_1.3.1   
    
    loaded via a namespace (and not attached):
     [1] pbdZMQ_0.3-7     tidyselect_1.2.0 repr_1.1.4       haven_2.4.3     
     [5] colorspace_2.1-0 vctrs_0.6.1      generics_0.1.3   htmltools_0.5.5 
     [9] base64enc_0.1-3  utf8_1.2.3       rlang_1.1.0      pillar_1.9.0    
    [13] glue_1.6.2       withr_2.5.0      DBI_1.1.3        dbplyr_2.3.2    
    [17] modelr_0.1.8     readxl_1.3.1     uuid_1.0-4       lifecycle_1.0.3 
    [21] munsell_0.5.0    gtable_0.3.0     cellranger_1.1.0 rvest_1.0.2     
    [25] evaluate_0.20    tzdb_0.2.0       fastmap_1.1.1    fansi_1.0.4     
    [29] broom_0.7.12     IRdisplay_1.1    Rcpp_1.0.10      backports_1.4.1 
    [33] scales_1.2.0     IRkernel_1.3     jsonlite_1.8.4   fs_1.6.1        
    [37] hms_1.1.3        digest_0.6.31    stringi_1.7.6    grid_4.1.2      
    [41] cli_3.6.1        tools_4.1.2      magrittr_2.0.3   crayon_1.5.2    
    [45] pkgconfig_2.0.3  xml2_1.3.3       reprex_2.0.1     lubridate_1.8.0 
    [49] rstudioapi_0.13  httr_1.4.5       R6_2.5.1         compiler_4.1.2  



```R
R.version
```


                   _                           
    platform       x86_64-conda-linux-gnu      
    arch           x86_64                      
    os             linux-gnu                   
    system         x86_64, linux-gnu           
    status                                     
    major          4                           
    minor          1.2                         
    year           2021                        
    month          11                          
    day            01                          
    svn rev        81115                       
    language       R                           
    version.string R version 4.1.2 (2021-11-01)
    nickname       Bird Hippie                 


## Load files


```R
setwd("/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/")

# Load in all files - raw Methylation
# no CTCF filter
methMatrix_noCTCFFilt_10ct_in <- read_tsv("masterHMRs_methMatrix.noCTCFfilter.10ct.numerical.txt", col_names=F)
colnames(methMatrix_noCTCFFilt_10ct_in) <- c("H1ESC","fSpinal","fHeart","Adrenal","Liver","HSPC","Macrophage","Neutrophil","Tcell","Bcell")

# Remove NA 
methMatrix_noCTCFFilt_10ct_in[ methMatrix_noCTCFFilt_10ct_in == "." ] <- NA
methMatrix_noCTCFFilt_10ct_NoNA <- na.omit(methMatrix_noCTCFFilt_10ct_in)
methMatrix_noCTCFFilt_10ct_NoNA_datmat <- data.matrix(methMatrix_noCTCFFilt_10ct_NoNA)
methMatrix_noCTCFFilt_10ct_NoNA_mat <- as.matrix(methMatrix_noCTCFFilt_10ct_NoNA)
methMatrix_noCTCFFilt_10ct_NoNA_nummat<- matrix(as.numeric(methMatrix_noCTCFFilt_10ct_NoNA_mat),    # Convert to numeric matrix
                                              ncol = ncol(methMatrix_noCTCFFilt_10ct_NoNA_mat))
colnames(methMatrix_noCTCFFilt_10ct_NoNA_nummat) <- c("H1ESC","fSpinal","fHeart","Adrenal","Liver","HSPC","Macrophage","Neutrophil","Tcell","Bcell")
```

    Warning message:
    “One or more parsing issues, see `problems()` for details”
    [1mRows: [22m[34m126104[39m [1mColumns: [22m[34m10[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (3): X6, X7, X9
    [32mdbl[39m (7): X1, X2, X3, X4, X5, X8, X10
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
methMatrix_noCTCFFilt_10ct_NoNA
```


<table class="dataframe">
<caption>A tibble: 123992 × 10</caption>
<thead>
	<tr><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>0.00000000</td><td>0.3986132222</td><td>0.758924000</td><td>0.00000000</td><td>0.000000000</td><td>0.8683217778 </td><td>0.8967626667  </td><td>0.000000000</td><td>0.8804616667 </td><td>0.000000000</td></tr>
	<tr><td>0.00000000</td><td>0.0003370411</td><td>0.001232708</td><td>0.00000000</td><td>0.007751938</td><td>0.0079365    </td><td>0.002717391304</td><td>0.006459946</td><td>0.01086956522</td><td>0.007751938</td></tr>
	<tr><td>0.43091628</td><td>0.8629746111</td><td>0.913014111</td><td>0.62438861</td><td>0.123875611</td><td>0.7918531111 </td><td>0.8466523889  </td><td>0.967592611</td><td>0.8787037222 </td><td>0.490740778</td></tr>
	<tr><td>0.30741762</td><td>0.2357134600</td><td>0.240453310</td><td>0.16995105</td><td>0.033333300</td><td>0.13726615   </td><td>0.27230077    </td><td>0.223333300</td><td>0.2252412    </td><td>0.216666700</td></tr>
	<tr><td>0.66666667</td><td>0.6592395000</td><td>0.499206333</td><td>0.29166667</td><td>0.000000000</td><td>0.84375      </td><td>0             </td><td>0.000000000</td><td>0.6732621667 </td><td>0.333333333</td></tr>
	<tr><td>0.00000000</td><td>0.9381945000</td><td>0.000000000</td><td>0.00000000</td><td>0.000000000</td><td>0.9583333333 </td><td>0.861111      </td><td>0.000000000</td><td>0.9391535    </td><td>0.000000000</td></tr>
	<tr><td>0.23036650</td><td>0.3951615769</td><td>0.436699273</td><td>0.28136504</td><td>0.282748427</td><td>0.6262035526 </td><td>0.5063650167  </td><td>0.133600423</td><td>0.6000363947 </td><td>0.133241731</td></tr>
	<tr><td>0.18991929</td><td>0.3622291765</td><td>0.315070000</td><td>0.22714553</td><td>0.188014235</td><td>0.9375       </td><td>0.1525632727  </td><td>0.144817882</td><td>0.5542327778 </td><td>0.173890588</td></tr>
	<tr><td>0.72461560</td><td>0.8092892000</td><td>0.773860200</td><td>0.77138280</td><td>0.627394000</td><td>0.8387412    </td><td>0.1794516     </td><td>0.175000000</td><td>0.6795918    </td><td>0.537373800</td></tr>
	<tr><td>0.37597402</td><td>0.1838144500</td><td>0.603043000</td><td>0.57478502</td><td>0.432629625</td><td>0.3678942    </td><td>0.174779059   </td><td>0.286029378</td><td>0.2904716675 </td><td>0.337126433</td></tr>
	<tr><td>0.29549088</td><td>0.0000000000</td><td>0.745465925</td><td>0.35009389</td><td>0.606469984</td><td>0.6221358217 </td><td>0.8739610189  </td><td>0.664041536</td><td>0.8481670755 </td><td>0.179240587</td></tr>
	<tr><td>0.08460062</td><td>0.1738681147</td><td>0.129984953</td><td>0.05739979</td><td>0.044418328</td><td>0.1293946612 </td><td>0.1105308954  </td><td>0.059861478</td><td>0.1336111918 </td><td>0.073010111</td></tr>
	<tr><td>0.41025223</td><td>0.9385339231</td><td>0.939444077</td><td>0.54800908</td><td>0.946896308</td><td>0.9653136923 </td><td>0.9744446923  </td><td>0.359850923</td><td>0.9632615385 </td><td>0.249991731</td></tr>
	<tr><td>0.49548768</td><td>0.4191103947</td><td>0.617378776</td><td>0.17200885</td><td>0.406927687</td><td>0.7104560811 </td><td>0.4736291389  </td><td>0.312558397</td><td>0.7172746757 </td><td>0.481333526</td></tr>
	<tr><td>0.70039683</td><td>0.6877705000</td><td>0.616588833</td><td>0.50567300</td><td>0.513007767</td><td>0.7843093333 </td><td>0.572033      </td><td>0.159722167</td><td>0.6504546    </td><td>0.653295167</td></tr>
	<tr><td>0.05630877</td><td>0.0422033456</td><td>0.043238607</td><td>0.04163275</td><td>0.038514660</td><td>0.06905170758</td><td>0.06495400832 </td><td>0.050431597</td><td>0.06848919286</td><td>0.075417018</td></tr>
	<tr><td>0.41842108</td><td>0.7901013846</td><td>0.677402154</td><td>0.39749331</td><td>0.450417462</td><td>0.8116758462 </td><td>0.8875708462  </td><td>0.281196692</td><td>0.2197826154 </td><td>0.384615385</td></tr>
	<tr><td>0.73634750</td><td>0.6419902500</td><td>0.594424000</td><td>0.72344000</td><td>0.782415000</td><td>0.696659025  </td><td>0.48733       </td><td>0.641761500</td><td>0.1055834375 </td><td>0.591949000</td></tr>
	<tr><td>0.74513894</td><td>0.8325073125</td><td>0.905609563</td><td>0.76977138</td><td>0.750800438</td><td>0.8765721875 </td><td>0.3599040437  </td><td>0.759180437</td><td>0.8860234375 </td><td>0.789045312</td></tr>
	<tr><td>0.71824983</td><td>0.6663691667</td><td>0.539856833</td><td>0.59493033</td><td>0.729730833</td><td>0.3479406167 </td><td>0.1348325167  </td><td>0.211454500</td><td>0.5473678333 </td><td>0.414141333</td></tr>
	<tr><td>0.63311540</td><td>0.4408846100</td><td>0.370146303</td><td>0.24084614</td><td>0.280130130</td><td>0.2581309133 </td><td>0.2367806133  </td><td>0.148340277</td><td>0.2580932867 </td><td>0.220868420</td></tr>
	<tr><td>0.81344136</td><td>0.6741617273</td><td>0.790760454</td><td>0.46009473</td><td>0.553324909</td><td>0.2147925364 </td><td>0.3284043545  </td><td>0.215678082</td><td>0.624842     </td><td>0.413851500</td></tr>
	<tr><td>0.77084206</td><td>0.6525558188</td><td>0.320512562</td><td>0.71665419</td><td>0.743482125</td><td>0.9205804375 </td><td>0.9317095625  </td><td>0.917785312</td><td>0.816237125  </td><td>0.424811819</td></tr>
	<tr><td>0.26786610</td><td>0.1735855410</td><td>0.190666056</td><td>0.23775954</td><td>0.190173884</td><td>0.2523955176 </td><td>0.1416534643  </td><td>0.165553703</td><td>0.2795565838 </td><td>0.260236800</td></tr>
	<tr><td>0.52451921</td><td>0.3533441250</td><td>0.299392500</td><td>0.52793267</td><td>0.643046900</td><td>0.8023708333 </td><td>0.86945       </td><td>0.702309692</td><td>0.7486093333 </td><td>0.714667333</td></tr>
	<tr><td>0.74031586</td><td>0.7195342857</td><td>0.745302429</td><td>0.48809014</td><td>0.585794429</td><td>0.2449171    </td><td>0.2508511     </td><td>0.273671929</td><td>0.3617694286 </td><td>0.272097586</td></tr>
	<tr><td>0.83288009</td><td>0.5023639545</td><td>0.711337045</td><td>0.55414595</td><td>0.681442955</td><td>0.1868961955 </td><td>0.1755481227  </td><td>0.206087368</td><td>0.4228495818 </td><td>0.213271573</td></tr>
	<tr><td>0.67677459</td><td>0.8467650270</td><td>0.866379622</td><td>0.75269762</td><td>0.752095270</td><td>0.5386379919 </td><td>0.4633221432  </td><td>0.404454097</td><td>0.5058361568 </td><td>0.160166454</td></tr>
	<tr><td>0.24550987</td><td>0.1703019580</td><td>0.195675906</td><td>0.14910089</td><td>0.181464401</td><td>0.1294420751 </td><td>0.1005630412  </td><td>0.087196896</td><td>0.1766952026 </td><td>0.109505507</td></tr>
	<tr><td>0.62214844</td><td>0.1655110925</td><td>0.270567476</td><td>0.17323645</td><td>0.335840014</td><td>0.3702744425 </td><td>0.2727530962  </td><td>0.296061607</td><td>0.2596652047 </td><td>0.323363660</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>0.7040317</td><td>0.00000000</td><td>0.61611685</td><td>0.61128174</td><td>0.6116899</td><td>0.5405405405</td><td>0.7043768865</td><td>0.08832764</td><td>0.7110297347</td><td>0.13748153</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.51378127</td><td>0.09871982</td><td>0.4245165</td><td>0.8         </td><td>0.6460839091</td><td>0.00000000</td><td>0.639552    </td><td>0.00000000</td></tr>
	<tr><td>0.2617558</td><td>0.00000000</td><td>0.57997297</td><td>0.30626524</td><td>0.6643658</td><td>0.8571428571</td><td>0.7263844848</td><td>0.03535355</td><td>0.7335832727</td><td>0.03254679</td></tr>
	<tr><td>0.2837900</td><td>0.00000000</td><td>0.64958213</td><td>0.28278905</td><td>0.5777168</td><td>0.75        </td><td>0.7366730556</td><td>0.01906319</td><td>0.7472522778</td><td>0.07263242</td></tr>
	<tr><td>0.4950250</td><td>0.00000000</td><td>0.69687665</td><td>0.44390002</td><td>0.6863997</td><td>0.5         </td><td>0.7516725918</td><td>0.00000000</td><td>0.7944938571</td><td>0.10897437</td></tr>
	<tr><td>0.2065973</td><td>0.00000000</td><td>0.77888675</td><td>0.29840425</td><td>0.7292315</td><td>0           </td><td>0.8446855   </td><td>0.00000000</td><td>0.882609375 </td><td>0.00000000</td></tr>
	<tr><td>0.3269063</td><td>0.00000000</td><td>0.57920409</td><td>0.31713825</td><td>0.5827726</td><td>0.5         </td><td>0.7724402187</td><td>0.00000000</td><td>0.7422971875</td><td>0.03501984</td></tr>
	<tr><td>0.5055407</td><td>0.00000000</td><td>0.61104343</td><td>0.50265700</td><td>0.6239507</td><td>0           </td><td>0.6989298571</td><td>0.14285714</td><td>0.684336    </td><td>0.11190471</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.51131100</td><td>0.00000000</td><td>0.3163727</td><td>0.5         </td><td>0.6129067375</td><td>0.00000000</td><td>0.639508975 </td><td>0.00000000</td></tr>
	<tr><td>0.4975848</td><td>0.00000000</td><td>0.69424251</td><td>0.28469744</td><td>0.5310800</td><td>0.875       </td><td>0.7183297467</td><td>0.05555556</td><td>0.7239896944</td><td>0.09239807</td></tr>
	<tr><td>0.5355928</td><td>0.00000000</td><td>0.71423697</td><td>0.49665079</td><td>0.6369508</td><td>0.75        </td><td>0.7585433793</td><td>0.05172414</td><td>0.7743936897</td><td>0.17676517</td></tr>
	<tr><td>0.2045451</td><td>0.00000000</td><td>0.64852279</td><td>0.18312521</td><td>0.6318099</td><td>0.7777778333</td><td>0.6917824872</td><td>0.00000000</td><td>0.7732882821</td><td>0.05982905</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.71403020</td><td>0.00000000</td><td>0.6666668</td><td>0.2         </td><td>0.789275    </td><td>0.00000000</td><td>0.7697606   </td><td>0.00000000</td></tr>
	<tr><td>0.6075117</td><td>0.36926143</td><td>0.37632167</td><td>0.32992650</td><td>0.3412617</td><td>0.4016652222</td><td>0.4421813333</td><td>0.43937739</td><td>0.4260899722</td><td>0.42498928</td></tr>
	<tr><td>0.6582970</td><td>0.38689352</td><td>0.58008056</td><td>0.56120216</td><td>0.5681711</td><td>0.6572106522</td><td>0.65072276  </td><td>0.51351148</td><td>0.60463292  </td><td>0.50025144</td></tr>
	<tr><td>0.4618227</td><td>0.31316854</td><td>0.38669885</td><td>0.35097478</td><td>0.3797715</td><td>0.484569129 </td><td>0.4840944429</td><td>0.33727042</td><td>0.44638858  </td><td>0.33132444</td></tr>
	<tr><td>0.3029321</td><td>0.15640489</td><td>0.24275352</td><td>0.27330013</td><td>0.2886529</td><td>0.365929    </td><td>0.3261977889</td><td>0.26287741</td><td>0.340142775 </td><td>0.28638547</td></tr>
	<tr><td>0.5362513</td><td>0.42118856</td><td>0.41734111</td><td>0.31944557</td><td>0.3827468</td><td>0.5360422489</td><td>0.4594229444</td><td>0.39448089</td><td>0.4177737111</td><td>0.38845878</td></tr>
	<tr><td>0.3948686</td><td>0.61675425</td><td>0.62448014</td><td>0.38585182</td><td>0.5339708</td><td>0.516896975 </td><td>0.612497125 </td><td>0.19050709</td><td>0.62181725  </td><td>0.19466644</td></tr>
	<tr><td>0.5864938</td><td>0.38876333</td><td>0.45444917</td><td>0.37124632</td><td>0.3710083</td><td>0.4004435858</td><td>0.5084571667</td><td>0.35846272</td><td>0.5087278333</td><td>0.40013417</td></tr>
	<tr><td>0.6277619</td><td>0.44495500</td><td>0.47721244</td><td>0.38642681</td><td>0.3625473</td><td>0.5163198667</td><td>0.5301443   </td><td>0.49006903</td><td>0.5395405222</td><td>0.44335612</td></tr>
	<tr><td>0.6418516</td><td>0.41301489</td><td>0.42571444</td><td>0.36778164</td><td>0.3448534</td><td>0.4659447778</td><td>0.5041747222</td><td>0.51723289</td><td>0.5074499444</td><td>0.43628872</td></tr>
	<tr><td>0.6148867</td><td>0.40645943</td><td>0.42828438</td><td>0.41960972</td><td>0.3951311</td><td>0.5232651321</td><td>0.5442367283</td><td>0.53950653</td><td>0.4946689057</td><td>0.49108202</td></tr>
	<tr><td>0.6482021</td><td>0.41809411</td><td>0.42294166</td><td>0.38842221</td><td>0.3816551</td><td>0.4342907528</td><td>0.5123094444</td><td>0.49753300</td><td>0.4583173361</td><td>0.45147714</td></tr>
	<tr><td>0.5114616</td><td>0.37165036</td><td>0.42042793</td><td>0.34020050</td><td>0.3497128</td><td>0.4424378571</td><td>0.5327088571</td><td>0.50456129</td><td>0.521543    </td><td>0.46513171</td></tr>
	<tr><td>0.6290742</td><td>0.41451610</td><td>0.42311657</td><td>0.38658858</td><td>0.3519685</td><td>0.4437201743</td><td>0.521352587 </td><td>0.46236409</td><td>0.4716031043</td><td>0.45781887</td></tr>
	<tr><td>0.6466637</td><td>0.39776091</td><td>0.44410400</td><td>0.37787075</td><td>0.3818560</td><td>0.4463593067</td><td>0.5610116161</td><td>0.46019416</td><td>0.4790198226</td><td>0.45677087</td></tr>
	<tr><td>0.5777289</td><td>0.55375313</td><td>0.55455107</td><td>0.47728773</td><td>0.4377265</td><td>0.4935677333</td><td>0.6361981333</td><td>0.50531607</td><td>0.6328638667</td><td>0.49314887</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.07142857</td><td>0.00000000</td><td>0.0000000</td><td>1           </td><td>0.5         </td><td>0.00000000</td><td>0.3333333333</td><td>0.00000000</td></tr>
	<tr><td>0.0000000</td><td>0.07142857</td><td>0.10714286</td><td>0.00000000</td><td>0.2500000</td><td>0.5714285714</td><td>0           </td><td>0.00000000</td><td>0.75        </td><td>0.00000000</td></tr>
</tbody>
</table>




```R
methMatrix_noCTCFFilt_10ct_NoNA_mat
```


<table class="dataframe">
<caption>A matrix: 123992 × 10 of type chr</caption>
<thead>
	<tr><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th></tr>
</thead>
<tbody>
	<tr><td>0.0000000000</td><td>0.3986132222</td><td>0.7589240000</td><td>0.0000000000</td><td>0.0000000000</td><td>0.8683217778 </td><td>0.8967626667  </td><td>0.0000000000</td><td>0.8804616667 </td><td>0.0000000000</td></tr>
	<tr><td>0.0000000000</td><td>0.0003370411</td><td>0.0012327078</td><td>0.0000000000</td><td>0.0077519380</td><td>0.0079365    </td><td>0.002717391304</td><td>0.0064599457</td><td>0.01086956522</td><td>0.0077519380</td></tr>
	<tr><td>0.4309162778</td><td>0.8629746111</td><td>0.9130141111</td><td>0.6243886111</td><td>0.1238756111</td><td>0.7918531111 </td><td>0.8466523889  </td><td>0.9675926111</td><td>0.8787037222 </td><td>0.4907407778</td></tr>
	<tr><td>0.3074176200</td><td>0.2357134600</td><td>0.2404533100</td><td>0.1699510500</td><td>0.0333333000</td><td>0.13726615   </td><td>0.27230077    </td><td>0.2233333000</td><td>0.2252412    </td><td>0.2166667000</td></tr>
	<tr><td>0.6666666667</td><td>0.6592395000</td><td>0.4992063333</td><td>0.2916666667</td><td>0.0000000000</td><td>0.84375      </td><td>0             </td><td>0.0000000000</td><td>0.6732621667 </td><td>0.3333333333</td></tr>
	<tr><td>0.0000000000</td><td>0.9381945000</td><td>0.0000000000</td><td>0.0000000000</td><td>0.0000000000</td><td>0.9583333333 </td><td>0.861111      </td><td>0.0000000000</td><td>0.9391535    </td><td>0.0000000000</td></tr>
	<tr><td>0.2303665000</td><td>0.3951615769</td><td>0.4366992731</td><td>0.2813650385</td><td>0.2827484269</td><td>0.6262035526 </td><td>0.5063650167  </td><td>0.1336004231</td><td>0.6000363947 </td><td>0.1332417308</td></tr>
	<tr><td>0.1899192941</td><td>0.3622291765</td><td>0.3150700000</td><td>0.2271455294</td><td>0.1880142353</td><td>0.9375       </td><td>0.1525632727  </td><td>0.1448178824</td><td>0.5542327778 </td><td>0.1738905882</td></tr>
	<tr><td>0.7246156000</td><td>0.8092892000</td><td>0.7738602000</td><td>0.7713828000</td><td>0.6273940000</td><td>0.8387412    </td><td>0.1794516     </td><td>0.1750000000</td><td>0.6795918    </td><td>0.5373738000</td></tr>
	<tr><td>0.3759740250</td><td>0.1838144500</td><td>0.6030430000</td><td>0.5747850250</td><td>0.4326296250</td><td>0.3678942    </td><td>0.174779059   </td><td>0.2860293775</td><td>0.2904716675 </td><td>0.3371264325</td></tr>
	<tr><td>0.2954908786</td><td>0.0000000000</td><td>0.7454659245</td><td>0.3500938950</td><td>0.6064699843</td><td>0.6221358217 </td><td>0.8739610189  </td><td>0.6640415365</td><td>0.8481670755 </td><td>0.1792405868</td></tr>
	<tr><td>0.0846006194</td><td>0.1738681147</td><td>0.1299849531</td><td>0.0573997929</td><td>0.0444183275</td><td>0.1293946612 </td><td>0.1105308954  </td><td>0.0598614776</td><td>0.1336111918 </td><td>0.0730101112</td></tr>
	<tr><td>0.4102522308</td><td>0.9385339231</td><td>0.9394440769</td><td>0.5480090769</td><td>0.9468963077</td><td>0.9653136923 </td><td>0.9744446923  </td><td>0.3598509231</td><td>0.9632615385 </td><td>0.2499917308</td></tr>
	<tr><td>0.4954876842</td><td>0.4191103947</td><td>0.6173787763</td><td>0.1720088500</td><td>0.4069276868</td><td>0.7104560811 </td><td>0.4736291389  </td><td>0.3125583974</td><td>0.7172746757 </td><td>0.4813335263</td></tr>
	<tr><td>0.7003968333</td><td>0.6877705000</td><td>0.6165888333</td><td>0.5056730000</td><td>0.5130077667</td><td>0.7843093333 </td><td>0.572033      </td><td>0.1597221667</td><td>0.6504546    </td><td>0.6532951667</td></tr>
	<tr><td>0.0563087671</td><td>0.0422033456</td><td>0.0432386067</td><td>0.0416327530</td><td>0.0385146597</td><td>0.06905170758</td><td>0.06495400832 </td><td>0.0504315966</td><td>0.06848919286</td><td>0.0754170181</td></tr>
	<tr><td>0.4184210769</td><td>0.7901013846</td><td>0.6774021538</td><td>0.3974933077</td><td>0.4504174615</td><td>0.8116758462 </td><td>0.8875708462  </td><td>0.2811966923</td><td>0.2197826154 </td><td>0.3846153846</td></tr>
	<tr><td>0.7363475000</td><td>0.6419902500</td><td>0.5944240000</td><td>0.7234400000</td><td>0.7824150000</td><td>0.696659025  </td><td>0.48733       </td><td>0.6417615000</td><td>0.1055834375 </td><td>0.5919490000</td></tr>
	<tr><td>0.7451389375</td><td>0.8325073125</td><td>0.9056095625</td><td>0.7697713750</td><td>0.7508004375</td><td>0.8765721875 </td><td>0.3599040437  </td><td>0.7591804375</td><td>0.8860234375 </td><td>0.7890453125</td></tr>
	<tr><td>0.7182498333</td><td>0.6663691667</td><td>0.5398568333</td><td>0.5949303333</td><td>0.7297308333</td><td>0.3479406167 </td><td>0.1348325167  </td><td>0.2114545000</td><td>0.5473678333 </td><td>0.4141413333</td></tr>
	<tr><td>0.6331154000</td><td>0.4408846100</td><td>0.3701463033</td><td>0.2408461437</td><td>0.2801301300</td><td>0.2581309133 </td><td>0.2367806133  </td><td>0.1483402767</td><td>0.2580932867 </td><td>0.2208684200</td></tr>
	<tr><td>0.8134413636</td><td>0.6741617273</td><td>0.7907604545</td><td>0.4600947273</td><td>0.5533249091</td><td>0.2147925364 </td><td>0.3284043545  </td><td>0.2156780818</td><td>0.624842     </td><td>0.4138515000</td></tr>
	<tr><td>0.7708420625</td><td>0.6525558188</td><td>0.3205125625</td><td>0.7166541875</td><td>0.7434821250</td><td>0.9205804375 </td><td>0.9317095625  </td><td>0.9177853125</td><td>0.816237125  </td><td>0.4248118188</td></tr>
	<tr><td>0.2678661044</td><td>0.1735855410</td><td>0.1906660559</td><td>0.2377595368</td><td>0.1901738838</td><td>0.2523955176 </td><td>0.1416534643  </td><td>0.1655537029</td><td>0.2795565838 </td><td>0.2602368000</td></tr>
	<tr><td>0.5245192083</td><td>0.3533441250</td><td>0.2993925000</td><td>0.5279326667</td><td>0.6430469000</td><td>0.8023708333 </td><td>0.86945       </td><td>0.7023096917</td><td>0.7486093333 </td><td>0.7146673333</td></tr>
	<tr><td>0.7403158571</td><td>0.7195342857</td><td>0.7453024286</td><td>0.4880901429</td><td>0.5857944286</td><td>0.2449171    </td><td>0.2508511     </td><td>0.2736719286</td><td>0.3617694286 </td><td>0.2720975857</td></tr>
	<tr><td>0.8328800909</td><td>0.5023639545</td><td>0.7113370455</td><td>0.5541459545</td><td>0.6814429545</td><td>0.1868961955 </td><td>0.1755481227  </td><td>0.2060873682</td><td>0.4228495818 </td><td>0.2132715727</td></tr>
	<tr><td>0.6767745946</td><td>0.8467650270</td><td>0.8663796216</td><td>0.7526976216</td><td>0.7520952703</td><td>0.5386379919 </td><td>0.4633221432  </td><td>0.4044540973</td><td>0.5058361568 </td><td>0.1601664541</td></tr>
	<tr><td>0.2455098705</td><td>0.1703019580</td><td>0.1956759057</td><td>0.1491008881</td><td>0.1814644010</td><td>0.1294420751 </td><td>0.1005630412  </td><td>0.0871968964</td><td>0.1766952026 </td><td>0.1095055067</td></tr>
	<tr><td>0.6221484434</td><td>0.1655110925</td><td>0.2705674764</td><td>0.1732364509</td><td>0.3358400142</td><td>0.3702744425 </td><td>0.2727530962  </td><td>0.2960616075</td><td>0.2596652047 </td><td>0.3233636604</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>0.7040316654</td><td>0.0000000000</td><td>0.6161168502</td><td>0.6112817364</td><td>0.6116898678</td><td>0.5405405405</td><td>0.7043768865</td><td>0.0883276429</td><td>0.7110297347</td><td>0.1374815328</td></tr>
	<tr><td>0.0000000000</td><td>0.0000000000</td><td>0.5137812727</td><td>0.0987198182</td><td>0.4245165455</td><td>0.8         </td><td>0.6460839091</td><td>0.0000000000</td><td>0.639552    </td><td>0.0000000000</td></tr>
	<tr><td>0.2617558485</td><td>0.0000000000</td><td>0.5799729667</td><td>0.3062652424</td><td>0.6643658485</td><td>0.8571428571</td><td>0.7263844848</td><td>0.0353535455</td><td>0.7335832727</td><td>0.0325467909</td></tr>
	<tr><td>0.2837899630</td><td>0.0000000000</td><td>0.6495821296</td><td>0.2827890463</td><td>0.5777168333</td><td>0.75        </td><td>0.7366730556</td><td>0.0190631852</td><td>0.7472522778</td><td>0.0726324185</td></tr>
	<tr><td>0.4950250000</td><td>0.0000000000</td><td>0.6968766538</td><td>0.4439000192</td><td>0.6863996923</td><td>0.5         </td><td>0.7516725918</td><td>0.0000000000</td><td>0.7944938571</td><td>0.1089743654</td></tr>
	<tr><td>0.2065972500</td><td>0.0000000000</td><td>0.7788867500</td><td>0.2984042500</td><td>0.7292315000</td><td>0           </td><td>0.8446855   </td><td>0.0000000000</td><td>0.882609375 </td><td>0.0000000000</td></tr>
	<tr><td>0.3269062500</td><td>0.0000000000</td><td>0.5792040938</td><td>0.3171382500</td><td>0.5827725625</td><td>0.5         </td><td>0.7724402187</td><td>0.0000000000</td><td>0.7422971875</td><td>0.0350198438</td></tr>
	<tr><td>0.5055407143</td><td>0.0000000000</td><td>0.6110434286</td><td>0.5026570000</td><td>0.6239507143</td><td>0           </td><td>0.6989298571</td><td>0.1428571429</td><td>0.684336    </td><td>0.1119047143</td></tr>
	<tr><td>0.0000000000</td><td>0.0000000000</td><td>0.5113110000</td><td>0.0000000000</td><td>0.3163727500</td><td>0.5         </td><td>0.6129067375</td><td>0.0000000000</td><td>0.639508975 </td><td>0.0000000000</td></tr>
	<tr><td>0.4975847750</td><td>0.0000000000</td><td>0.6942425111</td><td>0.2846974444</td><td>0.5310800278</td><td>0.875       </td><td>0.7183297467</td><td>0.0555555556</td><td>0.7239896944</td><td>0.0923980722</td></tr>
	<tr><td>0.5355928276</td><td>0.0000000000</td><td>0.7142369655</td><td>0.4966507931</td><td>0.6369508276</td><td>0.75        </td><td>0.7585433793</td><td>0.0517241379</td><td>0.7743936897</td><td>0.1767651724</td></tr>
	<tr><td>0.2045450513</td><td>0.0000000000</td><td>0.6485227872</td><td>0.1831252051</td><td>0.6318098718</td><td>0.7777778333</td><td>0.6917824872</td><td>0.0000000000</td><td>0.7732882821</td><td>0.0598290513</td></tr>
	<tr><td>0.0000000000</td><td>0.0000000000</td><td>0.7140302000</td><td>0.0000000000</td><td>0.6666668000</td><td>0.2         </td><td>0.789275    </td><td>0.0000000000</td><td>0.7697606   </td><td>0.0000000000</td></tr>
	<tr><td>0.6075117222</td><td>0.3692614333</td><td>0.3763216667</td><td>0.3299265000</td><td>0.3412617222</td><td>0.4016652222</td><td>0.4421813333</td><td>0.4393773889</td><td>0.4260899722</td><td>0.4249892778</td></tr>
	<tr><td>0.6582970000</td><td>0.3868935200</td><td>0.5800805600</td><td>0.5612021600</td><td>0.5681710800</td><td>0.6572106522</td><td>0.65072276  </td><td>0.5135114800</td><td>0.60463292  </td><td>0.5002514400</td></tr>
	<tr><td>0.4618227400</td><td>0.3131685429</td><td>0.3866988486</td><td>0.3509747800</td><td>0.3797714674</td><td>0.484569129 </td><td>0.4840944429</td><td>0.3372704249</td><td>0.44638858  </td><td>0.3313244371</td></tr>
	<tr><td>0.3029321111</td><td>0.1564048889</td><td>0.2427535222</td><td>0.2733001333</td><td>0.2886528889</td><td>0.365929    </td><td>0.3261977889</td><td>0.2628774111</td><td>0.340142775 </td><td>0.2863854667</td></tr>
	<tr><td>0.5362513333</td><td>0.4211885556</td><td>0.4173411111</td><td>0.3194455667</td><td>0.3827468111</td><td>0.5360422489</td><td>0.4594229444</td><td>0.3944808889</td><td>0.4177737111</td><td>0.3884587778</td></tr>
	<tr><td>0.3948686250</td><td>0.6167542500</td><td>0.6244801375</td><td>0.3858518250</td><td>0.5339707500</td><td>0.516896975 </td><td>0.612497125 </td><td>0.1905070875</td><td>0.62181725  </td><td>0.1946664375</td></tr>
	<tr><td>0.5864937500</td><td>0.3887633333</td><td>0.4544491667</td><td>0.3712463167</td><td>0.3710083333</td><td>0.4004435858</td><td>0.5084571667</td><td>0.3584627167</td><td>0.5087278333</td><td>0.4001341667</td></tr>
	<tr><td>0.6277618889</td><td>0.4449550000</td><td>0.4772124444</td><td>0.3864268111</td><td>0.3625473333</td><td>0.5163198667</td><td>0.5301443   </td><td>0.4900690333</td><td>0.5395405222</td><td>0.4433561222</td></tr>
	<tr><td>0.6418515556</td><td>0.4130148889</td><td>0.4257144389</td><td>0.3677816444</td><td>0.3448534167</td><td>0.4659447778</td><td>0.5041747222</td><td>0.5172328889</td><td>0.5074499444</td><td>0.4362887222</td></tr>
	<tr><td>0.6148866604</td><td>0.4064594264</td><td>0.4282843811</td><td>0.4196097170</td><td>0.3951311245</td><td>0.5232651321</td><td>0.5442367283</td><td>0.5395065283</td><td>0.4946689057</td><td>0.4910820245</td></tr>
	<tr><td>0.6482021111</td><td>0.4180941083</td><td>0.4229416583</td><td>0.3884222139</td><td>0.3816550722</td><td>0.4342907528</td><td>0.5123094444</td><td>0.4975330000</td><td>0.4583173361</td><td>0.4514771389</td></tr>
	<tr><td>0.5114616429</td><td>0.3716503571</td><td>0.4204279286</td><td>0.3402005000</td><td>0.3497128214</td><td>0.4424378571</td><td>0.5327088571</td><td>0.5045612857</td><td>0.521543    </td><td>0.4651317143</td></tr>
	<tr><td>0.6290742174</td><td>0.4145161000</td><td>0.4231165696</td><td>0.3865885826</td><td>0.3519684739</td><td>0.4437201743</td><td>0.521352587 </td><td>0.4623640870</td><td>0.4716031043</td><td>0.4578188739</td></tr>
	<tr><td>0.6466637097</td><td>0.3977609065</td><td>0.4441040032</td><td>0.3778707516</td><td>0.3818559774</td><td>0.4463593067</td><td>0.5610116161</td><td>0.4601941613</td><td>0.4790198226</td><td>0.4567708742</td></tr>
	<tr><td>0.5777289333</td><td>0.5537531333</td><td>0.5545510667</td><td>0.4772877333</td><td>0.4377264667</td><td>0.4935677333</td><td>0.6361981333</td><td>0.5053160667</td><td>0.6328638667</td><td>0.4931488667</td></tr>
	<tr><td>0.0000000000</td><td>0.0000000000</td><td>0.0714285714</td><td>0.0000000000</td><td>0.0000000000</td><td>1           </td><td>0.5         </td><td>0.0000000000</td><td>0.3333333333</td><td>0.0000000000</td></tr>
	<tr><td>0.0000000000</td><td>0.0714285714</td><td>0.1071428571</td><td>0.0000000000</td><td>0.2500000000</td><td>0.5714285714</td><td>0           </td><td>0.0000000000</td><td>0.75        </td><td>0.0000000000</td></tr>
</tbody>
</table>




```R
methMatrix_noCTCFFilt_10ct_NoNA
```


<table class="dataframe">
<caption>A tibble: 123992 × 10</caption>
<thead>
	<tr><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>0.00000000</td><td>0.3986132222</td><td>0.758924000</td><td>0.00000000</td><td>0.000000000</td><td>0.8683217778 </td><td>0.8967626667  </td><td>0.000000000</td><td>0.8804616667 </td><td>0.000000000</td></tr>
	<tr><td>0.00000000</td><td>0.0003370411</td><td>0.001232708</td><td>0.00000000</td><td>0.007751938</td><td>0.0079365    </td><td>0.002717391304</td><td>0.006459946</td><td>0.01086956522</td><td>0.007751938</td></tr>
	<tr><td>0.43091628</td><td>0.8629746111</td><td>0.913014111</td><td>0.62438861</td><td>0.123875611</td><td>0.7918531111 </td><td>0.8466523889  </td><td>0.967592611</td><td>0.8787037222 </td><td>0.490740778</td></tr>
	<tr><td>0.30741762</td><td>0.2357134600</td><td>0.240453310</td><td>0.16995105</td><td>0.033333300</td><td>0.13726615   </td><td>0.27230077    </td><td>0.223333300</td><td>0.2252412    </td><td>0.216666700</td></tr>
	<tr><td>0.66666667</td><td>0.6592395000</td><td>0.499206333</td><td>0.29166667</td><td>0.000000000</td><td>0.84375      </td><td>0             </td><td>0.000000000</td><td>0.6732621667 </td><td>0.333333333</td></tr>
	<tr><td>0.00000000</td><td>0.9381945000</td><td>0.000000000</td><td>0.00000000</td><td>0.000000000</td><td>0.9583333333 </td><td>0.861111      </td><td>0.000000000</td><td>0.9391535    </td><td>0.000000000</td></tr>
	<tr><td>0.23036650</td><td>0.3951615769</td><td>0.436699273</td><td>0.28136504</td><td>0.282748427</td><td>0.6262035526 </td><td>0.5063650167  </td><td>0.133600423</td><td>0.6000363947 </td><td>0.133241731</td></tr>
	<tr><td>0.18991929</td><td>0.3622291765</td><td>0.315070000</td><td>0.22714553</td><td>0.188014235</td><td>0.9375       </td><td>0.1525632727  </td><td>0.144817882</td><td>0.5542327778 </td><td>0.173890588</td></tr>
	<tr><td>0.72461560</td><td>0.8092892000</td><td>0.773860200</td><td>0.77138280</td><td>0.627394000</td><td>0.8387412    </td><td>0.1794516     </td><td>0.175000000</td><td>0.6795918    </td><td>0.537373800</td></tr>
	<tr><td>0.37597402</td><td>0.1838144500</td><td>0.603043000</td><td>0.57478502</td><td>0.432629625</td><td>0.3678942    </td><td>0.174779059   </td><td>0.286029378</td><td>0.2904716675 </td><td>0.337126433</td></tr>
	<tr><td>0.29549088</td><td>0.0000000000</td><td>0.745465925</td><td>0.35009389</td><td>0.606469984</td><td>0.6221358217 </td><td>0.8739610189  </td><td>0.664041536</td><td>0.8481670755 </td><td>0.179240587</td></tr>
	<tr><td>0.08460062</td><td>0.1738681147</td><td>0.129984953</td><td>0.05739979</td><td>0.044418328</td><td>0.1293946612 </td><td>0.1105308954  </td><td>0.059861478</td><td>0.1336111918 </td><td>0.073010111</td></tr>
	<tr><td>0.41025223</td><td>0.9385339231</td><td>0.939444077</td><td>0.54800908</td><td>0.946896308</td><td>0.9653136923 </td><td>0.9744446923  </td><td>0.359850923</td><td>0.9632615385 </td><td>0.249991731</td></tr>
	<tr><td>0.49548768</td><td>0.4191103947</td><td>0.617378776</td><td>0.17200885</td><td>0.406927687</td><td>0.7104560811 </td><td>0.4736291389  </td><td>0.312558397</td><td>0.7172746757 </td><td>0.481333526</td></tr>
	<tr><td>0.70039683</td><td>0.6877705000</td><td>0.616588833</td><td>0.50567300</td><td>0.513007767</td><td>0.7843093333 </td><td>0.572033      </td><td>0.159722167</td><td>0.6504546    </td><td>0.653295167</td></tr>
	<tr><td>0.05630877</td><td>0.0422033456</td><td>0.043238607</td><td>0.04163275</td><td>0.038514660</td><td>0.06905170758</td><td>0.06495400832 </td><td>0.050431597</td><td>0.06848919286</td><td>0.075417018</td></tr>
	<tr><td>0.41842108</td><td>0.7901013846</td><td>0.677402154</td><td>0.39749331</td><td>0.450417462</td><td>0.8116758462 </td><td>0.8875708462  </td><td>0.281196692</td><td>0.2197826154 </td><td>0.384615385</td></tr>
	<tr><td>0.73634750</td><td>0.6419902500</td><td>0.594424000</td><td>0.72344000</td><td>0.782415000</td><td>0.696659025  </td><td>0.48733       </td><td>0.641761500</td><td>0.1055834375 </td><td>0.591949000</td></tr>
	<tr><td>0.74513894</td><td>0.8325073125</td><td>0.905609563</td><td>0.76977138</td><td>0.750800438</td><td>0.8765721875 </td><td>0.3599040437  </td><td>0.759180437</td><td>0.8860234375 </td><td>0.789045312</td></tr>
	<tr><td>0.71824983</td><td>0.6663691667</td><td>0.539856833</td><td>0.59493033</td><td>0.729730833</td><td>0.3479406167 </td><td>0.1348325167  </td><td>0.211454500</td><td>0.5473678333 </td><td>0.414141333</td></tr>
	<tr><td>0.63311540</td><td>0.4408846100</td><td>0.370146303</td><td>0.24084614</td><td>0.280130130</td><td>0.2581309133 </td><td>0.2367806133  </td><td>0.148340277</td><td>0.2580932867 </td><td>0.220868420</td></tr>
	<tr><td>0.81344136</td><td>0.6741617273</td><td>0.790760454</td><td>0.46009473</td><td>0.553324909</td><td>0.2147925364 </td><td>0.3284043545  </td><td>0.215678082</td><td>0.624842     </td><td>0.413851500</td></tr>
	<tr><td>0.77084206</td><td>0.6525558188</td><td>0.320512562</td><td>0.71665419</td><td>0.743482125</td><td>0.9205804375 </td><td>0.9317095625  </td><td>0.917785312</td><td>0.816237125  </td><td>0.424811819</td></tr>
	<tr><td>0.26786610</td><td>0.1735855410</td><td>0.190666056</td><td>0.23775954</td><td>0.190173884</td><td>0.2523955176 </td><td>0.1416534643  </td><td>0.165553703</td><td>0.2795565838 </td><td>0.260236800</td></tr>
	<tr><td>0.52451921</td><td>0.3533441250</td><td>0.299392500</td><td>0.52793267</td><td>0.643046900</td><td>0.8023708333 </td><td>0.86945       </td><td>0.702309692</td><td>0.7486093333 </td><td>0.714667333</td></tr>
	<tr><td>0.74031586</td><td>0.7195342857</td><td>0.745302429</td><td>0.48809014</td><td>0.585794429</td><td>0.2449171    </td><td>0.2508511     </td><td>0.273671929</td><td>0.3617694286 </td><td>0.272097586</td></tr>
	<tr><td>0.83288009</td><td>0.5023639545</td><td>0.711337045</td><td>0.55414595</td><td>0.681442955</td><td>0.1868961955 </td><td>0.1755481227  </td><td>0.206087368</td><td>0.4228495818 </td><td>0.213271573</td></tr>
	<tr><td>0.67677459</td><td>0.8467650270</td><td>0.866379622</td><td>0.75269762</td><td>0.752095270</td><td>0.5386379919 </td><td>0.4633221432  </td><td>0.404454097</td><td>0.5058361568 </td><td>0.160166454</td></tr>
	<tr><td>0.24550987</td><td>0.1703019580</td><td>0.195675906</td><td>0.14910089</td><td>0.181464401</td><td>0.1294420751 </td><td>0.1005630412  </td><td>0.087196896</td><td>0.1766952026 </td><td>0.109505507</td></tr>
	<tr><td>0.62214844</td><td>0.1655110925</td><td>0.270567476</td><td>0.17323645</td><td>0.335840014</td><td>0.3702744425 </td><td>0.2727530962  </td><td>0.296061607</td><td>0.2596652047 </td><td>0.323363660</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>0.7040317</td><td>0.00000000</td><td>0.61611685</td><td>0.61128174</td><td>0.6116899</td><td>0.5405405405</td><td>0.7043768865</td><td>0.08832764</td><td>0.7110297347</td><td>0.13748153</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.51378127</td><td>0.09871982</td><td>0.4245165</td><td>0.8         </td><td>0.6460839091</td><td>0.00000000</td><td>0.639552    </td><td>0.00000000</td></tr>
	<tr><td>0.2617558</td><td>0.00000000</td><td>0.57997297</td><td>0.30626524</td><td>0.6643658</td><td>0.8571428571</td><td>0.7263844848</td><td>0.03535355</td><td>0.7335832727</td><td>0.03254679</td></tr>
	<tr><td>0.2837900</td><td>0.00000000</td><td>0.64958213</td><td>0.28278905</td><td>0.5777168</td><td>0.75        </td><td>0.7366730556</td><td>0.01906319</td><td>0.7472522778</td><td>0.07263242</td></tr>
	<tr><td>0.4950250</td><td>0.00000000</td><td>0.69687665</td><td>0.44390002</td><td>0.6863997</td><td>0.5         </td><td>0.7516725918</td><td>0.00000000</td><td>0.7944938571</td><td>0.10897437</td></tr>
	<tr><td>0.2065973</td><td>0.00000000</td><td>0.77888675</td><td>0.29840425</td><td>0.7292315</td><td>0           </td><td>0.8446855   </td><td>0.00000000</td><td>0.882609375 </td><td>0.00000000</td></tr>
	<tr><td>0.3269063</td><td>0.00000000</td><td>0.57920409</td><td>0.31713825</td><td>0.5827726</td><td>0.5         </td><td>0.7724402187</td><td>0.00000000</td><td>0.7422971875</td><td>0.03501984</td></tr>
	<tr><td>0.5055407</td><td>0.00000000</td><td>0.61104343</td><td>0.50265700</td><td>0.6239507</td><td>0           </td><td>0.6989298571</td><td>0.14285714</td><td>0.684336    </td><td>0.11190471</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.51131100</td><td>0.00000000</td><td>0.3163727</td><td>0.5         </td><td>0.6129067375</td><td>0.00000000</td><td>0.639508975 </td><td>0.00000000</td></tr>
	<tr><td>0.4975848</td><td>0.00000000</td><td>0.69424251</td><td>0.28469744</td><td>0.5310800</td><td>0.875       </td><td>0.7183297467</td><td>0.05555556</td><td>0.7239896944</td><td>0.09239807</td></tr>
	<tr><td>0.5355928</td><td>0.00000000</td><td>0.71423697</td><td>0.49665079</td><td>0.6369508</td><td>0.75        </td><td>0.7585433793</td><td>0.05172414</td><td>0.7743936897</td><td>0.17676517</td></tr>
	<tr><td>0.2045451</td><td>0.00000000</td><td>0.64852279</td><td>0.18312521</td><td>0.6318099</td><td>0.7777778333</td><td>0.6917824872</td><td>0.00000000</td><td>0.7732882821</td><td>0.05982905</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.71403020</td><td>0.00000000</td><td>0.6666668</td><td>0.2         </td><td>0.789275    </td><td>0.00000000</td><td>0.7697606   </td><td>0.00000000</td></tr>
	<tr><td>0.6075117</td><td>0.36926143</td><td>0.37632167</td><td>0.32992650</td><td>0.3412617</td><td>0.4016652222</td><td>0.4421813333</td><td>0.43937739</td><td>0.4260899722</td><td>0.42498928</td></tr>
	<tr><td>0.6582970</td><td>0.38689352</td><td>0.58008056</td><td>0.56120216</td><td>0.5681711</td><td>0.6572106522</td><td>0.65072276  </td><td>0.51351148</td><td>0.60463292  </td><td>0.50025144</td></tr>
	<tr><td>0.4618227</td><td>0.31316854</td><td>0.38669885</td><td>0.35097478</td><td>0.3797715</td><td>0.484569129 </td><td>0.4840944429</td><td>0.33727042</td><td>0.44638858  </td><td>0.33132444</td></tr>
	<tr><td>0.3029321</td><td>0.15640489</td><td>0.24275352</td><td>0.27330013</td><td>0.2886529</td><td>0.365929    </td><td>0.3261977889</td><td>0.26287741</td><td>0.340142775 </td><td>0.28638547</td></tr>
	<tr><td>0.5362513</td><td>0.42118856</td><td>0.41734111</td><td>0.31944557</td><td>0.3827468</td><td>0.5360422489</td><td>0.4594229444</td><td>0.39448089</td><td>0.4177737111</td><td>0.38845878</td></tr>
	<tr><td>0.3948686</td><td>0.61675425</td><td>0.62448014</td><td>0.38585182</td><td>0.5339708</td><td>0.516896975 </td><td>0.612497125 </td><td>0.19050709</td><td>0.62181725  </td><td>0.19466644</td></tr>
	<tr><td>0.5864938</td><td>0.38876333</td><td>0.45444917</td><td>0.37124632</td><td>0.3710083</td><td>0.4004435858</td><td>0.5084571667</td><td>0.35846272</td><td>0.5087278333</td><td>0.40013417</td></tr>
	<tr><td>0.6277619</td><td>0.44495500</td><td>0.47721244</td><td>0.38642681</td><td>0.3625473</td><td>0.5163198667</td><td>0.5301443   </td><td>0.49006903</td><td>0.5395405222</td><td>0.44335612</td></tr>
	<tr><td>0.6418516</td><td>0.41301489</td><td>0.42571444</td><td>0.36778164</td><td>0.3448534</td><td>0.4659447778</td><td>0.5041747222</td><td>0.51723289</td><td>0.5074499444</td><td>0.43628872</td></tr>
	<tr><td>0.6148867</td><td>0.40645943</td><td>0.42828438</td><td>0.41960972</td><td>0.3951311</td><td>0.5232651321</td><td>0.5442367283</td><td>0.53950653</td><td>0.4946689057</td><td>0.49108202</td></tr>
	<tr><td>0.6482021</td><td>0.41809411</td><td>0.42294166</td><td>0.38842221</td><td>0.3816551</td><td>0.4342907528</td><td>0.5123094444</td><td>0.49753300</td><td>0.4583173361</td><td>0.45147714</td></tr>
	<tr><td>0.5114616</td><td>0.37165036</td><td>0.42042793</td><td>0.34020050</td><td>0.3497128</td><td>0.4424378571</td><td>0.5327088571</td><td>0.50456129</td><td>0.521543    </td><td>0.46513171</td></tr>
	<tr><td>0.6290742</td><td>0.41451610</td><td>0.42311657</td><td>0.38658858</td><td>0.3519685</td><td>0.4437201743</td><td>0.521352587 </td><td>0.46236409</td><td>0.4716031043</td><td>0.45781887</td></tr>
	<tr><td>0.6466637</td><td>0.39776091</td><td>0.44410400</td><td>0.37787075</td><td>0.3818560</td><td>0.4463593067</td><td>0.5610116161</td><td>0.46019416</td><td>0.4790198226</td><td>0.45677087</td></tr>
	<tr><td>0.5777289</td><td>0.55375313</td><td>0.55455107</td><td>0.47728773</td><td>0.4377265</td><td>0.4935677333</td><td>0.6361981333</td><td>0.50531607</td><td>0.6328638667</td><td>0.49314887</td></tr>
	<tr><td>0.0000000</td><td>0.00000000</td><td>0.07142857</td><td>0.00000000</td><td>0.0000000</td><td>1           </td><td>0.5         </td><td>0.00000000</td><td>0.3333333333</td><td>0.00000000</td></tr>
	<tr><td>0.0000000</td><td>0.07142857</td><td>0.10714286</td><td>0.00000000</td><td>0.2500000</td><td>0.5714285714</td><td>0           </td><td>0.00000000</td><td>0.75        </td><td>0.00000000</td></tr>
</tbody>
</table>



## Elbow method


```R
# Elbow method
scaled_data = as.matrix(scale(methMatrix_noCTCFFilt_10ct_NoNA_nummat))
k.max <- 15
data <- scaled_data
wss <- sapply(1:k.max,
              function(k){kmeans(data, k,iter.max = 80, algorithm = "Hartigan-Wong" )$tot.withinss})
wss

pdf(file = "/data/hodges_lab/Tim/MethylationHeatmap_paper/Elbow_Method.10ct.pdf")

plot(1:k.max, wss,
     type="b", pch = 19, frame = TRUE,
     xlab="Number of clusters K", 
     ylab="Total within-clusters sum of squares")

dev.off()

```

    Warning message:
    “Quick-TRANSfer stage steps exceeded maximum (= 6199600)”



<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>1239910.00000001</li><li>835274.111723265</li><li>630412.895505676</li><li>557006.317987546</li><li>514803.431294636</li><li>455142.518554006</li><li>424779.317462294</li><li>413354.644932347</li><li>387603.25696616</li><li>359016.547506521</li><li>345944.934743873</li><li>340462.47629996</li><li>323066.944693357</li><li>313911.799860817</li><li>306501.086967756</li></ol>




<strong>png:</strong> 2



```R
plot(1:k.max, wss,
     type="b", pch = 19, frame = TRUE,
     xlab="Number of clusters K", 
     ylab="Total within-clusters sum of squares")
```


![png](output_32_0.png)


## Heatmap


```R
RNGkind(sample.kind="Rounding")
```

    Warning message in RNGkind(sample.kind = "Rounding"):
    “non-uniform 'Rounding' sampler used”



```R
# Finalists
for (seedNum in c(86,57,68,83,107)) {
    print(seedNum)
    set.seed(seedNum)
    col.pal <- brewer.pal(9,"YlOrRd")
    pheatmap(methMatrix_noCTCFFilt_10ct_NoNA, kmeans_k = 10, cluster_cols = F,
                       color=rev(col.pal), cutree_rows = 10, main = paste0(seedNum, " - k-means = 10"))
}
```

    [1] 86
    [1] 57



![png](output_35_1.png)


    [1] 68



![png](output_35_3.png)


    [1] 83



![png](output_35_5.png)


    [1] 107



![png](output_35_7.png)



![png](output_35_8.png)


### Final 


```R
pdf(file = "/data/hodges_lab/Tim/MethylationHeatmap_paper/MethylationHeatmap_k10_setseed86.10ct.pdf")

seedNum = 86
set.seed(seedNum)
col.pal <- brewer.pal(9,"YlOrRd")
pheatmap(methMatrix_noCTCFFilt_10ct_NoNA, kmeans_k = 10, cluster_cols = F,
                       color=rev(col.pal), cutree_rows = 10, main = paste0(seedNum, " - k-means = 10"))

dev.off()
```


<strong>pdf:</strong> 3



```R
seedNum = 86
set.seed(seedNum)
col.pal <- brewer.pal(10,"YlOrRd")
p_k10_seed86 <- pheatmap(methMatrix_noCTCFFilt_10ct_NoNA, kmeans_k = 10, cluster_cols = F,
                       color=rev(col.pal), cutree_rows = 10, main = paste0(seedNum, " - k-means = 10"))
```

    Warning message in brewer.pal(10, "YlOrRd"):
    “n too large, allowed maximum for palette YlOrRd is 9
    Returning the palette you asked for with that many colors
    ”



![png](output_38_1.png)



```R
# Trial from online

save_pheatmap_pdf <- function(x, filename, width=7, height=7) {
    stopifnot(!missing(x))
    stopifnot(!missing(filename))
    pdf(filename, width=width, height=height)
    grid::grid.newpage()
    grid::grid.draw(x$gtable)
    dev.off()
}

save_pheatmap_pdf(p_k10_seed86, "/data/hodges_lab/Tim/MethylationHeatmap_paper/MethylationHeatmap_k10_setseed86.10ct.save_pheatmap_pdf.pdf")
```


<strong>png:</strong> 2



```R

```

# Save clusters


```R
setwd("/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/")

```


```R
methMatrix_noCTCFFilt_10ct_bed <- read_tsv("masterHMRs_methMatrix.noCTCFfilter.10ct.txt", col_names=F)
colnames(methMatrix_noCTCFFilt_10ct_bed) <- c("chr","start","end","H1ESC","fSpinal","fHeart","Adrenal","Liver","HSPC","Macrophage","Neutrophil","Tcell","Bcell")

```

    Warning message:
    “One or more parsing issues, see `problems()` for details”
    [1mRows: [22m[34m126104[39m [1mColumns: [22m[34m13[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): X1, X9, X10, X12
    [32mdbl[39m (9): X2, X3, X4, X5, X6, X7, X8, X11, X13
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
head(methMatrix_noCTCFFilt_10ct_bed)
```


<table class="dataframe">
<caption>A tibble: 6 × 13</caption>
<thead>
	<tr><th scope=col>chr</th><th scope=col>start</th><th scope=col>end</th><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 20043</td><td> 20480</td><td>0.0000000</td><td>0.3986132222</td><td>0.758924000</td><td>0.0000000</td><td>0.000000000</td><td>0.8683217778</td><td>0.8967626667  </td><td>0.000000000</td><td>0.8804616667 </td><td>0.000000000</td></tr>
	<tr><td>chr1</td><td> 28432</td><td> 30155</td><td>0.0000000</td><td>0.0003370411</td><td>0.001232708</td><td>0.0000000</td><td>0.007751938</td><td>0.0079365   </td><td>0.002717391304</td><td>0.006459946</td><td>0.01086956522</td><td>0.007751938</td></tr>
	<tr><td>chr1</td><td> 51441</td><td> 51734</td><td>0.4309163</td><td>0.8629746111</td><td>0.913014111</td><td>0.6243886</td><td>0.123875611</td><td>0.7918531111</td><td>0.8466523889  </td><td>0.967592611</td><td>0.8787037222 </td><td>0.490740778</td></tr>
	<tr><td>chr1</td><td> 91118</td><td> 91684</td><td>0.3074176</td><td>0.2357134600</td><td>0.240453310</td><td>0.1699510</td><td>0.033333300</td><td>0.13726615  </td><td>0.27230077    </td><td>0.223333300</td><td>0.2252412    </td><td>0.216666700</td></tr>
	<tr><td>chr1</td><td> 96558</td><td> 96806</td><td>0.6666667</td><td>0.6592395000</td><td>0.499206333</td><td>0.2916667</td><td>0.000000000</td><td>0.84375     </td><td>0             </td><td>0.000000000</td><td>0.6732621667 </td><td>0.333333333</td></tr>
	<tr><td>chr1</td><td>137353</td><td>137404</td><td>0.0000000</td><td>0.9381945000</td><td>0.000000000</td><td>0.0000000</td><td>0.000000000</td><td>0.9583333333</td><td>0.861111      </td><td>0.000000000</td><td>0.9391535    </td><td>0.000000000</td></tr>
</tbody>
</table>




```R
# NA Omit
methMatrix_noCTCFFilt_10ct_bed[ methMatrix_noCTCFFilt_10ct_bed == "." ] <- NA
methMatrix_noCTCFFilt_noNA_10ct_bed <- na.omit(methMatrix_noCTCFFilt_10ct_bed)
methMatrix_noCTCFFilt_10ct_bed
```


<table class="dataframe">
<caption>A spec_tbl_df: 126104 × 13</caption>
<thead>
	<tr><th scope=col>chr</th><th scope=col>start</th><th scope=col>end</th><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 20043</td><td> 20480</td><td>0.00000000</td><td>0.3986132222</td><td>0.758924000</td><td>0.00000000</td><td>0.000000000</td><td>0.8683217778 </td><td>0.8967626667  </td><td>0.000000000</td><td>0.8804616667 </td><td>0.000000000</td></tr>
	<tr><td>chr1</td><td> 28432</td><td> 30155</td><td>0.00000000</td><td>0.0003370411</td><td>0.001232708</td><td>0.00000000</td><td>0.007751938</td><td>0.0079365    </td><td>0.002717391304</td><td>0.006459946</td><td>0.01086956522</td><td>0.007751938</td></tr>
	<tr><td>chr1</td><td> 51441</td><td> 51734</td><td>0.43091628</td><td>0.8629746111</td><td>0.913014111</td><td>0.62438861</td><td>0.123875611</td><td>0.7918531111 </td><td>0.8466523889  </td><td>0.967592611</td><td>0.8787037222 </td><td>0.490740778</td></tr>
	<tr><td>chr1</td><td> 91118</td><td> 91684</td><td>0.30741762</td><td>0.2357134600</td><td>0.240453310</td><td>0.16995105</td><td>0.033333300</td><td>0.13726615   </td><td>0.27230077    </td><td>0.223333300</td><td>0.2252412    </td><td>0.216666700</td></tr>
	<tr><td>chr1</td><td> 96558</td><td> 96806</td><td>0.66666667</td><td>0.6592395000</td><td>0.499206333</td><td>0.29166667</td><td>0.000000000</td><td>0.84375      </td><td>0             </td><td>0.000000000</td><td>0.6732621667 </td><td>0.333333333</td></tr>
	<tr><td>chr1</td><td>137353</td><td>137404</td><td>0.00000000</td><td>0.9381945000</td><td>0.000000000</td><td>0.00000000</td><td>0.000000000</td><td>0.9583333333 </td><td>0.861111      </td><td>0.000000000</td><td>0.9391535    </td><td>0.000000000</td></tr>
	<tr><td>chr1</td><td>235927</td><td>237877</td><td>0.23036650</td><td>0.3951615769</td><td>0.436699273</td><td>0.28136504</td><td>0.282748427</td><td>0.6262035526 </td><td>0.5063650167  </td><td>0.133600423</td><td>0.6000363947 </td><td>0.133241731</td></tr>
	<tr><td>chr1</td><td>241322</td><td>243648</td><td>0.18991929</td><td>0.3622291765</td><td>0.315070000</td><td>0.22714553</td><td>0.188014235</td><td>0.9375       </td><td>0.1525632727  </td><td>0.144817882</td><td>0.5542327778 </td><td>0.173890588</td></tr>
	<tr><td>chr1</td><td>250304</td><td>250571</td><td>0.72461560</td><td>0.8092892000</td><td>0.773860200</td><td>0.77138280</td><td>0.627394000</td><td>0.8387412    </td><td>0.1794516     </td><td>0.175000000</td><td>0.6795918    </td><td>0.537373800</td></tr>
	<tr><td>chr1</td><td>435874</td><td>436666</td><td>0.00000000</td><td>0.0000000000</td><td>0.000000000</td><td>0.00000000</td><td>0.000000000</td><td>0.2          </td><td>NA            </td><td>0.000000000</td><td>NA           </td><td>0.000000000</td></tr>
	<tr><td>chr1</td><td>521379</td><td>521660</td><td>0.40476186</td><td>0.0738095571</td><td>0.152698043</td><td>0.06207246</td><td>0.040399386</td><td>0.0555555    </td><td>NA            </td><td>0.021978000</td><td>NA           </td><td>0.000000000</td></tr>
	<tr><td>chr1</td><td>540516</td><td>541078</td><td>0.37597402</td><td>0.1838144500</td><td>0.603043000</td><td>0.57478502</td><td>0.432629625</td><td>0.3678942    </td><td>0.174779059   </td><td>0.286029378</td><td>0.2904716675 </td><td>0.337126433</td></tr>
	<tr><td>chr1</td><td>564470</td><td>570301</td><td>0.29549088</td><td>0.0000000000</td><td>0.745465925</td><td>0.35009389</td><td>0.606469984</td><td>0.6221358217 </td><td>0.8739610189  </td><td>0.664041536</td><td>0.8481670755 </td><td>0.179240587</td></tr>
	<tr><td>chr1</td><td>580157</td><td>580989</td><td>0.20512823</td><td>0.0000000000</td><td>0.115384615</td><td>0.26121792</td><td>0.293846154</td><td>NA           </td><td>NA            </td><td>0.269230769</td><td>NA           </td><td>0.307692308</td></tr>
	<tr><td>chr1</td><td>601076</td><td>601549</td><td>0.37632288</td><td>0.0000000000</td><td>0.157488575</td><td>0.16971412</td><td>0.144573375</td><td>0.5          </td><td>NA            </td><td>0.261458375</td><td>NA           </td><td>0.253594750</td></tr>
	<tr><td>chr1</td><td>713542</td><td>715250</td><td>0.08460062</td><td>0.1738681147</td><td>0.129984953</td><td>0.05739979</td><td>0.044418328</td><td>0.1293946612 </td><td>0.1105308954  </td><td>0.059861478</td><td>0.1336111918 </td><td>0.073010111</td></tr>
	<tr><td>chr1</td><td>724205</td><td>724516</td><td>0.41025223</td><td>0.9385339231</td><td>0.939444077</td><td>0.54800908</td><td>0.946896308</td><td>0.9653136923 </td><td>0.9744446923  </td><td>0.359850923</td><td>0.9632615385 </td><td>0.249991731</td></tr>
	<tr><td>chr1</td><td>751579</td><td>754108</td><td>0.49548768</td><td>0.4191103947</td><td>0.617378776</td><td>0.17200885</td><td>0.406927687</td><td>0.7104560811 </td><td>0.4736291389  </td><td>0.312558397</td><td>0.7172746757 </td><td>0.481333526</td></tr>
	<tr><td>chr1</td><td>760139</td><td>760912</td><td>0.70039683</td><td>0.6877705000</td><td>0.616588833</td><td>0.50567300</td><td>0.513007767</td><td>0.7843093333 </td><td>0.572033      </td><td>0.159722167</td><td>0.6504546    </td><td>0.653295167</td></tr>
	<tr><td>chr1</td><td>761369</td><td>764411</td><td>0.05630877</td><td>0.0422033456</td><td>0.043238607</td><td>0.04163275</td><td>0.038514660</td><td>0.06905170758</td><td>0.06495400832 </td><td>0.050431597</td><td>0.06848919286</td><td>0.075417018</td></tr>
	<tr><td>chr1</td><td>777447</td><td>777888</td><td>0.41842108</td><td>0.7901013846</td><td>0.677402154</td><td>0.39749331</td><td>0.450417462</td><td>0.8116758462 </td><td>0.8875708462  </td><td>0.281196692</td><td>0.2197826154 </td><td>0.384615385</td></tr>
	<tr><td>chr1</td><td>779994</td><td>780162</td><td>0.73634750</td><td>0.6419902500</td><td>0.594424000</td><td>0.72344000</td><td>0.782415000</td><td>0.696659025  </td><td>0.48733       </td><td>0.641761500</td><td>0.1055834375 </td><td>0.591949000</td></tr>
	<tr><td>chr1</td><td>786789</td><td>787096</td><td>0.74513894</td><td>0.8325073125</td><td>0.905609563</td><td>0.76977138</td><td>0.750800438</td><td>0.8765721875 </td><td>0.3599040437  </td><td>0.759180437</td><td>0.8860234375 </td><td>0.789045312</td></tr>
	<tr><td>chr1</td><td>792048</td><td>792328</td><td>0.71824983</td><td>0.6663691667</td><td>0.539856833</td><td>0.59493033</td><td>0.729730833</td><td>0.3479406167 </td><td>0.1348325167  </td><td>0.211454500</td><td>0.5473678333 </td><td>0.414141333</td></tr>
	<tr><td>chr1</td><td>793394</td><td>794622</td><td>0.63311540</td><td>0.4408846100</td><td>0.370146303</td><td>0.24084614</td><td>0.280130130</td><td>0.2581309133 </td><td>0.2367806133  </td><td>0.148340277</td><td>0.2580932867 </td><td>0.220868420</td></tr>
	<tr><td>chr1</td><td>796327</td><td>796684</td><td>0.81344136</td><td>0.6741617273</td><td>0.790760454</td><td>0.46009473</td><td>0.553324909</td><td>0.2147925364 </td><td>0.3284043545  </td><td>0.215678082</td><td>0.624842     </td><td>0.413851500</td></tr>
	<tr><td>chr1</td><td>801044</td><td>801850</td><td>0.77084206</td><td>0.6525558188</td><td>0.320512562</td><td>0.71665419</td><td>0.743482125</td><td>0.9205804375 </td><td>0.9317095625  </td><td>0.917785312</td><td>0.816237125  </td><td>0.424811819</td></tr>
	<tr><td>chr1</td><td>802921</td><td>805627</td><td>0.26786610</td><td>0.1735855410</td><td>0.190666056</td><td>0.23775954</td><td>0.190173884</td><td>0.2523955176 </td><td>0.1416534643  </td><td>0.165553703</td><td>0.2795565838 </td><td>0.260236800</td></tr>
	<tr><td>chr1</td><td>807944</td><td>808642</td><td>0.52451921</td><td>0.3533441250</td><td>0.299392500</td><td>0.52793267</td><td>0.643046900</td><td>0.8023708333 </td><td>0.86945       </td><td>0.702309692</td><td>0.7486093333 </td><td>0.714667333</td></tr>
	<tr><td>chr1</td><td>825900</td><td>826457</td><td>0.74031586</td><td>0.7195342857</td><td>0.745302429</td><td>0.48809014</td><td>0.585794429</td><td>0.2449171    </td><td>0.2508511     </td><td>0.273671929</td><td>0.3617694286 </td><td>0.272097586</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrY</td><td>58862712</td><td>58863851</td><td>0.4975848</td><td>0.00000000</td><td>0.69424251</td><td>0.2846974</td><td>0.5310800</td><td>0.875       </td><td>0.7183297467</td><td>0.05555556</td><td>0.7239896944</td><td>0.092398072</td></tr>
	<tr><td>chrY</td><td>58866276</td><td>58867160</td><td>0.5355928</td><td>0.00000000</td><td>0.71423697</td><td>0.4966508</td><td>0.6369508</td><td>0.75        </td><td>0.7585433793</td><td>0.05172414</td><td>0.7743936897</td><td>0.176765172</td></tr>
	<tr><td>chrY</td><td>58868385</td><td>58869825</td><td>0.3791546</td><td>0.00000000</td><td>0.67038338</td><td>0.3085624</td><td>0.6953183</td><td>NA          </td><td>0.7633258462</td><td>0.00000000</td><td>0.7642892308</td><td>0.006410256</td></tr>
	<tr><td>chrY</td><td>58887160</td><td>58887622</td><td>0.0000000</td><td>0.00000000</td><td>0.39217722</td><td>0.0000000</td><td>0.4506453</td><td>NA          </td><td>0.6502811111</td><td>0.00000000</td><td>0.6133279444</td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>58890909</td><td>58892319</td><td>0.2045451</td><td>0.00000000</td><td>0.64852279</td><td>0.1831252</td><td>0.6318099</td><td>0.7777778333</td><td>0.6917824872</td><td>0.00000000</td><td>0.7732882821</td><td>0.059829051</td></tr>
	<tr><td>chrY</td><td>58895901</td><td>58896603</td><td>0.0000000</td><td>0.00000000</td><td>0.58239608</td><td>0.0000000</td><td>0.2838468</td><td>NA          </td><td>0.8049603333</td><td>0.00000000</td><td>0.670703875 </td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>58901521</td><td>58901918</td><td>0.0000000</td><td>0.00000000</td><td>0.49053850</td><td>0.0000000</td><td>0.3382576</td><td>NA          </td><td>0.52791125  </td><td>0.00000000</td><td>0.552617375 </td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>58902934</td><td>58903406</td><td>0.0000000</td><td>0.00000000</td><td>0.54642445</td><td>0.0000000</td><td>0.3203973</td><td>NA          </td><td>0.6080712727</td><td>0.00000000</td><td>0.5845803636</td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>58910928</td><td>58911153</td><td>0.8595699</td><td>0.00000000</td><td>0.79563907</td><td>0.7949341</td><td>0.7857352</td><td>NA          </td><td>0.76645105  </td><td>0.04166664</td><td>0.7809690929</td><td>0.237013000</td></tr>
	<tr><td>chrY</td><td>58912801</td><td>58912947</td><td>0.8364420</td><td>0.00000000</td><td>0.66420417</td><td>0.6958045</td><td>0.6997942</td><td>NA          </td><td>0.8880951667</td><td>0.15293667</td><td>0.8014068333</td><td>0.121835167</td></tr>
	<tr><td>chrY</td><td>58914771</td><td>58914877</td><td>0.0000000</td><td>0.00000000</td><td>0.71403020</td><td>0.0000000</td><td>0.6666668</td><td>0.2         </td><td>0.789275    </td><td>0.00000000</td><td>0.7697606   </td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>58968459</td><td>58970307</td><td>0.6075117</td><td>0.36926143</td><td>0.37632167</td><td>0.3299265</td><td>0.3412617</td><td>0.4016652222</td><td>0.4421813333</td><td>0.43937739</td><td>0.4260899722</td><td>0.424989278</td></tr>
	<tr><td>chrY</td><td>58973924</td><td>58975180</td><td>0.6582970</td><td>0.38689352</td><td>0.58008056</td><td>0.5612022</td><td>0.5681711</td><td>0.6572106522</td><td>0.65072276  </td><td>0.51351148</td><td>0.60463292  </td><td>0.500251440</td></tr>
	<tr><td>chrY</td><td>58975712</td><td>58980982</td><td>0.4618227</td><td>0.31316854</td><td>0.38669885</td><td>0.3509748</td><td>0.3797715</td><td>0.484569129 </td><td>0.4840944429</td><td>0.33727042</td><td>0.44638858  </td><td>0.331324437</td></tr>
	<tr><td>chrY</td><td>58981441</td><td>58982549</td><td>0.3029321</td><td>0.15640489</td><td>0.24275352</td><td>0.2733001</td><td>0.2886529</td><td>0.365929    </td><td>0.3261977889</td><td>0.26287741</td><td>0.340142775 </td><td>0.286385467</td></tr>
	<tr><td>chrY</td><td>58984477</td><td>58985363</td><td>0.5362513</td><td>0.42118856</td><td>0.41734111</td><td>0.3194456</td><td>0.3827468</td><td>0.5360422489</td><td>0.4594229444</td><td>0.39448089</td><td>0.4177737111</td><td>0.388458778</td></tr>
	<tr><td>chrY</td><td>58987083</td><td>58987887</td><td>0.3948686</td><td>0.61675425</td><td>0.62448014</td><td>0.3858518</td><td>0.5339708</td><td>0.516896975 </td><td>0.612497125 </td><td>0.19050709</td><td>0.62181725  </td><td>0.194666438</td></tr>
	<tr><td>chrY</td><td>58991998</td><td>58993040</td><td>0.5864938</td><td>0.38876333</td><td>0.45444917</td><td>0.3712463</td><td>0.3710083</td><td>0.4004435858</td><td>0.5084571667</td><td>0.35846272</td><td>0.5087278333</td><td>0.400134167</td></tr>
	<tr><td>chrY</td><td>58997396</td><td>58999154</td><td>0.6277619</td><td>0.44495500</td><td>0.47721244</td><td>0.3864268</td><td>0.3625473</td><td>0.5163198667</td><td>0.5301443   </td><td>0.49006903</td><td>0.5395405222</td><td>0.443356122</td></tr>
	<tr><td>chrY</td><td>59002477</td><td>59004319</td><td>0.6418516</td><td>0.41301489</td><td>0.42571444</td><td>0.3677816</td><td>0.3448534</td><td>0.4659447778</td><td>0.5041747222</td><td>0.51723289</td><td>0.5074499444</td><td>0.436288722</td></tr>
	<tr><td>chrY</td><td>59005151</td><td>59013694</td><td>0.6148867</td><td>0.40645943</td><td>0.42828438</td><td>0.4196097</td><td>0.3951311</td><td>0.5232651321</td><td>0.5442367283</td><td>0.53950653</td><td>0.4946689057</td><td>0.491082024</td></tr>
	<tr><td>chrY</td><td>59013786</td><td>59019076</td><td>0.6482021</td><td>0.41809411</td><td>0.42294166</td><td>0.3884222</td><td>0.3816551</td><td>0.4342907528</td><td>0.5123094444</td><td>0.49753300</td><td>0.4583173361</td><td>0.451477139</td></tr>
	<tr><td>chrY</td><td>59019178</td><td>59020362</td><td>0.5114616</td><td>0.37165036</td><td>0.42042793</td><td>0.3402005</td><td>0.3497128</td><td>0.4424378571</td><td>0.5327088571</td><td>0.50456129</td><td>0.521543    </td><td>0.465131714</td></tr>
	<tr><td>chrY</td><td>59020798</td><td>59024579</td><td>0.6290742</td><td>0.41451610</td><td>0.42311657</td><td>0.3865886</td><td>0.3519685</td><td>0.4437201743</td><td>0.521352587 </td><td>0.46236409</td><td>0.4716031043</td><td>0.457818874</td></tr>
	<tr><td>chrY</td><td>59026116</td><td>59029265</td><td>0.6466637</td><td>0.39776091</td><td>0.44410400</td><td>0.3778708</td><td>0.3818560</td><td>0.4463593067</td><td>0.5610116161</td><td>0.46019416</td><td>0.4790198226</td><td>0.456770874</td></tr>
	<tr><td>chrY</td><td>59030207</td><td>59031692</td><td>0.5777289</td><td>0.55375313</td><td>0.55455107</td><td>0.4772877</td><td>0.4377265</td><td>0.4935677333</td><td>0.6361981333</td><td>0.50531607</td><td>0.6328638667</td><td>0.493148867</td></tr>
	<tr><td>chrY</td><td>59119931</td><td>59120410</td><td>0.0000000</td><td>0.00000000</td><td>0.31250000</td><td>0.0000000</td><td>0.6250000</td><td>NA          </td><td>0.8333333333</td><td>0.00000000</td><td>NA          </td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>59170454</td><td>59170936</td><td>0.0000000</td><td>0.00000000</td><td>0.00000000</td><td>0.0000000</td><td>0.1428571</td><td>NA          </td><td>1           </td><td>0.00000000</td><td>NA          </td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>59234842</td><td>59236468</td><td>0.0000000</td><td>0.00000000</td><td>0.07142857</td><td>0.0000000</td><td>0.0000000</td><td>1           </td><td>0.5         </td><td>0.00000000</td><td>0.3333333333</td><td>0.000000000</td></tr>
	<tr><td>chrY</td><td>59265980</td><td>59268752</td><td>0.0000000</td><td>0.07142857</td><td>0.10714286</td><td>0.0000000</td><td>0.2500000</td><td>0.5714285714</td><td>0           </td><td>0.00000000</td><td>0.75        </td><td>0.000000000</td></tr>
</tbody>
</table>




```R
dim(methMatrix_noCTCFFilt_noNA_10ct_bed)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>123992</li><li>13</li></ol>




```R
str(p_k10_seed86$kmeans$cluster)
```

     int [1:123992] 1 5 9 5 1 1 1 5 6 1 ...



```R
# Add together
output_10ct <- cbind(methMatrix_noCTCFFilt_noNA_10ct_bed, p_k10_seed86$kmeans$cluster)
```


```R
output_10ct
```


<table class="dataframe">
<caption>A data.frame: 123992 × 14</caption>
<thead>
	<tr><th scope=col>chr</th><th scope=col>start</th><th scope=col>end</th><th scope=col>H1ESC</th><th scope=col>fSpinal</th><th scope=col>fHeart</th><th scope=col>Adrenal</th><th scope=col>Liver</th><th scope=col>HSPC</th><th scope=col>Macrophage</th><th scope=col>Neutrophil</th><th scope=col>Tcell</th><th scope=col>Bcell</th><th scope=col>p_k10_seed86$kmeans$cluster</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 20043</td><td> 20480</td><td>0.00000000</td><td>0.3986132222</td><td>0.758924000</td><td>0.00000000</td><td>0.000000000</td><td>0.8683217778 </td><td>0.8967626667  </td><td>0.000000000</td><td>0.8804616667 </td><td>0.000000000</td><td> 1</td></tr>
	<tr><td>chr1</td><td> 28432</td><td> 30155</td><td>0.00000000</td><td>0.0003370411</td><td>0.001232708</td><td>0.00000000</td><td>0.007751938</td><td>0.0079365    </td><td>0.002717391304</td><td>0.006459946</td><td>0.01086956522</td><td>0.007751938</td><td> 5</td></tr>
	<tr><td>chr1</td><td> 51441</td><td> 51734</td><td>0.43091628</td><td>0.8629746111</td><td>0.913014111</td><td>0.62438861</td><td>0.123875611</td><td>0.7918531111 </td><td>0.8466523889  </td><td>0.967592611</td><td>0.8787037222 </td><td>0.490740778</td><td> 9</td></tr>
	<tr><td>chr1</td><td> 91118</td><td> 91684</td><td>0.30741762</td><td>0.2357134600</td><td>0.240453310</td><td>0.16995105</td><td>0.033333300</td><td>0.13726615   </td><td>0.27230077    </td><td>0.223333300</td><td>0.2252412    </td><td>0.216666700</td><td> 5</td></tr>
	<tr><td>chr1</td><td> 96558</td><td> 96806</td><td>0.66666667</td><td>0.6592395000</td><td>0.499206333</td><td>0.29166667</td><td>0.000000000</td><td>0.84375      </td><td>0             </td><td>0.000000000</td><td>0.6732621667 </td><td>0.333333333</td><td> 1</td></tr>
	<tr><td>chr1</td><td>137353</td><td>137404</td><td>0.00000000</td><td>0.9381945000</td><td>0.000000000</td><td>0.00000000</td><td>0.000000000</td><td>0.9583333333 </td><td>0.861111      </td><td>0.000000000</td><td>0.9391535    </td><td>0.000000000</td><td> 1</td></tr>
	<tr><td>chr1</td><td>235927</td><td>237877</td><td>0.23036650</td><td>0.3951615769</td><td>0.436699273</td><td>0.28136504</td><td>0.282748427</td><td>0.6262035526 </td><td>0.5063650167  </td><td>0.133600423</td><td>0.6000363947 </td><td>0.133241731</td><td> 1</td></tr>
	<tr><td>chr1</td><td>241322</td><td>243648</td><td>0.18991929</td><td>0.3622291765</td><td>0.315070000</td><td>0.22714553</td><td>0.188014235</td><td>0.9375       </td><td>0.1525632727  </td><td>0.144817882</td><td>0.5542327778 </td><td>0.173890588</td><td> 5</td></tr>
	<tr><td>chr1</td><td>250304</td><td>250571</td><td>0.72461560</td><td>0.8092892000</td><td>0.773860200</td><td>0.77138280</td><td>0.627394000</td><td>0.8387412    </td><td>0.1794516     </td><td>0.175000000</td><td>0.6795918    </td><td>0.537373800</td><td> 6</td></tr>
	<tr><td>chr1</td><td>540516</td><td>541078</td><td>0.37597402</td><td>0.1838144500</td><td>0.603043000</td><td>0.57478502</td><td>0.432629625</td><td>0.3678942    </td><td>0.174779059   </td><td>0.286029378</td><td>0.2904716675 </td><td>0.337126433</td><td> 1</td></tr>
	<tr><td>chr1</td><td>564470</td><td>570301</td><td>0.29549088</td><td>0.0000000000</td><td>0.745465925</td><td>0.35009389</td><td>0.606469984</td><td>0.6221358217 </td><td>0.8739610189  </td><td>0.664041536</td><td>0.8481670755 </td><td>0.179240587</td><td>10</td></tr>
	<tr><td>chr1</td><td>713542</td><td>715250</td><td>0.08460062</td><td>0.1738681147</td><td>0.129984953</td><td>0.05739979</td><td>0.044418328</td><td>0.1293946612 </td><td>0.1105308954  </td><td>0.059861478</td><td>0.1336111918 </td><td>0.073010111</td><td> 5</td></tr>
	<tr><td>chr1</td><td>724205</td><td>724516</td><td>0.41025223</td><td>0.9385339231</td><td>0.939444077</td><td>0.54800908</td><td>0.946896308</td><td>0.9653136923 </td><td>0.9744446923  </td><td>0.359850923</td><td>0.9632615385 </td><td>0.249991731</td><td> 7</td></tr>
	<tr><td>chr1</td><td>751579</td><td>754108</td><td>0.49548768</td><td>0.4191103947</td><td>0.617378776</td><td>0.17200885</td><td>0.406927687</td><td>0.7104560811 </td><td>0.4736291389  </td><td>0.312558397</td><td>0.7172746757 </td><td>0.481333526</td><td> 1</td></tr>
	<tr><td>chr1</td><td>760139</td><td>760912</td><td>0.70039683</td><td>0.6877705000</td><td>0.616588833</td><td>0.50567300</td><td>0.513007767</td><td>0.7843093333 </td><td>0.572033      </td><td>0.159722167</td><td>0.6504546    </td><td>0.653295167</td><td> 6</td></tr>
	<tr><td>chr1</td><td>761369</td><td>764411</td><td>0.05630877</td><td>0.0422033456</td><td>0.043238607</td><td>0.04163275</td><td>0.038514660</td><td>0.06905170758</td><td>0.06495400832 </td><td>0.050431597</td><td>0.06848919286</td><td>0.075417018</td><td> 5</td></tr>
	<tr><td>chr1</td><td>777447</td><td>777888</td><td>0.41842108</td><td>0.7901013846</td><td>0.677402154</td><td>0.39749331</td><td>0.450417462</td><td>0.8116758462 </td><td>0.8875708462  </td><td>0.281196692</td><td>0.2197826154 </td><td>0.384615385</td><td> 2</td></tr>
	<tr><td>chr1</td><td>779994</td><td>780162</td><td>0.73634750</td><td>0.6419902500</td><td>0.594424000</td><td>0.72344000</td><td>0.782415000</td><td>0.696659025  </td><td>0.48733       </td><td>0.641761500</td><td>0.1055834375 </td><td>0.591949000</td><td> 2</td></tr>
	<tr><td>chr1</td><td>786789</td><td>787096</td><td>0.74513894</td><td>0.8325073125</td><td>0.905609563</td><td>0.76977138</td><td>0.750800438</td><td>0.8765721875 </td><td>0.3599040437  </td><td>0.759180437</td><td>0.8860234375 </td><td>0.789045312</td><td> 6</td></tr>
	<tr><td>chr1</td><td>792048</td><td>792328</td><td>0.71824983</td><td>0.6663691667</td><td>0.539856833</td><td>0.59493033</td><td>0.729730833</td><td>0.3479406167 </td><td>0.1348325167  </td><td>0.211454500</td><td>0.5473678333 </td><td>0.414141333</td><td> 4</td></tr>
	<tr><td>chr1</td><td>793394</td><td>794622</td><td>0.63311540</td><td>0.4408846100</td><td>0.370146303</td><td>0.24084614</td><td>0.280130130</td><td>0.2581309133 </td><td>0.2367806133  </td><td>0.148340277</td><td>0.2580932867 </td><td>0.220868420</td><td> 5</td></tr>
	<tr><td>chr1</td><td>796327</td><td>796684</td><td>0.81344136</td><td>0.6741617273</td><td>0.790760454</td><td>0.46009473</td><td>0.553324909</td><td>0.2147925364 </td><td>0.3284043545  </td><td>0.215678082</td><td>0.624842     </td><td>0.413851500</td><td> 4</td></tr>
	<tr><td>chr1</td><td>801044</td><td>801850</td><td>0.77084206</td><td>0.6525558188</td><td>0.320512562</td><td>0.71665419</td><td>0.743482125</td><td>0.9205804375 </td><td>0.9317095625  </td><td>0.917785312</td><td>0.816237125  </td><td>0.424811819</td><td> 8</td></tr>
	<tr><td>chr1</td><td>802921</td><td>805627</td><td>0.26786610</td><td>0.1735855410</td><td>0.190666056</td><td>0.23775954</td><td>0.190173884</td><td>0.2523955176 </td><td>0.1416534643  </td><td>0.165553703</td><td>0.2795565838 </td><td>0.260236800</td><td> 5</td></tr>
	<tr><td>chr1</td><td>807944</td><td>808642</td><td>0.52451921</td><td>0.3533441250</td><td>0.299392500</td><td>0.52793267</td><td>0.643046900</td><td>0.8023708333 </td><td>0.86945       </td><td>0.702309692</td><td>0.7486093333 </td><td>0.714667333</td><td> 8</td></tr>
	<tr><td>chr1</td><td>825900</td><td>826457</td><td>0.74031586</td><td>0.7195342857</td><td>0.745302429</td><td>0.48809014</td><td>0.585794429</td><td>0.2449171    </td><td>0.2508511     </td><td>0.273671929</td><td>0.3617694286 </td><td>0.272097586</td><td> 3</td></tr>
	<tr><td>chr1</td><td>832358</td><td>833525</td><td>0.83288009</td><td>0.5023639545</td><td>0.711337045</td><td>0.55414595</td><td>0.681442955</td><td>0.1868961955 </td><td>0.1755481227  </td><td>0.206087368</td><td>0.4228495818 </td><td>0.213271573</td><td> 3</td></tr>
	<tr><td>chr1</td><td>833571</td><td>834596</td><td>0.67677459</td><td>0.8467650270</td><td>0.866379622</td><td>0.75269762</td><td>0.752095270</td><td>0.5386379919 </td><td>0.4633221432  </td><td>0.404454097</td><td>0.5058361568 </td><td>0.160166454</td><td> 4</td></tr>
	<tr><td>chr1</td><td>839574</td><td>842689</td><td>0.24550987</td><td>0.1703019580</td><td>0.195675906</td><td>0.14910089</td><td>0.181464401</td><td>0.1294420751 </td><td>0.1005630412  </td><td>0.087196896</td><td>0.1766952026 </td><td>0.109505507</td><td> 5</td></tr>
	<tr><td>chr1</td><td>845246</td><td>846919</td><td>0.62214844</td><td>0.1655110925</td><td>0.270567476</td><td>0.17323645</td><td>0.335840014</td><td>0.3702744425 </td><td>0.2727530962  </td><td>0.296061607</td><td>0.2596652047 </td><td>0.323363660</td><td> 5</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrY</td><td>28787456</td><td>28818681</td><td>0.7040317</td><td>0.00000000</td><td>0.61611685</td><td>0.61128174</td><td>0.6116899</td><td>0.5405405405</td><td>0.7043768865</td><td>0.08832764</td><td>0.7110297347</td><td>0.13748153</td><td>1</td></tr>
	<tr><td>chrY</td><td>58819396</td><td>58819937</td><td>0.0000000</td><td>0.00000000</td><td>0.51378127</td><td>0.09871982</td><td>0.4245165</td><td>0.8         </td><td>0.6460839091</td><td>0.00000000</td><td>0.639552    </td><td>0.00000000</td><td>5</td></tr>
	<tr><td>chrY</td><td>58832906</td><td>58834168</td><td>0.2617558</td><td>0.00000000</td><td>0.57997297</td><td>0.30626524</td><td>0.6643658</td><td>0.8571428571</td><td>0.7263844848</td><td>0.03535355</td><td>0.7335832727</td><td>0.03254679</td><td>1</td></tr>
	<tr><td>chrY</td><td>58836666</td><td>58838614</td><td>0.2837900</td><td>0.00000000</td><td>0.64958213</td><td>0.28278905</td><td>0.5777168</td><td>0.75        </td><td>0.7366730556</td><td>0.01906319</td><td>0.7472522778</td><td>0.07263242</td><td>1</td></tr>
	<tr><td>chrY</td><td>58842618</td><td>58844065</td><td>0.4950250</td><td>0.00000000</td><td>0.69687665</td><td>0.44390002</td><td>0.6863997</td><td>0.5         </td><td>0.7516725918</td><td>0.00000000</td><td>0.7944938571</td><td>0.10897437</td><td>1</td></tr>
	<tr><td>chrY</td><td>58845268</td><td>58845402</td><td>0.2065973</td><td>0.00000000</td><td>0.77888675</td><td>0.29840425</td><td>0.7292315</td><td>0           </td><td>0.8446855   </td><td>0.00000000</td><td>0.882609375 </td><td>0.00000000</td><td>1</td></tr>
	<tr><td>chrY</td><td>58854586</td><td>58855892</td><td>0.3269063</td><td>0.00000000</td><td>0.57920409</td><td>0.31713825</td><td>0.5827726</td><td>0.5         </td><td>0.7724402187</td><td>0.00000000</td><td>0.7422971875</td><td>0.03501984</td><td>1</td></tr>
	<tr><td>chrY</td><td>58856263</td><td>58856465</td><td>0.5055407</td><td>0.00000000</td><td>0.61104343</td><td>0.50265700</td><td>0.6239507</td><td>0           </td><td>0.6989298571</td><td>0.14285714</td><td>0.684336    </td><td>0.11190471</td><td>1</td></tr>
	<tr><td>chrY</td><td>58858740</td><td>58859131</td><td>0.0000000</td><td>0.00000000</td><td>0.51131100</td><td>0.00000000</td><td>0.3163727</td><td>0.5         </td><td>0.6129067375</td><td>0.00000000</td><td>0.639508975 </td><td>0.00000000</td><td>5</td></tr>
	<tr><td>chrY</td><td>58862712</td><td>58863851</td><td>0.4975848</td><td>0.00000000</td><td>0.69424251</td><td>0.28469744</td><td>0.5310800</td><td>0.875       </td><td>0.7183297467</td><td>0.05555556</td><td>0.7239896944</td><td>0.09239807</td><td>1</td></tr>
	<tr><td>chrY</td><td>58866276</td><td>58867160</td><td>0.5355928</td><td>0.00000000</td><td>0.71423697</td><td>0.49665079</td><td>0.6369508</td><td>0.75        </td><td>0.7585433793</td><td>0.05172414</td><td>0.7743936897</td><td>0.17676517</td><td>1</td></tr>
	<tr><td>chrY</td><td>58890909</td><td>58892319</td><td>0.2045451</td><td>0.00000000</td><td>0.64852279</td><td>0.18312521</td><td>0.6318099</td><td>0.7777778333</td><td>0.6917824872</td><td>0.00000000</td><td>0.7732882821</td><td>0.05982905</td><td>1</td></tr>
	<tr><td>chrY</td><td>58914771</td><td>58914877</td><td>0.0000000</td><td>0.00000000</td><td>0.71403020</td><td>0.00000000</td><td>0.6666668</td><td>0.2         </td><td>0.789275    </td><td>0.00000000</td><td>0.7697606   </td><td>0.00000000</td><td>5</td></tr>
	<tr><td>chrY</td><td>58968459</td><td>58970307</td><td>0.6075117</td><td>0.36926143</td><td>0.37632167</td><td>0.32992650</td><td>0.3412617</td><td>0.4016652222</td><td>0.4421813333</td><td>0.43937739</td><td>0.4260899722</td><td>0.42498928</td><td>1</td></tr>
	<tr><td>chrY</td><td>58973924</td><td>58975180</td><td>0.6582970</td><td>0.38689352</td><td>0.58008056</td><td>0.56120216</td><td>0.5681711</td><td>0.6572106522</td><td>0.65072276  </td><td>0.51351148</td><td>0.60463292  </td><td>0.50025144</td><td>1</td></tr>
	<tr><td>chrY</td><td>58975712</td><td>58980982</td><td>0.4618227</td><td>0.31316854</td><td>0.38669885</td><td>0.35097478</td><td>0.3797715</td><td>0.484569129 </td><td>0.4840944429</td><td>0.33727042</td><td>0.44638858  </td><td>0.33132444</td><td>1</td></tr>
	<tr><td>chrY</td><td>58981441</td><td>58982549</td><td>0.3029321</td><td>0.15640489</td><td>0.24275352</td><td>0.27330013</td><td>0.2886529</td><td>0.365929    </td><td>0.3261977889</td><td>0.26287741</td><td>0.340142775 </td><td>0.28638547</td><td>5</td></tr>
	<tr><td>chrY</td><td>58984477</td><td>58985363</td><td>0.5362513</td><td>0.42118856</td><td>0.41734111</td><td>0.31944557</td><td>0.3827468</td><td>0.5360422489</td><td>0.4594229444</td><td>0.39448089</td><td>0.4177737111</td><td>0.38845878</td><td>1</td></tr>
	<tr><td>chrY</td><td>58987083</td><td>58987887</td><td>0.3948686</td><td>0.61675425</td><td>0.62448014</td><td>0.38585182</td><td>0.5339708</td><td>0.516896975 </td><td>0.612497125 </td><td>0.19050709</td><td>0.62181725  </td><td>0.19466644</td><td>1</td></tr>
	<tr><td>chrY</td><td>58991998</td><td>58993040</td><td>0.5864938</td><td>0.38876333</td><td>0.45444917</td><td>0.37124632</td><td>0.3710083</td><td>0.4004435858</td><td>0.5084571667</td><td>0.35846272</td><td>0.5087278333</td><td>0.40013417</td><td>1</td></tr>
	<tr><td>chrY</td><td>58997396</td><td>58999154</td><td>0.6277619</td><td>0.44495500</td><td>0.47721244</td><td>0.38642681</td><td>0.3625473</td><td>0.5163198667</td><td>0.5301443   </td><td>0.49006903</td><td>0.5395405222</td><td>0.44335612</td><td>1</td></tr>
	<tr><td>chrY</td><td>59002477</td><td>59004319</td><td>0.6418516</td><td>0.41301489</td><td>0.42571444</td><td>0.36778164</td><td>0.3448534</td><td>0.4659447778</td><td>0.5041747222</td><td>0.51723289</td><td>0.5074499444</td><td>0.43628872</td><td>1</td></tr>
	<tr><td>chrY</td><td>59005151</td><td>59013694</td><td>0.6148867</td><td>0.40645943</td><td>0.42828438</td><td>0.41960972</td><td>0.3951311</td><td>0.5232651321</td><td>0.5442367283</td><td>0.53950653</td><td>0.4946689057</td><td>0.49108202</td><td>1</td></tr>
	<tr><td>chrY</td><td>59013786</td><td>59019076</td><td>0.6482021</td><td>0.41809411</td><td>0.42294166</td><td>0.38842221</td><td>0.3816551</td><td>0.4342907528</td><td>0.5123094444</td><td>0.49753300</td><td>0.4583173361</td><td>0.45147714</td><td>1</td></tr>
	<tr><td>chrY</td><td>59019178</td><td>59020362</td><td>0.5114616</td><td>0.37165036</td><td>0.42042793</td><td>0.34020050</td><td>0.3497128</td><td>0.4424378571</td><td>0.5327088571</td><td>0.50456129</td><td>0.521543    </td><td>0.46513171</td><td>1</td></tr>
	<tr><td>chrY</td><td>59020798</td><td>59024579</td><td>0.6290742</td><td>0.41451610</td><td>0.42311657</td><td>0.38658858</td><td>0.3519685</td><td>0.4437201743</td><td>0.521352587 </td><td>0.46236409</td><td>0.4716031043</td><td>0.45781887</td><td>1</td></tr>
	<tr><td>chrY</td><td>59026116</td><td>59029265</td><td>0.6466637</td><td>0.39776091</td><td>0.44410400</td><td>0.37787075</td><td>0.3818560</td><td>0.4463593067</td><td>0.5610116161</td><td>0.46019416</td><td>0.4790198226</td><td>0.45677087</td><td>1</td></tr>
	<tr><td>chrY</td><td>59030207</td><td>59031692</td><td>0.5777289</td><td>0.55375313</td><td>0.55455107</td><td>0.47728773</td><td>0.4377265</td><td>0.4935677333</td><td>0.6361981333</td><td>0.50531607</td><td>0.6328638667</td><td>0.49314887</td><td>1</td></tr>
	<tr><td>chrY</td><td>59234842</td><td>59236468</td><td>0.0000000</td><td>0.00000000</td><td>0.07142857</td><td>0.00000000</td><td>0.0000000</td><td>1           </td><td>0.5         </td><td>0.00000000</td><td>0.3333333333</td><td>0.00000000</td><td>5</td></tr>
	<tr><td>chrY</td><td>59265980</td><td>59268752</td><td>0.0000000</td><td>0.07142857</td><td>0.10714286</td><td>0.00000000</td><td>0.2500000</td><td>0.5714285714</td><td>0           </td><td>0.00000000</td><td>0.75        </td><td>0.00000000</td><td>5</td></tr>
</tbody>
</table>




```R
# Write output

write_tsv(output_10ct, file="/data/hodges_lab/Tim/MethylationHeatmap_paper/methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt")

write_tsv(output_10ct, file="/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt")
```

## Separate in bash


```R
cd /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/
CLUST_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/

for i in $(seq 1 10)
do
# Use awk to separate out k-means clusters based on 14-th column: clusterID 
awk -v CLUSTNUM=${i} 'BEGIN{OFS=FS="\t"}{if ($14==CLUSTNUM) print $0}' methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt > \
${CLUST_DIR}methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_${i}.txt

# BED version
awk -v CLUSTNUM=${i} 'BEGIN{OFS=FS="\t"}{if ($14==CLUSTNUM) print $1,$2,$3}' methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt > \
${CLUST_DIR}methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_${i}.bed

done

echo "Done."

cd $CLUST_DIR
ls
```

    Done.
    masterHMRs_methMatrix.noCTCFfilter.10ct.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt



```R
cd /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/
ls
head methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt
```

    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt
    chr	start	end	H1ESC	fSpinal	fHeart	Adrenal	Liver	HSPC	Macrophage	Neutrophil	Tcell	Bcell	p_k10_seed86$kmeans$cluster
    chr1	20043	20480	0	0.3986132222	0.758924	0	0	0.8683217778	0.8967626667	0	0.8804616667	0	1
    chr1	28432	30155	0	3.370410853e-4	0.001232707752	0	0.007751937984	0.0079365	0.002717391304	0.006459945736	0.01086956522	0.007751937984	5
    chr1	51441	51734	0.4309162778	0.8629746111	0.9130141111	0.6243886111	0.1238756111	0.7918531111	0.8466523889	0.9675926111	0.8787037222	0.4907407778	9
    chr1	91118	91684	0.30741762	0.23571346	0.24045331	0.16995105	0.0333333	0.13726615	0.27230077	0.2233333	0.2252412	0.2166667	5
    chr1	96558	96806	0.6666666667	0.6592395	0.4992063333	0.2916666667	0	0.84375	0	0	0.6732621667	0.3333333333	1
    chr1	137353	137404	0	0.9381945	0	0	0	0.9583333333	0.861111	0	0.9391535	0	1
    chr1	235927	237877	0.2303665	0.3951615769	0.4366992731	0.2813650385	0.2827484269	0.6262035526	0.5063650167	0.1336004231	0.6000363947	0.1332417308	1
    chr1	241322	243648	0.1899192941	0.3622291765	0.31507	0.2271455294	0.1880142353	0.9375	0.1525632727	0.1448178824	0.5542327778	0.1738905882	5
    chr1	250304	250571	0.7246156	0.8092892	0.7738602	0.7713828	0.627394	0.8387412	0.1794516	0.175	0.6795918	0.5373738	6


# Dendrogram


```R
RNGkind(sample.kind="Rounding")
```

    Warning message in RNGkind(sample.kind = "Rounding"):
    “non-uniform 'Rounding' sampler used”



```R
library("dendextend")
```

    
    ---------------------
    Welcome to dendextend version 1.15.2
    Type citation('dendextend') for how to cite the package.
    
    Type browseVignettes(package = 'dendextend') for the package vignette.
    The github page is: https://github.com/talgalili/dendextend/
    
    Suggestions and bug-reports can be submitted at: https://github.com/talgalili/dendextend/issues
    You may ask questions at stackoverflow, use the r and dendextend tags: 
    	 https://stackoverflow.com/questions/tagged/dendextend
    
    	To suppress this message use:  suppressPackageStartupMessages(library(dendextend))
    ---------------------
    
    
    
    Attaching package: ‘dendextend’
    
    
    The following object is masked from ‘package:stats’:
    
        cutree
    
    


## num matrix


```R
d.meth <- dist(t(methMatrix_noCTCFFilt_10ct_NoNA_nummat)) # , method = "euclidean") #make sure to transpose the matrix, hence the 't' before the data.frame
hcfit <- hclust(d.meth, method="ward.D2")
test <- as.dendrogram(hcfit)

# Call
# test %>% set("branches_k_color", k = 4) %>% 
#  plot(main = "Default colors", horiz=TRUE)


pdf("/data/hodges_lab/Tim/MethylationHeatmap_paper/dendro.seed115.pdf")
p_dendro <- test %>% plot(main = "Default colors", horiz=TRUE)
dev.off()

p_dendro
```


<strong>png:</strong> 2



    NULL


### Different seeds


```R
for (seedNum in 100:110) {
    set.seed(seedNum)
    hc_obj <- hclust(d.meth, method="ward.D2")
    dend_obj <- as.dendrogram(hc_obj)
    dend_obj %>% plot(main = "Default colors", horiz=TRUE)
}
```


![png](output_60_0.png)


## Saved plot


```R
set.seed(110)
hc_obj <- hclust(d.meth, method="ward.D2")
dend_obj <- as.dendrogram(hc_obj)
dend_obj %>% plot(main = "Default colors", horiz=TRUE)

pdf("/data/hodges_lab/Tim/MethylationHeatmap_paper/Dendrogram.setseed110.10ct.pdf")

dend_obj %>% plot(main = "Default colors", horiz=TRUE)

dev.off()
```


<strong>png:</strong> 2



![png](output_62_1.png)



```R
set.seed(120)
hc_obj <- hclust(d.meth, method="ward.D2")
dend_obj <- as.dendrogram(hc_obj)
dend_obj %>% plot(main = "Default colors", horiz=TRUE)
```


![png](output_63_0.png)


## as.matrix()


```R
d.meth <- dist(t(methMatrix_noCTCFFilt_NoNA_mat)) # , method = "euclidean") #make sure to transpose the matrix, hence the 't' before the data.frame
hcfit <- hclust(d.meth, method="ward.D2")
test <- as.dendrogram(hcfit)

# Call
# test %>% set("branches_k_color", k = 4) %>% 
#  plot(main = "Default colors", horiz=TRUE)


#pdf("/data/hodges_lab/Tim/MethylationHeatmap_paper/dendro.seed115.pdf")
p_dendro <- test %>% plot(main = "Default colors", horiz=TRUE)
#dev.off()
p_dendro
```


    Error in t(methMatrix_noCTCFFilt_NoNA_mat): object 'methMatrix_noCTCFFilt_NoNA_mat' not found
    Traceback:


    1. dist(t(methMatrix_noCTCFFilt_NoNA_mat))

    2. as.matrix(x)

    3. t(methMatrix_noCTCFFilt_NoNA_mat)


## data.matrix()


```R
 test %>% plot(main = "Default colors", horiz=TRUE)
```


![png](output_67_0.png)


# DIANA: DIvisive ANAlysis clustering


```R
pdf("/data/hodges_lab/Tim/MethylationHeatmap_paper/MethylationHeatmap_Diana_Diagram.10ct.pdf")
pltree(diana(t(methMatrix_noCTCFFilt_10ct_NoNA_nummat)), cex = 0.6, main = "Dendrogram of diana")
dev.off()

pltree(diana(t(methMatrix_noCTCFFilt_10ct_NoNA_nummat)), cex = 0.6, main = "Dendrogram of diana")
```


<strong>png:</strong> 2



![png](output_69_1.png)



```R
pltree(diana(t(methMatrix_noCTCFFilt_10_ct_NoNA_nummat)), cex = 0.6, hang = -1, main = "Dendrogram of diana")
```


    Error in t(methMatrix_noCTCFFilt_10_ct_NoNA_nummat): object 'methMatrix_noCTCFFilt_10_ct_NoNA_nummat' not found
    Traceback:


    1. pltree(diana(t(methMatrix_noCTCFFilt_10_ct_NoNA_nummat)), cex = 0.6, 
     .     hang = -1, main = "Dendrogram of diana")

    2. diana(t(methMatrix_noCTCFFilt_10_ct_NoNA_nummat))

    3. inherits(x, "dist")

    4. t(methMatrix_noCTCFFilt_10_ct_NoNA_nummat)



```R

```

# HOMER

## Set up 


```R
mkdir -p /data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86/
mkdir -p /data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86/collected_outputs_seed86/
```

## Run via SLRM


```R
# Isolate BED coordinates from all celltypes merged BED file
```


```R
head /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/masterHMRs_methMatrix.noCTCFfilter.10ct.txt
```

    chr1	20043	20480	0	0.3986132222	0.758924	0	0	0.8683217778	0.8967626667	0	0.8804616667	0
    chr1	28432	30155	0	0.0003370410853	0.001232707752	0	0.007751937984	0.0079365	0.002717391304	0.006459945736	0.01086956522	0.007751937984
    chr1	51441	51734	0.4309162778	0.8629746111	0.9130141111	0.6243886111	0.1238756111	0.7918531111	0.8466523889	0.9675926111	0.8787037222	0.4907407778
    chr1	91118	91684	0.30741762	0.23571346	0.24045331	0.16995105	0.0333333	0.13726615	0.27230077	0.2233333	0.2252412	0.2166667
    chr1	96558	96806	0.6666666667	0.6592395	0.4992063333	0.2916666667	0	0.84375	0	0	0.6732621667	0.3333333333
    chr1	137353	137404	0	0.9381945	0	0	0	0.9583333333	0.861111	0	0.9391535	0
    chr1	235927	237877	0.2303665	0.3951615769	0.4366992731	0.2813650385	0.2827484269	0.6262035526	0.5063650167	0.1336004231	0.6000363947	0.1332417308
    chr1	241322	243648	0.1899192941	0.3622291765	0.31507	0.2271455294	0.1880142353	0.9375	0.1525632727	0.1448178824	0.5542327778	0.1738905882
    chr1	250304	250571	0.7246156	0.8092892	0.7738602	0.7713828	0.627394	0.8387412	0.1794516	0.175	0.6795918	0.5373738
    chr1	435874	436666	0	0	0	0	0	0.2	.	0	.	0



```R
awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3}' /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/masterHMRs_methMatrix.noCTCFfilter.10ct.txt > /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/masterHMRs_methMatrix.noCTCFfilter.10ct.txt

awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3}' /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files/masterHMRs_methMatrix.noCTCFfilter.10ct.txt > /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/masterHMRs_methMatrix.noCTCFfilter.10ct.txt

echo "done."
```

    done.



```R
cd /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/
ls
```

    masterHMRs_methMatrix.noCTCFfilter.10ct.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_10.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_2.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_3.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_4.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_5.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_6.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_7.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_8.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.bed
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_9.txt
    methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.txt



```R
# putting .SLRM script in /data/hodges_lab/Tim/MethylationHeatmap_paper
# /data/hodges_lab/Tim/MethylationHeatmap_paper/run_HOMER_TFmotifs_k10_seed86_clusters.slrm
```


```R
#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=30:00:00
#SBATCH --mem=100G
#SBATCH --output=motifs_all_clusters_k10_seed86.Jul15.txt

HM_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/
CLUST_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/
OUT_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86_Jul15/
mkdir -p ${OUT_DIR}

cd ${CLUST_DIR}


# Background of all HMRs
BG_FILE=/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/masterHMRs_methMatrix.noCTCFfilter.10ct.txt

# Run loop 
for NUM in $(seq 1 10)
do
mkdir -p ${OUT_DIR}cluster${NUM}\_10ct_seed86_motifs # Make output folder per cluster
# Run motifs
/data/hodges_lab/bin/HOMERv4.10_5-16-2018/bin/findMotifsGenome.pl ${CLUST_DIR}methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_${NUM}.bed \
hg19 \
${OUT_DIR}cluster${NUM}\_10ct_seed86_motifs -bg ${BG_FILE} -nomotif
done


```


```R
for NUM in $(seq 1 10)
do
wc -l ${CLUST_DIR}methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_${NUM}.bed
done
```


```R
# Test code for singular cluster 1 just to make sure pattern works

/data/hodges_lab/bin/HOMERv4.10_5-16-2018/bin/findMotifsGenome.pl \
/data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/methMatrix_bed_NoNA_NoCTCFFilt_10ct.clusterIDs10_seed86.cluster_1.bed \
hg19 /data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86/test_cluster1_10ct_seed86_motifs -bg /data/hodges_lab/Tim/MethylationHeatmap_paper/mapped_files_seed86/masterHMRs_methMatrix.noCTCFfilter.10ct.txt -nomotif
```


```R
/data/hodges_lab/bin/HOMERv4.10_5-16-2018/bin/findMotifsGenome.pl 
```

    
    	Program will find de novo and known motifs in regions in the genome
    
    	Usage: findMotifsGenome.pl <pos file> <genome> <output directory> [additional options]
    	Example: findMotifsGenome.pl peaks.txt mm8r peakAnalysis -size 200 -len 8
    
    	Possible Genomes:
    		rheMac8	rhesus
    		hg38	human
    		hg19	human
    			-- or --
    		Custom: provide the path to genome FASTA files (directory or single file)
    			Heads up: will create the directory "preparsed/" in same location.
    
    	Basic options:
    		-mask (mask repeats/lower case sequence, can also add 'r' to genome, i.e. mm9r)
    		-bg <background position file> (genomic positions to be used as background, default=automatic)
    			removes background positions overlapping with target positions unless -keepOverlappingBg is used
    			-chopify (chop up large background regions to the avg size of target regions)
    		-len <#>[,<#>,<#>...] (motif length, default=8,10,12) [NOTE: values greater 12 may cause the program
    			to run out of memory - in these cases decrease the number of sequences analyzed (-N),
    			or try analyzing shorter sequence regions (i.e. -size 100)]
    		-size <#> (fragment size to use for motif finding, default=200)
    			-size <#,#> (i.e. -size -100,50 will get sequences from -100 to +50 relative from center)
    			-size given (uses the exact regions you give it)
    		-S <#> (Number of motifs to optimize, default: 25)
    		-mis <#> (global optimization: searches for strings with # mismatches, default: 2)
    		-norevopp (don't search reverse strand for motifs)
    		-nomotif (don't search for de novo motif enrichment)
    		-rna (output RNA motif logos and compare to RNA motif database, automatically sets -norevopp)
    
    	Scanning sequence for motifs
    		-find <motif file> (This will cause the program to only scan for motifs)
    
    	Known Motif Options/Visualization
    		-mset <vertebrates|insects|worms|plants|yeast|all> (check against motif collects, default: auto)
    		-basic (just visualize de novo motifs, don't check similarity with known motifs)
    		-bits (scale sequence logos by information content, default: doesn't scale)
    		-nocheck (don't search for de novo vs. known motif similarity)
    		-mcheck <motif file> (known motifs to check against de novo motifs,
    		-float (allow adjustment of the degeneracy threshold for known motifs to improve p-value[dangerous])
    		-noknown (don't search for known motif enrichment, default: -known)
    		-mknown <motif file> (known motifs to check for enrichment,
    		-nofacts (omit humor)
    		-seqlogo (use weblogo/seqlogo/ghostscript to generate logos, default uses SVG now)
    
    	Sequence normalization options:
    		-gc (use GC% for sequence content normalization, now the default)
    		-cpg (use CpG% instead of GC% for sequence content normalization)
    		-noweight (no CG correction)
    		Also -nlen <#>, -olen <#>, see homer2 section below.
    
    	Advanced options:
    		-h (use hypergeometric for p-values, binomial is default)
    		-N <#> (Number of sequences to use for motif finding, default=max(50k, 2x input)
    		-local <#> (use local background, # of equal size regions around peaks to use i.e. 2)
    		-redundant <#> (Remove redundant sequences matching greater than # percent, i.e. -redundant 0.5)
    		-maxN <#> (maximum percentage of N's in sequence to consider for motif finding, default: 0.7)
    		-maskMotif <motif file1> [motif file 2]... (motifs to mask before motif finding)
    		-opt <motif file1> [motif file 2]... (motifs to optimize or change length of)
    		-rand (randomize target and background sequences labels)
    		-ref <peak file> (use file for target and background - first argument is list of peak ids for targets)
    		-oligo (perform analysis of individual oligo enrichment)
    		-dumpFasta (Dump fasta files for target and background sequences for use with other programs)
    		-preparse (force new background files to be created)
    		-preparsedDir <directory> (location to search for preparsed file and/or place new files)
    		-keepFiles (keep temporary files)
    		-fdr <#> (Calculate empirical FDR for de novo discovery #=number of randomizations)
    
    	homer2 specific options:
    		-homer2 (use homer2 instead of original homer, default)
    		-nlen <#> (length of lower-order oligos to normalize in background, default: -nlen 3)
    			-nmax <#> (Max normalization iterations, default: 160)
    			-neutral (weight sequences to neutral frequencies, i.e. 25%, 6.25%, etc.)
    		-olen <#> (lower-order oligo normalization for oligo table, use if -nlen isn't working well)
    		-p <#> (Number of processors to use, default: 1)
    		-e <#> (Maximum expected motif instance per bp in random sequence, default: 0.01)
    		-cache <#> (size in MB for statistics cache, default: 500)
    		-quickMask (skip full masking after finding motifs, similar to original homer)
    		-minlp <#> (stop looking for motifs when seed logp score gets above #, default: -10)
    
    	Original homer specific options:
    		-homer1 (to force the use of the original homer)
    		-depth [low|med|high|allnight] (time spent on local optimization default: med)
    



```R
#!/bin/bash
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=20:00:00
#SBATCH --mem=100G
#SBATCH --output=motifs_all.txt

cd /scratch/scottt7/paper_wases/HMRs/


#clusmemtf.liver.sh
for i in Adrenal Bcell fSpinal Liver H1ESC Rvent
do
	/data/hodges_lab/bin/Homer/bin/findMotifsGenome.pl ${i}_internalClusters_individualHMRs_cellspecific.txt hg19 /scratch/scottt7/paper_wases/HMRs/${i}.motifs
done
```


```R

```

## Bash: clean and subset


```R
# Make a collection folder for HOMER results
OUT_DIR=/data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86_Jul15/collected_outputs_seed86/
mkdir -p $OUT_DIR
```


```R
for i in $(seq 1 10)
do
# Find file within the appropriate sub-folder that was made per-cluster group and move it to OUT, renaming it so they aren't all named the same "knownResults.txt"
cp /data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86_Jul15/cluster${i}_10ct_seed86_motifs/knownResults.txt \
${OUT_DIR}knownResults.cluster_${i}.txt

# Report
echo "Moved: " knownResults.cluster_${i}.txt
done

```

    Moved:  knownResults.cluster_1.txt
    Moved:  knownResults.cluster_2.txt
    Moved:  knownResults.cluster_3.txt
    Moved:  knownResults.cluster_4.txt
    Moved:  knownResults.cluster_5.txt
    Moved:  knownResults.cluster_6.txt
    Moved:  knownResults.cluster_7.txt
    Moved:  knownResults.cluster_8.txt
    Moved:  knownResults.cluster_9.txt
    Moved:  knownResults.cluster_10.txt


## R: Load libraries


```R
library(tidyverse)
library(ggplot2)
library(RColorBrewer)
library(pheatmap)
library(data.table) # for rbindlist

print("Libraries loaded.")
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    
    
    Attaching package: ‘data.table’
    
    
    The following objects are masked from ‘package:dplyr’:
    
        between, first, last
    
    
    The following object is masked from ‘package:purrr’:
    
        transpose
    
    


    [1] "Libraries loaded."


## Load data


```R
setwd("/data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86_Jul15/collected_outputs_seed86/")

HEADER_NAMES=c("MotifName","Consensus","p","logp","q","numTarget","percentTarget","numBackground","percentBackground")

# Get the shorter versions of motif names
lofn <- list.files()
lofn_clean_tmp <- map(lofn, ~sub("knownResults.", "", .))
lofn_clean <- map(lofn_clean_tmp, ~sub(".txt", "", .))

# Read in the data and name each element in the list (cluster-specific results dataframe)
lof <- map(lofn, ~read_tsv(., col_names = HEADER_NAMES, skip = 1))
names(lof) <- lofn_clean
lof_shortNames <- map(lof, ~mutate(., MotifNameShort = sub("\\(.*", "", .$MotifName)))
lof_shortNames

# Combine from list to a Df, while adding a cluster ID column
df_all_bind <- rbindlist(lof_shortNames, idcol="clusterID")
df_all_bind$clusterID = factor(df_all_bind$clusterID, levels = rev(c("cluster_3","cluster_5","cluster_6","cluster_7","cluster_8","cluster_9","cluster_10","cluster_1","cluster_2","cluster_4")))
```

    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m428[39m [1mColumns: [22m[34m9[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (4): MotifName, Consensus, percentTarget, percentBackground
    [32mdbl[39m (5): p, logp, q, numTarget, numBackground
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



<dl>
	<dt>$cluster_1</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer                      </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1e-38</td><td>-88.470</td><td>0.0000</td><td>1115</td><td>4.97% </td><td> 3430.9</td><td>3.30% </td><td>CTCF                             </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer                         </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1e-36</td><td>-85.010</td><td>0.0000</td><td>1286</td><td>5.74% </td><td> 4116.0</td><td>3.96% </td><td>BORIS                            </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer                          </td><td>AGGVNCCTTTGT        </td><td>1e-14</td><td>-32.760</td><td>0.0000</td><td>2324</td><td>10.37%</td><td> 9205.8</td><td>8.87% </td><td>Sox9                             </td></tr>
	<tr><td>STAT5(Stat)/mCD4+-Stat5-ChIP-Seq(GSE12346)/Homer                      </td><td>RTTTCTNAGAAA        </td><td>1e-11</td><td>-25.330</td><td>0.0000</td><td>1005</td><td>4.48% </td><td> 3754.5</td><td>3.62% </td><td>STAT5                            </td></tr>
	<tr><td>LEF1(HMG)/H1-LEF1-ChIP-Seq(GSE64758)/Homer                            </td><td>CCTTTGATST          </td><td>1e-10</td><td>-24.750</td><td>0.0000</td><td>1938</td><td>8.65% </td><td> 7741.7</td><td>7.46% </td><td>LEF1                             </td></tr>
	<tr><td>REST-NRSF(Zf)/Jurkat-NRSF-ChIP-Seq/Homer                              </td><td>GGMGCTGTCCATGGTGCTGA</td><td>1e-10</td><td>-23.700</td><td>0.0000</td><td>  69</td><td>0.31% </td><td>  130.9</td><td>0.13% </td><td>REST-NRSF                        </td></tr>
	<tr><td>ZNF692(Zf)/HEK293-ZNF692.GFP-ChIP-Seq(GSE58341)/Homer                 </td><td>GTGGGCCCCA          </td><td>1e-09</td><td>-22.250</td><td>0.0000</td><td> 502</td><td>2.24% </td><td> 1740.7</td><td>1.68% </td><td>ZNF692                           </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer                 </td><td>CCWTTGTYYB          </td><td>1e-09</td><td>-20.840</td><td>0.0000</td><td>4236</td><td>18.90%</td><td>18022.2</td><td>17.36%</td><td>Sox10                            </td></tr>
	<tr><td>DMRT6(DM)/Testis-DMRT6-ChIP-Seq(GSE60440)/Homer                       </td><td>YDGHTACAWTGTADC     </td><td>1e-08</td><td>-20.580</td><td>0.0000</td><td> 473</td><td>2.11% </td><td> 1646.0</td><td>1.59% </td><td>DMRT6                            </td></tr>
	<tr><td>ZNF652/HepG2-ZNF652.Flag-ChIP-Seq(Encode)/Homer                       </td><td>TTAACCCTTTVNKKN     </td><td>1e-08</td><td>-20.410</td><td>0.0000</td><td> 720</td><td>3.21% </td><td> 2657.2</td><td>2.56% </td><td>ZNF652/HepG2-ZNF652.Flag-ChIP-Seq</td></tr>
	<tr><td>Sp2(Zf)/HEK293-Sp2.eGFP-ChIP-Seq(Encode)/Homer                        </td><td>YGGCCCCGCCCC        </td><td>1e-08</td><td>-19.010</td><td>0.0000</td><td>3980</td><td>17.76%</td><td>16953.9</td><td>16.33%</td><td>Sp2                              </td></tr>
	<tr><td>DMRT1(DM)/Testis-DMRT1-ChIP-Seq(GSE64892)/Homer                       </td><td>TWGHWACAWTGTWDC     </td><td>1e-08</td><td>-18.970</td><td>0.0000</td><td> 581</td><td>2.59% </td><td> 2108.7</td><td>2.03% </td><td>DMRT1                            </td></tr>
	<tr><td>Tbr1(T-box)/Cortex-Tbr1-ChIP-Seq(GSE71384)/Homer                      </td><td>AAGGTGTKAA          </td><td>1e-08</td><td>-18.960</td><td>0.0000</td><td>3453</td><td>15.41%</td><td>14601.0</td><td>14.06%</td><td>Tbr1                             </td></tr>
	<tr><td>Zic3(Zf)/mES-Zic3-ChIP-Seq(GSE37889)/Homer                            </td><td>GGCCYCCTGCTGDGH     </td><td>1e-07</td><td>-18.350</td><td>0.0000</td><td>1892</td><td>8.44% </td><td> 7723.4</td><td>7.44% </td><td>Zic3                             </td></tr>
	<tr><td>Tbox:Smad(T-box,MAD)/ESCd5-Smad2_3-ChIP-Seq(GSE29422)/Homer           </td><td>AGGTGHCAGACA        </td><td>1e-07</td><td>-16.850</td><td>0.0000</td><td> 513</td><td>2.29% </td><td> 1863.5</td><td>1.79% </td><td>Tbox:Smad                        </td></tr>
	<tr><td>KLF14(Zf)/HEK293-KLF14.GFP-ChIP-Seq(GSE58341)/Homer                   </td><td>RGKGGGCGKGGC        </td><td>1e-07</td><td>-16.190</td><td>0.0000</td><td>4691</td><td>20.93%</td><td>20282.5</td><td>19.54%</td><td>KLF14                            </td></tr>
	<tr><td>STAT6(Stat)/Macrophage-Stat6-ChIP-Seq(GSE38377)/Homer                 </td><td>TTCCKNAGAA          </td><td>1e-06</td><td>-16.060</td><td>0.0000</td><td>1453</td><td>6.48% </td><td> 5880.0</td><td>5.66% </td><td>STAT6                            </td></tr>
	<tr><td>Sp5(Zf)/mES-Sp5.Flag-ChIP-Seq(GSE72989)/Homer                         </td><td>RGKGGGCGGAGC        </td><td>1e-06</td><td>-15.580</td><td>0.0000</td><td>2675</td><td>11.94%</td><td>11274.5</td><td>10.86%</td><td>Sp5                              </td></tr>
	<tr><td>Zfp281(Zf)/ES-Zfp281-ChIP-Seq(GSE81042)/Homer                         </td><td>CCCCTCCCCCAC        </td><td>1e-06</td><td>-13.820</td><td>0.0000</td><td> 674</td><td>3.01% </td><td> 2591.0</td><td>2.50% </td><td>Zfp281                           </td></tr>
	<tr><td>FOXP1(Forkhead)/H9-FOXP1-ChIP-Seq(GSE31006)/Homer                     </td><td>NYYTGTTTACHN        </td><td>1e-05</td><td>-12.980</td><td>0.0000</td><td>1249</td><td>5.57% </td><td> 5084.9</td><td>4.90% </td><td>FOXP1                            </td></tr>
	<tr><td>Foxo3(Forkhead)/U2OS-Foxo3-ChIP-Seq(E-MTAB-2701)/Homer                </td><td>DGTAAACA            </td><td>1e-04</td><td>-11.010</td><td>0.0003</td><td>2105</td><td>9.39% </td><td> 8931.7</td><td>8.60% </td><td>Foxo3                            </td></tr>
	<tr><td>FOXA1(Forkhead)/LNCAP-FOXA1-ChIP-Seq(GSE27824)/Homer                  </td><td>WAAGTAAACA          </td><td>1e-04</td><td> -9.928</td><td>0.0009</td><td>3379</td><td>15.08%</td><td>14700.3</td><td>14.16%</td><td>FOXA1                            </td></tr>
	<tr><td>Fox:Ebox(Forkhead,bHLH)/Panc1-Foxa2-ChIP-Seq(GSE47459)/Homer          </td><td>NNNVCTGWGYAAACASN   </td><td>1e-04</td><td> -9.374</td><td>0.0016</td><td>2492</td><td>11.12%</td><td>10739.9</td><td>10.34%</td><td>Fox:Ebox                         </td></tr>
	<tr><td>FoxD3(forkhead)/ZebrafishEmbryo-Foxd3.biotin-ChIP-seq(GSE106676)/Homer</td><td>TGTTTAYTTAGC        </td><td>1e-04</td><td> -9.366</td><td>0.0016</td><td>2392</td><td>10.67%</td><td>10291.2</td><td>9.91% </td><td>FoxD3                            </td></tr>
	<tr><td>NFAT(RHD)/Jurkat-NFATC1-ChIP-Seq(Jolma_et_al.)/Homer                  </td><td>ATTTTCCATT          </td><td>1e-04</td><td> -9.265</td><td>0.0016</td><td>2298</td><td>10.25%</td><td> 9875.6</td><td>9.51% </td><td>NFAT                             </td></tr>
	<tr><td>Foxa2(Forkhead)/Liver-Foxa2-ChIP-Seq(GSE25694)/Homer                  </td><td>CYTGTTTACWYW        </td><td>1e-03</td><td> -9.011</td><td>0.0020</td><td>2120</td><td>9.46% </td><td> 9091.2</td><td>8.76% </td><td>Foxa2                            </td></tr>
	<tr><td>Foxh1(Forkhead)/hESC-FOXH1-ChIP-Seq(GSE29422)/Homer                   </td><td>NNTGTGGATTSS        </td><td>1e-03</td><td> -8.972</td><td>0.0020</td><td>1464</td><td>6.53% </td><td> 6171.7</td><td>5.94% </td><td>Foxh1                            </td></tr>
	<tr><td>STAT4(Stat)/CD4-Stat4-ChIP-Seq(GSE22104)/Homer                        </td><td>NYTTCCWGGAAR        </td><td>1e-03</td><td> -8.795</td><td>0.0023</td><td>2547</td><td>11.36%</td><td>11017.9</td><td>10.61%</td><td>STAT4                            </td></tr>
	<tr><td>PRDM9(Zf)/Testis-DMC1-ChIP-Seq(GSE35498)/Homer                        </td><td>ADGGYAGYAGCATCT     </td><td>1e-03</td><td> -8.546</td><td>0.0029</td><td>1012</td><td>4.52% </td><td> 4193.8</td><td>4.04% </td><td>PRDM9                            </td></tr>
	<tr><td>p53(p53)/mES-cMyc-ChIP-Seq(GSE11431)/Homer                            </td><td>ACATGCCCGGGCAT      </td><td>1e-03</td><td> -8.484</td><td>0.0030</td><td>  83</td><td>0.37% </td><td>  253.4</td><td>0.24% </td><td>p53                              </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                     </td><td>AVCAGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>3630</td><td>16.20%</td><td>20378.9</td><td>19.63%</td><td>EHF            </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer                </td><td>AVCCGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>1002</td><td>4.47% </td><td> 6402.7</td><td>6.17% </td><td>ELF1           </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                   </td><td>ANCAGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>2145</td><td>9.57% </td><td>12395.0</td><td>11.94%</td><td>ELF3           </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                   </td><td>ACTTCCKGKT     </td><td>1</td><td>0</td><td>1</td><td>2545</td><td>11.36%</td><td>16275.1</td><td>15.68%</td><td>Elf4           </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                   </td><td>ACVAGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>2058</td><td>9.18% </td><td>12127.6</td><td>11.68%</td><td>ELF5           </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY     </td><td>1</td><td>0</td><td>1</td><td>1068</td><td>4.77% </td><td> 6657.5</td><td>6.41% </td><td>Elk1           </td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY     </td><td>1</td><td>0</td><td>1</td><td>1049</td><td>4.68% </td><td> 6567.2</td><td>6.33% </td><td>Elk4           </td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG     </td><td>1</td><td>0</td><td>1</td><td>4515</td><td>20.14%</td><td>25640.0</td><td>24.70%</td><td>ERG            </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG     </td><td>1</td><td>0</td><td>1</td><td>2622</td><td>11.70%</td><td>17041.2</td><td>16.41%</td><td>ETS1           </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT     </td><td>1</td><td>0</td><td>1</td><td> 803</td><td>3.58% </td><td> 5784.5</td><td>5.57% </td><td>Ets1-distal    </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                        </td><td>AACCGGAAGT     </td><td>1</td><td>0</td><td>1</td><td> 605</td><td>2.70% </td><td> 4174.6</td><td>4.02% </td><td>ETS            </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT   </td><td>1</td><td>0</td><td>1</td><td> 200</td><td>0.89% </td><td> 1743.7</td><td>1.68% </td><td>ETS:RUNX       </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>3414</td><td>15.23%</td><td>21154.7</td><td>20.38%</td><td>ETV1           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN   </td><td>1</td><td>0</td><td>1</td><td>2702</td><td>12.06%</td><td>16257.9</td><td>15.66%</td><td>Etv2           </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG     </td><td>1</td><td>0</td><td>1</td><td>2558</td><td>11.41%</td><td>16309.9</td><td>15.71%</td><td>ETV4           </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN     </td><td>1</td><td>0</td><td>1</td><td>2268</td><td>10.12%</td><td>13102.6</td><td>12.62%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT     </td><td>1</td><td>0</td><td>1</td><td>1452</td><td>6.48% </td><td> 9347.3</td><td>9.00% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH     </td><td>1</td><td>0</td><td>1</td><td>2720</td><td>12.14%</td><td>17366.6</td><td>16.73%</td><td>Fli1           </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer               </td><td>RACCGGAAGT     </td><td>1</td><td>0</td><td>1</td><td>2110</td><td>9.41% </td><td>13747.4</td><td>13.24%</td><td>GABPA          </td></tr>
	<tr><td>IRF3(IRF)/BMDM-Irf3-ChIP-Seq(GSE67343)/Homer                   </td><td>AGTTTCAKTTTC   </td><td>1</td><td>0</td><td>1</td><td> 741</td><td>3.31% </td><td> 4859.9</td><td>4.68% </td><td>IRF3           </td></tr>
	<tr><td>IRF8(IRF)/BMDM-IRF8-ChIP-Seq(GSE77884)/Homer                   </td><td>GRAASTGAAAST   </td><td>1</td><td>0</td><td>1</td><td> 734</td><td>3.27% </td><td> 4894.7</td><td>4.71% </td><td>IRF8           </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer                 </td><td>VTTACGTAAYNNNNN</td><td>1</td><td>0</td><td>1</td><td>1432</td><td>6.39% </td><td> 8254.5</td><td>7.95% </td><td>NFIL3          </td></tr>
	<tr><td>PU.1:IRF8(ETS:IRF)/pDC-Irf8-ChIP-Seq(GSE66899)/Homer           </td><td>GGAAGTGAAAST   </td><td>1</td><td>0</td><td>1</td><td> 430</td><td>1.92% </td><td> 3194.0</td><td>3.08% </td><td>PU.1:IRF8      </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer          </td><td>MGGAAGTGAAAC   </td><td>1</td><td>0</td><td>1</td><td>3303</td><td>14.74%</td><td>18116.7</td><td>17.45%</td><td>PU.1-IRF       </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer                </td><td>AGAGGAAGTG     </td><td>1</td><td>0</td><td>1</td><td>1227</td><td>5.47% </td><td> 9110.0</td><td>8.77% </td><td>PU.1           </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG     </td><td>1</td><td>0</td><td>1</td><td>1537</td><td>6.86% </td><td> 9334.6</td><td>8.99% </td><td>RUNX           </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM     </td><td>1</td><td>0</td><td>1</td><td>2279</td><td>10.17%</td><td>13425.5</td><td>12.93%</td><td>RUNX1          </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                 </td><td>NWAACCACADNN   </td><td>1</td><td>0</td><td>1</td><td>1905</td><td>8.50% </td><td>10758.2</td><td>10.36%</td><td>RUNX2          </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer                </td><td>ASWTCCTGBT     </td><td>1</td><td>0</td><td>1</td><td>2361</td><td>10.53%</td><td>13254.7</td><td>12.77%</td><td>SPDEF          </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer                 </td><td>AAAGRGGAAGTG   </td><td>1</td><td>0</td><td>1</td><td> 605</td><td>2.70% </td><td> 4876.1</td><td>4.70% </td><td>SpiB           </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_10</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>OCT4-SOX2-TCF-NANOG(POU,Homeobox,HMG)/mES-Oct4-ChIP-Seq(GSE11431)/Homer</td><td>ATTTGCATAACAATG</td><td>1e-157</td><td>-361.90</td><td>0</td><td> 450</td><td>8.85% </td><td> 2186.0</td><td>1.87% </td><td>OCT4-SOX2-TCF-NANOG</td></tr>
	<tr><td>Oct4(POU,Homeobox)/mES-Oct4-ChIP-Seq(GSE11431)/Homer                   </td><td>ATTTGCATAW     </td><td> 1e-67</td><td>-154.80</td><td>0</td><td> 556</td><td>10.93%</td><td> 5701.8</td><td>4.87% </td><td>Oct4               </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer                            </td><td>CCWTTGTY       </td><td> 1e-52</td><td>-121.00</td><td>0</td><td>1311</td><td>25.77%</td><td>20138.1</td><td>17.20%</td><td>Sox3               </td></tr>
	<tr><td>Oct6(POU,Homeobox)/NPC-Pou3f1-ChIP-Seq(GSE35496)/Homer                 </td><td>WATGCAAATGAG   </td><td> 1e-52</td><td>-120.20</td><td>0</td><td> 472</td><td>9.28% </td><td> 5029.7</td><td>4.29% </td><td>Oct6               </td></tr>
	<tr><td>Brn1(POU,Homeobox)/NPC-Brn1-ChIP-Seq(GSE35496)/Homer                   </td><td>TATGCWAATBAV   </td><td> 1e-48</td><td>-112.20</td><td>0</td><td> 378</td><td>7.43% </td><td> 3733.7</td><td>3.19% </td><td>Brn1               </td></tr>
	<tr><td>Sp5(Zf)/mES-Sp5.Flag-ChIP-Seq(GSE72989)/Homer                          </td><td>RGKGGGCGGAGC   </td><td> 1e-48</td><td>-110.90</td><td>0</td><td>1086</td><td>21.35%</td><td>16149.1</td><td>13.79%</td><td>Sp5                </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer                         </td><td>CYRCATTCCA     </td><td> 1e-46</td><td>-107.40</td><td>0</td><td> 802</td><td>15.77%</td><td>10964.4</td><td>9.36% </td><td>TEAD1              </td></tr>
	<tr><td>Sox15(HMG)/CPA-Sox15-ChIP-Seq(GSE62909)/Homer                          </td><td>RAACAATGGN     </td><td> 1e-44</td><td>-101.90</td><td>0</td><td> 907</td><td>17.83%</td><td>13075.8</td><td>11.17%</td><td>Sox15              </td></tr>
	<tr><td>Sp1(Zf)/Promoter/Homer                                                 </td><td>GGCCCCGCCCCC   </td><td> 1e-42</td><td> -97.00</td><td>0</td><td> 386</td><td>7.59% </td><td> 4128.0</td><td>3.52% </td><td>Sp1                </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer                  </td><td>CCWTTGTYYB     </td><td> 1e-38</td><td> -88.30</td><td>0</td><td>1171</td><td>23.02%</td><td>18704.9</td><td>15.97%</td><td>Sox10              </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer                   </td><td>CCWGGAATGY     </td><td> 1e-36</td><td> -83.05</td><td>0</td><td> 681</td><td>13.39%</td><td> 9528.7</td><td>8.14% </td><td>TEAD4              </td></tr>
	<tr><td>TEAD2(TEA)/Py2T-Tead2-ChIP-Seq(GSE55709)/Homer                         </td><td>CCWGGAATGY     </td><td> 1e-35</td><td> -82.07</td><td>0</td><td> 460</td><td>9.04% </td><td> 5660.9</td><td>4.83% </td><td>TEAD2              </td></tr>
	<tr><td>TEAD(TEA)/Fibroblast-PU.1-ChIP-Seq(Unpublished)/Homer                  </td><td>YCWGGAATGY     </td><td> 1e-35</td><td> -81.71</td><td>0</td><td> 570</td><td>11.21%</td><td> 7574.1</td><td>6.47% </td><td>TEAD               </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer                          </td><td>TRCATTCCAG     </td><td> 1e-34</td><td> -79.69</td><td>0</td><td> 841</td><td>16.53%</td><td>12633.9</td><td>10.79%</td><td>TEAD3              </td></tr>
	<tr><td>p53(p53)/mES-cMyc-ChIP-Seq(GSE11431)/Homer                             </td><td>ACATGCCCGGGCAT </td><td> 1e-33</td><td> -77.71</td><td>0</td><td>  78</td><td>1.53% </td><td>  301.3</td><td>0.26% </td><td>p53                </td></tr>
	<tr><td>KLF14(Zf)/HEK293-KLF14.GFP-ChIP-Seq(GSE58341)/Homer                    </td><td>RGKGGGCGKGGC   </td><td> 1e-31</td><td> -72.79</td><td>0</td><td>1565</td><td>30.76%</td><td>27554.0</td><td>23.53%</td><td>KLF14              </td></tr>
	<tr><td>Sp2(Zf)/HEK293-Sp2.eGFP-ChIP-Seq(Encode)/Homer                         </td><td>YGGCCCCGCCCC   </td><td> 1e-31</td><td> -72.72</td><td>0</td><td>1353</td><td>26.60%</td><td>23141.0</td><td>19.76%</td><td>Sp2                </td></tr>
	<tr><td>Oct11(POU,Homeobox)/NCIH1048-POU2F3-ChIP-seq(GSE115123)/Homer          </td><td>GATTTGCATA     </td><td> 1e-29</td><td> -68.74</td><td>0</td><td> 330</td><td>6.49% </td><td> 3819.2</td><td>3.26% </td><td>Oct11              </td></tr>
	<tr><td>Oct2(POU,Homeobox)/Bcell-Oct2-ChIP-Seq(GSE21512)/Homer                 </td><td>ATATGCAAAT     </td><td> 1e-25</td><td> -57.83</td><td>0</td><td> 306</td><td>6.02% </td><td> 3679.0</td><td>3.14% </td><td>Oct2               </td></tr>
	<tr><td>Zic(Zf)/Cerebellum-ZIC1.2-ChIP-Seq(GSE60731)/Homer                     </td><td>CCTGCTGAGH     </td><td> 1e-23</td><td> -54.83</td><td>0</td><td> 660</td><td>12.97%</td><td>10178.3</td><td>8.69% </td><td>Zic                </td></tr>
	<tr><td>KLF3(Zf)/MEF-Klf3-ChIP-Seq(GSE44748)/Homer                             </td><td>NRGCCCCRCCCHBNN</td><td> 1e-22</td><td> -52.06</td><td>0</td><td> 475</td><td>9.34% </td><td> 6815.8</td><td>5.82% </td><td>KLF3               </td></tr>
	<tr><td>Sox4(HMG)/proB-Sox4-ChIP-Seq(GSE50066)/Homer                           </td><td>YCTTTGTTCC     </td><td> 1e-22</td><td> -51.65</td><td>0</td><td> 630</td><td>12.38%</td><td> 9739.9</td><td>8.32% </td><td>Sox4               </td></tr>
	<tr><td>Sox6(HMG)/Myotubes-Sox6-ChIP-Seq(GSE32627)/Homer                       </td><td>CCATTGTTNY     </td><td> 1e-19</td><td> -44.77</td><td>0</td><td>1032</td><td>20.29%</td><td>18121.5</td><td>15.47%</td><td>Sox6               </td></tr>
	<tr><td>KLF5(Zf)/LoVo-KLF5-ChIP-Seq(GSE49402)/Homer                            </td><td>DGGGYGKGGC     </td><td> 1e-18</td><td> -42.66</td><td>0</td><td>1060</td><td>20.84%</td><td>18834.2</td><td>16.08%</td><td>KLF5               </td></tr>
	<tr><td>Zfp281(Zf)/ES-Zfp281-ChIP-Seq(GSE81042)/Homer                          </td><td>CCCCTCCCCCAC   </td><td> 1e-18</td><td> -42.20</td><td>0</td><td> 275</td><td>5.41% </td><td> 3564.2</td><td>3.04% </td><td>Zfp281             </td></tr>
	<tr><td>FOXP1(Forkhead)/H9-FOXP1-ChIP-Seq(GSE31006)/Homer                      </td><td>NYYTGTTTACHN   </td><td> 1e-17</td><td> -39.85</td><td>0</td><td> 372</td><td>7.31% </td><td> 5368.2</td><td>4.58% </td><td>FOXP1              </td></tr>
	<tr><td>Tbox:Smad(T-box,MAD)/ESCd5-Smad2_3-ChIP-Seq(GSE29422)/Homer            </td><td>AGGTGHCAGACA   </td><td> 1e-17</td><td> -39.24</td><td>0</td><td> 173</td><td>3.40% </td><td> 1943.0</td><td>1.66% </td><td>Tbox:Smad          </td></tr>
	<tr><td>Sox2(HMG)/mES-Sox2-ChIP-Seq(GSE11431)/Homer                            </td><td>BCCATTGTTC     </td><td> 1e-15</td><td> -35.86</td><td>0</td><td> 602</td><td>11.83%</td><td> 9942.8</td><td>8.49% </td><td>Sox2               </td></tr>
	<tr><td>GLIS3(Zf)/Thyroid-Glis3.GFP-ChIP-Seq(GSE103297)/Homer                  </td><td>CTCCCTGGGAGGCCN</td><td> 1e-15</td><td> -35.13</td><td>0</td><td>1318</td><td>25.91%</td><td>24820.0</td><td>21.19%</td><td>GLIS3              </td></tr>
	<tr><td>FOXK2(Forkhead)/U2OS-FOXK2-ChIP-Seq(E-MTAB-2204)/Homer                 </td><td>SCHTGTTTACAT   </td><td> 1e-14</td><td> -34.26</td><td>0</td><td> 479</td><td>9.42% </td><td> 7618.8</td><td>6.51% </td><td>FOXK2              </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY          </td><td>1</td><td>0</td><td>1</td><td>227</td><td>4.46% </td><td> 7719.3</td><td>6.59% </td><td>Elk4           </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer                </td><td>ASWTCCTGBT          </td><td>1</td><td>0</td><td>1</td><td>461</td><td>9.06% </td><td>13947.6</td><td>11.91%</td><td>SPDEF          </td></tr>
	<tr><td>Mef2d(MADS)/Retina-Mef2d-ChIP-Seq(GSE61391)/Homer              </td><td>GCTATTTTTAGC        </td><td>1</td><td>0</td><td>1</td><td> 71</td><td>1.40% </td><td> 3254.3</td><td>2.78% </td><td>Mef2d          </td></tr>
	<tr><td>AP-2gamma(AP2)/MCF7-TFAP2C-ChIP-Seq(GSE21234)/Homer            </td><td>SCCTSAGGSCAW        </td><td>1</td><td>0</td><td>1</td><td>512</td><td>10.06%</td><td>15347.9</td><td>13.11%</td><td>AP-2gamma      </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT        </td><td>1</td><td>0</td><td>1</td><td> 26</td><td>0.51% </td><td> 1759.3</td><td>1.50% </td><td>ETS:RUNX       </td></tr>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer               </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1</td><td>0</td><td>1</td><td>114</td><td>2.24% </td><td> 5092.4</td><td>4.35% </td><td>CTCF           </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                        </td><td>AACCGGAAGT          </td><td>1</td><td>0</td><td>1</td><td> 99</td><td>1.95% </td><td> 4673.5</td><td>3.99% </td><td>ETS            </td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                     </td><td>AVCAGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>617</td><td>12.13%</td><td>21431.0</td><td>18.30%</td><td>EHF            </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer                </td><td>AVCCGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>173</td><td>3.40% </td><td> 7459.2</td><td>6.37% </td><td>ELF1           </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                   </td><td>ANCAGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>303</td><td>5.96% </td><td>12857.6</td><td>10.98%</td><td>ELF3           </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                   </td><td>ACTTCCKGKT          </td><td>1</td><td>0</td><td>1</td><td>445</td><td>8.75% </td><td>17273.3</td><td>14.75%</td><td>Elf4           </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                   </td><td>ACVAGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>317</td><td>6.23% </td><td>12811.1</td><td>10.94%</td><td>ELF5           </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY          </td><td>1</td><td>0</td><td>1</td><td>198</td><td>3.89% </td><td> 7867.7</td><td>6.72% </td><td>Elk1           </td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG          </td><td>1</td><td>0</td><td>1</td><td>780</td><td>15.33%</td><td>27267.1</td><td>23.28%</td><td>ERG            </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG          </td><td>1</td><td>0</td><td>1</td><td>424</td><td>8.33% </td><td>17925.5</td><td>15.31%</td><td>ETS1           </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>108</td><td>2.12% </td><td> 5693.1</td><td>4.86% </td><td>Ets1-distal    </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>662</td><td>13.01%</td><td>22780.3</td><td>19.45%</td><td>ETV1           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN        </td><td>1</td><td>0</td><td>1</td><td>385</td><td>7.57% </td><td>17085.8</td><td>14.59%</td><td>Etv2           </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG          </td><td>1</td><td>0</td><td>1</td><td>469</td><td>9.22% </td><td>18040.3</td><td>15.40%</td><td>ETV4           </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN          </td><td>1</td><td>0</td><td>1</td><td>353</td><td>6.94% </td><td>13345.0</td><td>11.40%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT          </td><td>1</td><td>0</td><td>1</td><td>220</td><td>4.32% </td><td> 9756.0</td><td>8.33% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH          </td><td>1</td><td>0</td><td>1</td><td>480</td><td>9.44% </td><td>18799.5</td><td>16.05%</td><td>Fli1           </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer               </td><td>RACCGGAAGT          </td><td>1</td><td>0</td><td>1</td><td>363</td><td>7.14% </td><td>14718.6</td><td>12.57%</td><td>GABPA          </td></tr>
	<tr><td>HIC1(Zf)/Treg-ZBTB29-ChIP-Seq(GSE99889)/Homer                  </td><td>TGCCAGCB            </td><td>1</td><td>0</td><td>1</td><td>926</td><td>18.20%</td><td>28227.8</td><td>24.10%</td><td>HIC1           </td></tr>
	<tr><td>NF1-halfsite(CTF)/LNCaP-NF1-ChIP-Seq(Unpublished)/Homer        </td><td>YTGCCAAG            </td><td>1</td><td>0</td><td>1</td><td>783</td><td>15.39%</td><td>23982.5</td><td>20.48%</td><td>NF1-halfsite   </td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer                 </td><td>CYTGGCABNSTGCCAR    </td><td>1</td><td>0</td><td>1</td><td>156</td><td>3.07% </td><td> 7057.8</td><td>6.03% </td><td>NF1            </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer                </td><td>AGAGGAAGTG          </td><td>1</td><td>0</td><td>1</td><td>170</td><td>3.34% </td><td> 9228.2</td><td>7.88% </td><td>PU.1           </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG          </td><td>1</td><td>0</td><td>1</td><td>228</td><td>4.48% </td><td> 9575.3</td><td>8.18% </td><td>RUNX           </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM          </td><td>1</td><td>0</td><td>1</td><td>376</td><td>7.39% </td><td>13783.6</td><td>11.77%</td><td>RUNX1          </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer                 </td><td>AAAGRGGAAGTG        </td><td>1</td><td>0</td><td>1</td><td>101</td><td>1.99% </td><td> 4969.8</td><td>4.24% </td><td>SpiB           </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_2</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM     </td><td>1e-98</td><td>-226.70</td><td>0</td><td>1302</td><td>25.31%</td><td>16603.4</td><td>14.13%</td><td>RUNX1          </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer        </td><td>GCTGTGGTTW     </td><td>1e-85</td><td>-197.10</td><td>0</td><td>1012</td><td>19.67%</td><td>12224.7</td><td>10.40%</td><td>RUNX-AML       </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG     </td><td>1e-80</td><td>-185.70</td><td>0</td><td> 970</td><td>18.85%</td><td>11766.5</td><td>10.01%</td><td>RUNX           </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                 </td><td>NWAACCACADNN   </td><td>1e-80</td><td>-184.70</td><td>0</td><td>1093</td><td>21.24%</td><td>13934.8</td><td>11.86%</td><td>RUNX2          </td></tr>
	<tr><td>Tcf7(HMG)/GM12878-TCF7-ChIP-Seq(Encode)/Homer                  </td><td>CTTTGATGTGSB   </td><td>1e-42</td><td> -98.31</td><td>0</td><td> 400</td><td>7.77% </td><td> 4286.8</td><td>3.65% </td><td>Tcf7           </td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH     </td><td>1e-29</td><td> -68.75</td><td>0</td><td>1111</td><td>21.59%</td><td>18259.6</td><td>15.54%</td><td>Fli1           </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG     </td><td>1e-28</td><td> -65.55</td><td>0</td><td>1094</td><td>21.26%</td><td>18078.4</td><td>15.38%</td><td>ETS1           </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG     </td><td>1e-27</td><td> -64.26</td><td>0</td><td>1028</td><td>19.98%</td><td>16826.6</td><td>14.32%</td><td>ETV4           </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT   </td><td>1e-27</td><td> -62.99</td><td>0</td><td> 187</td><td>3.63% </td><td> 1715.1</td><td>1.46% </td><td>ETS:RUNX       </td></tr>
	<tr><td>LEF1(HMG)/H1-LEF1-ChIP-Seq(GSE64758)/Homer                     </td><td>CCTTTGATST     </td><td>1e-26</td><td> -61.07</td><td>0</td><td> 629</td><td>12.23%</td><td> 9264.0</td><td>7.88% </td><td>LEF1           </td></tr>
	<tr><td>JunB(bZIP)/DendriticCells-Junb-ChIP-Seq(GSE36099)/Homer        </td><td>RATGASTCAT     </td><td>1e-25</td><td> -59.63</td><td>0</td><td> 561</td><td>10.90%</td><td> 8061.2</td><td>6.86% </td><td>JunB           </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT     </td><td>1e-25</td><td> -58.31</td><td>0</td><td> 664</td><td>12.91%</td><td>10028.6</td><td>8.53% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>BATF(bZIP)/Th17-BATF-ChIP-Seq(GSE39756)/Homer                  </td><td>DATGASTCAT     </td><td>1e-24</td><td> -57.37</td><td>0</td><td> 623</td><td>12.11%</td><td> 9295.6</td><td>7.91% </td><td>BATF           </td></tr>
	<tr><td>Fra2(bZIP)/Striatum-Fra2-ChIP-Seq(GSE43429)/Homer              </td><td>GGATGACTCATC   </td><td>1e-24</td><td> -55.41</td><td>0</td><td> 500</td><td>9.72% </td><td> 7097.1</td><td>6.04% </td><td>Fra2           </td></tr>
	<tr><td>Fra1(bZIP)/BT549-Fra1-ChIP-Seq(GSE46166)/Homer                 </td><td>NNATGASTCATH   </td><td>1e-24</td><td> -55.33</td><td>0</td><td> 555</td><td>10.79%</td><td> 8108.3</td><td>6.90% </td><td>Fra1           </td></tr>
	<tr><td>E2A(bHLH),near_PU.1/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer        </td><td>NVCACCTGBN     </td><td>1e-23</td><td> -54.77</td><td>0</td><td> 989</td><td>19.22%</td><td>16532.4</td><td>14.07%</td><td>E2A            </td></tr>
	<tr><td>Atf3(bZIP)/GBM-ATF3-ChIP-Seq(GSE33912)/Homer                   </td><td>DATGASTCATHN   </td><td>1e-23</td><td> -54.03</td><td>0</td><td> 631</td><td>12.26%</td><td> 9580.2</td><td>8.15% </td><td>Atf3           </td></tr>
	<tr><td>Tcf3(HMG)/mES-Tcf3-ChIP-Seq(GSE11724)/Homer                    </td><td>ASWTCAAAGG     </td><td>1e-22</td><td> -52.47</td><td>0</td><td> 275</td><td>5.34% </td><td> 3270.0</td><td>2.78% </td><td>Tcf3           </td></tr>
	<tr><td>Egr2(Zf)/Thymocytes-Egr2-ChIP-Seq(GSE34254)/Homer              </td><td>NGCGTGGGCGGR   </td><td>1e-22</td><td> -52.07</td><td>0</td><td> 162</td><td>3.15% </td><td> 1527.6</td><td>1.30% </td><td>Egr2           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN   </td><td>1e-22</td><td> -51.19</td><td>0</td><td>1029</td><td>20.00%</td><td>17534.8</td><td>14.92%</td><td>Etv2           </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY     </td><td>1e-21</td><td> -50.49</td><td>0</td><td> 477</td><td>9.27% </td><td> 6853.7</td><td>5.83% </td><td>Elk1           </td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY     </td><td>1e-21</td><td> -49.58</td><td>0</td><td> 466</td><td>9.06% </td><td> 6685.3</td><td>5.69% </td><td>Elk4           </td></tr>
	<tr><td>AP-1(bZIP)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer               </td><td>VTGACTCATC     </td><td>1e-21</td><td> -48.86</td><td>0</td><td> 678</td><td>13.18%</td><td>10703.9</td><td>9.11% </td><td>AP-1           </td></tr>
	<tr><td>IRF:BATF(IRF:bZIP)/pDC-Irf8-ChIP-Seq(GSE66899)/Homer           </td><td>CTTTCANTATGACTV</td><td>1e-21</td><td> -48.70</td><td>0</td><td> 167</td><td>3.25% </td><td> 1655.9</td><td>1.41% </td><td>IRF:BATF       </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT     </td><td>1e-21</td><td> -48.44</td><td>0</td><td> 443</td><td>8.61% </td><td> 6307.0</td><td>5.37% </td><td>Ets1-distal    </td></tr>
	<tr><td>Fosl2(bZIP)/3T3L1-Fosl2-ChIP-Seq(GSE56872)/Homer               </td><td>NATGASTCABNN   </td><td>1e-20</td><td> -48.29</td><td>0</td><td> 367</td><td>7.13% </td><td> 4952.2</td><td>4.21% </td><td>Fosl2          </td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG     </td><td>1e-20</td><td> -48.26</td><td>0</td><td>1505</td><td>29.25%</td><td>27601.7</td><td>23.49%</td><td>ERG            </td></tr>
	<tr><td>ZEB1(Zf)/PDAC-ZEB1-ChIP-Seq(GSE64557)/Homer                    </td><td>VCAGGTRDRY     </td><td>1e-20</td><td> -48.24</td><td>0</td><td>1054</td><td>20.49%</td><td>18213.1</td><td>15.50%</td><td>ZEB1           </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT     </td><td>1e-19</td><td> -45.59</td><td>0</td><td>1253</td><td>24.35%</td><td>22485.5</td><td>19.13%</td><td>ETV1           </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN     </td><td>1e-19</td><td> -45.30</td><td>0</td><td> 857</td><td>16.66%</td><td>14404.0</td><td>12.26%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>Chop(bZIP)/MEF-Chop-ChIP-Seq(GSE35681)/Homer                </td><td>ATTGCATCAT               </td><td>1</td><td>-4e-06</td><td>1</td><td>  99</td><td>1.92% </td><td> 3405.9</td><td>2.90% </td><td>Chop        </td></tr>
	<tr><td>Erra(NR)/HepG2-Erra-ChIP-Seq(GSE31477)/Homer                </td><td>CAAAGGTCAG               </td><td>1</td><td>-4e-06</td><td>1</td><td>1004</td><td>19.51%</td><td>25913.2</td><td>22.05%</td><td>Erra        </td></tr>
	<tr><td>COUP-TFII(NR)/K562-NR2F1-ChIP-Seq(Encode)/Homer             </td><td>GKBCARAGGTCA             </td><td>1</td><td> 0e+00</td><td>1</td><td> 667</td><td>12.96%</td><td>18055.1</td><td>15.36%</td><td>COUP-TFII   </td></tr>
	<tr><td>Tlx?(NR)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer               </td><td>CTGGCAGSCTGCCA           </td><td>1</td><td> 0e+00</td><td>1</td><td> 181</td><td>3.52% </td><td> 5810.6</td><td>4.94% </td><td>Tlx?        </td></tr>
	<tr><td>CEBP:AP1(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer       </td><td>DRTGTTGCAA               </td><td>1</td><td> 0e+00</td><td>1</td><td> 389</td><td>7.56% </td><td>11342.5</td><td>9.65% </td><td>CEBP:AP1    </td></tr>
	<tr><td>Isl1(Homeobox)/Neuron-Isl1-ChIP-Seq(GSE31456)/Homer         </td><td>CTAATKGV                 </td><td>1</td><td> 0e+00</td><td>1</td><td> 906</td><td>17.61%</td><td>24182.4</td><td>20.58%</td><td>Isl1        </td></tr>
	<tr><td>COUP-TFII(NR)/Artia-Nr2f2-ChIP-Seq(GSE46497)/Homer          </td><td>AGRGGTCA                 </td><td>1</td><td> 0e+00</td><td>1</td><td> 782</td><td>15.20%</td><td>21200.5</td><td>18.04%</td><td>COUP-TFII   </td></tr>
	<tr><td>Atf4(bZIP)/MEF-Atf4-ChIP-Seq(GSE35681)/Homer                </td><td>MTGATGCAAT               </td><td>1</td><td> 0e+00</td><td>1</td><td> 122</td><td>2.37% </td><td> 4358.6</td><td>3.71% </td><td>Atf4        </td></tr>
	<tr><td>LXH9(Homeobox)/Hct116-LXH9.V5-ChIP-Seq(GSE116822)/Homer     </td><td>NGCTAATTAG               </td><td>1</td><td> 0e+00</td><td>1</td><td> 665</td><td>12.93%</td><td>18368.6</td><td>15.63%</td><td>LXH9        </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer              </td><td>AAAGRGGAAGTG             </td><td>1</td><td> 0e+00</td><td>1</td><td> 165</td><td>3.21% </td><td> 5587.9</td><td>4.75% </td><td>SpiB        </td></tr>
	<tr><td>Dlx3(Homeobox)/Kerainocytes-Dlx3-ChIP-Seq(GSE89884)/Homer   </td><td>NDGTAATTAC               </td><td>1</td><td> 0e+00</td><td>1</td><td> 282</td><td>5.48% </td><td> 8719.5</td><td>7.42% </td><td>Dlx3        </td></tr>
	<tr><td>TEAD(TEA)/Fibroblast-PU.1-ChIP-Seq(Unpublished)/Homer       </td><td>YCWGGAATGY               </td><td>1</td><td> 0e+00</td><td>1</td><td> 246</td><td>4.78% </td><td> 7807.3</td><td>6.64% </td><td>TEAD        </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer               </td><td>TRCATTCCAG               </td><td>1</td><td> 0e+00</td><td>1</td><td> 457</td><td>8.88% </td><td>13297.6</td><td>11.32%</td><td>TEAD3       </td></tr>
	<tr><td>TEAD2(TEA)/Py2T-Tead2-ChIP-Seq(GSE55709)/Homer              </td><td>CCWGGAATGY               </td><td>1</td><td> 0e+00</td><td>1</td><td> 167</td><td>3.25% </td><td> 5774.7</td><td>4.91% </td><td>TEAD2       </td></tr>
	<tr><td>EAR2(NR)/K562-NR2F6-ChIP-Seq(Encode)/Homer                  </td><td>NRBCARRGGTCA             </td><td>1</td><td> 0e+00</td><td>1</td><td> 576</td><td>11.20%</td><td>16443.9</td><td>13.99%</td><td>EAR2        </td></tr>
	<tr><td>NF1-halfsite(CTF)/LNCaP-NF1-ChIP-Seq(Unpublished)/Homer     </td><td>YTGCCAAG                 </td><td>1</td><td> 0e+00</td><td>1</td><td> 850</td><td>16.52%</td><td>23284.8</td><td>19.81%</td><td>NF1-halfsite</td></tr>
	<tr><td>HLF(bZIP)/HSC-HLF.Flag-ChIP-Seq(GSE69817)/Homer             </td><td>RTTATGYAAB               </td><td>1</td><td> 0e+00</td><td>1</td><td> 413</td><td>8.03% </td><td>12415.5</td><td>10.56%</td><td>HLF         </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer              </td><td>VTTACGTAAYNNNNN          </td><td>1</td><td> 0e+00</td><td>1</td><td> 310</td><td>6.03% </td><td> 9750.1</td><td>8.30% </td><td>NFIL3       </td></tr>
	<tr><td>Lhx3(Homeobox)/Neuron-Lhx3-ChIP-Seq(GSE31456)/Homer         </td><td>ADBTAATTAR               </td><td>1</td><td> 0e+00</td><td>1</td><td> 816</td><td>15.86%</td><td>22545.8</td><td>19.19%</td><td>Lhx3        </td></tr>
	<tr><td>Nkx6.1(Homeobox)/Islet-Nkx6.1-ChIP-Seq(GSE40975)/Homer      </td><td>GKTAATGR                 </td><td>1</td><td> 0e+00</td><td>1</td><td>1308</td><td>25.42%</td><td>34560.9</td><td>29.41%</td><td>Nkx6.1      </td></tr>
	<tr><td>Lhx1(Homeobox)/EmbryoCarcinoma-Lhx1-ChIP-Seq(GSE70957)/Homer</td><td>NNYTAATTAR               </td><td>1</td><td> 0e+00</td><td>1</td><td> 510</td><td>9.91% </td><td>15109.9</td><td>12.86%</td><td>Lhx1        </td></tr>
	<tr><td>Lhx2(Homeobox)/HFSC-Lhx2-ChIP-Seq(GSE48068)/Homer           </td><td>TAATTAGN                 </td><td>1</td><td> 0e+00</td><td>1</td><td> 469</td><td>9.12% </td><td>14150.9</td><td>12.04%</td><td>Lhx2        </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer              </td><td>CYRCATTCCA               </td><td>1</td><td> 0e+00</td><td>1</td><td> 347</td><td>6.74% </td><td>11280.9</td><td>9.60% </td><td>TEAD1       </td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer              </td><td>CYTGGCABNSTGCCAR         </td><td>1</td><td> 0e+00</td><td>1</td><td> 153</td><td>2.97% </td><td> 5986.3</td><td>5.09% </td><td>NF1         </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer        </td><td>CCWGGAATGY               </td><td>1</td><td> 0e+00</td><td>1</td><td> 276</td><td>5.36% </td><td> 9633.7</td><td>8.20% </td><td>TEAD4       </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer               </td><td>CNNBRGCGCCCCCTGSTGGC     </td><td>1</td><td> 0e+00</td><td>1</td><td>  63</td><td>1.22% </td><td> 4656.3</td><td>3.96% </td><td>BORIS       </td></tr>
	<tr><td>CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer           </td><td>ATTGCGCAAC               </td><td>1</td><td> 0e+00</td><td>1</td><td> 332</td><td>6.45% </td><td>11833.9</td><td>10.07%</td><td>CEBP        </td></tr>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer            </td><td>AYAGTGCCMYCTRGTGGCCA     </td><td>1</td><td> 0e+00</td><td>1</td><td>  21</td><td>0.41% </td><td> 4344.5</td><td>3.70% </td><td>CTCF        </td></tr>
	<tr><td>ZFP3(Zf)/HEK293-ZFP3.GFP-ChIP-Seq(GSE58341)/Homer           </td><td>GGGTTTTGAAGGATGARTAGGAGTT</td><td>1</td><td> 0e+00</td><td>1</td><td>   0</td><td>0.00% </td><td>   31.3</td><td>0.03% </td><td>ZFP3        </td></tr>
	<tr><td>ZNF16(Zf)/HEK293-ZNF16.GFP-ChIP-Seq(GSE58341)/Homer         </td><td>MACCTTCYATGGCTCCCTAKTGCCY</td><td>1</td><td> 0e+00</td><td>1</td><td>   0</td><td>0.00% </td><td>   76.7</td><td>0.07% </td><td>ZNF16       </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_3</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG  </td><td>1e-307</td><td>-1455.00</td><td>0</td><td>6165</td><td>44.59%</td><td>26477.4</td><td>23.67%</td><td>ERG            </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG  </td><td>1e-307</td><td>-1318.00</td><td>0</td><td>4480</td><td>32.40%</td><td>16752.7</td><td>14.98%</td><td>ETS1           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN</td><td>1e-307</td><td>-1315.00</td><td>0</td><td>4382</td><td>31.69%</td><td>16196.8</td><td>14.48%</td><td>Etv2           </td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH  </td><td>1e-307</td><td>-1304.00</td><td>0</td><td>4510</td><td>32.62%</td><td>17012.5</td><td>15.21%</td><td>Fli1           </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT  </td><td>1e-307</td><td>-1298.00</td><td>0</td><td>5226</td><td>37.80%</td><td>21456.0</td><td>19.18%</td><td>ETV1           </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                   </td><td>ACTTCCKGKT  </td><td>1e-307</td><td>-1086.00</td><td>0</td><td>4211</td><td>30.45%</td><td>16585.7</td><td>14.83%</td><td>Elf4           </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG  </td><td>1e-307</td><td>-1063.00</td><td>0</td><td>4123</td><td>29.82%</td><td>16206.9</td><td>14.49%</td><td>ETV4           </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer               </td><td>RACCGGAAGT  </td><td>1e-307</td><td>-1052.00</td><td>0</td><td>3695</td><td>26.72%</td><td>13750.2</td><td>12.29%</td><td>GABPA          </td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                     </td><td>AVCAGGAAGT  </td><td>1e-307</td><td> -904.90</td><td>0</td><td>4767</td><td>34.48%</td><td>21405.2</td><td>19.14%</td><td>EHF            </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT  </td><td>1e-307</td><td> -878.70</td><td>0</td><td>2678</td><td>19.37%</td><td> 9070.9</td><td>8.11% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN  </td><td>1e-307</td><td> -860.20</td><td>0</td><td>3360</td><td>24.30%</td><td>13011.2</td><td>11.63%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer                </td><td>AGAGGAAGTG  </td><td>1e-307</td><td> -759.10</td><td>0</td><td>2545</td><td>18.41%</td><td> 9015.7</td><td>8.06% </td><td>PU.1           </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT  </td><td>1e-307</td><td> -720.10</td><td>0</td><td>1829</td><td>13.23%</td><td> 5485.5</td><td>4.90% </td><td>Ets1-distal    </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                   </td><td>ANCAGGAAGT  </td><td>1e-307</td><td> -708.90</td><td>0</td><td>3137</td><td>22.69%</td><td>12733.4</td><td>11.38%</td><td>ELF3           </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                   </td><td>ACVAGGAAGT  </td><td>1e-262</td><td> -604.40</td><td>0</td><td>2967</td><td>21.46%</td><td>12495.4</td><td>11.17%</td><td>ELF5           </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM  </td><td>1e-218</td><td> -503.30</td><td>0</td><td>3065</td><td>22.17%</td><td>13952.4</td><td>12.47%</td><td>RUNX1          </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG  </td><td>1e-192</td><td> -443.00</td><td>0</td><td>2269</td><td>16.41%</td><td> 9577.8</td><td>8.56% </td><td>RUNX           </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer                </td><td>AVCCGGAAGT  </td><td>1e-186</td><td> -430.50</td><td>0</td><td>1696</td><td>12.27%</td><td> 6361.1</td><td>5.69% </td><td>ELF1           </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer                </td><td>ASWTCCTGBT  </td><td>1e-179</td><td> -413.20</td><td>0</td><td>2895</td><td>20.94%</td><td>13732.1</td><td>12.28%</td><td>SPDEF          </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY  </td><td>1e-173</td><td> -400.50</td><td>0</td><td>1701</td><td>12.30%</td><td> 6593.3</td><td>5.89% </td><td>Elk1           </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                        </td><td>AACCGGAAGT  </td><td>1e-165</td><td> -380.30</td><td>0</td><td>1216</td><td>8.79% </td><td> 4088.4</td><td>3.66% </td><td>ETS            </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                 </td><td>NWAACCACADNN</td><td>1e-156</td><td> -360.30</td><td>0</td><td>2449</td><td>17.71%</td><td>11421.3</td><td>10.21%</td><td>RUNX2          </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT</td><td>1e-135</td><td> -312.80</td><td>0</td><td> 606</td><td>4.38% </td><td> 1481.5</td><td>1.32% </td><td>ETS:RUNX       </td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY  </td><td>1e-135</td><td> -312.70</td><td>0</td><td>1566</td><td>11.33%</td><td> 6472.6</td><td>5.79% </td><td>Elk4           </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer        </td><td>GCTGTGGTTW  </td><td>1e-135</td><td> -312.60</td><td>0</td><td>2187</td><td>15.82%</td><td>10247.3</td><td>9.16% </td><td>RUNX-AML       </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer                 </td><td>AAAGRGGAAGTG</td><td>1e-133</td><td> -306.40</td><td>0</td><td>1278</td><td>9.24% </td><td> 4878.8</td><td>4.36% </td><td>SpiB           </td></tr>
	<tr><td>ETS:E-box(ETS,bHLH)/HPC7-Scl-ChIP-Seq(GSE22178)/Homer          </td><td>AGGAARCAGCTG</td><td> 1e-53</td><td> -123.70</td><td>0</td><td> 447</td><td>3.23% </td><td> 1583.1</td><td>1.42% </td><td>ETS:E-box      </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer          </td><td>MGGAAGTGAAAC</td><td> 1e-30</td><td>  -71.12</td><td>0</td><td>3049</td><td>22.05%</td><td>20285.7</td><td>18.14%</td><td>PU.1-IRF       </td></tr>
	<tr><td>IRF2(IRF)/Erythroblas-IRF2-ChIP-Seq(GSE36985)/Homer            </td><td>GAAASYGAAASY</td><td> 1e-26</td><td>  -61.51</td><td>0</td><td> 391</td><td>2.83% </td><td> 1745.9</td><td>1.56% </td><td>IRF2           </td></tr>
	<tr><td>Nrf2(bZIP)/Lymphoblast-Nrf2-ChIP-Seq(GSE37589)/Homer           </td><td>HTGCTGAGTCAT</td><td> 1e-26</td><td>  -60.60</td><td>0</td><td> 225</td><td>1.63% </td><td>  812.2</td><td>0.73% </td><td>Nrf2           </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>THRa(NR)/C17.2-THRa-ChIP-Seq(GSE38347)/Homer         </td><td>GGTCANYTGAGGWCA     </td><td>1</td><td>0</td><td>1</td><td> 507</td><td>3.67% </td><td> 5194.8</td><td>4.64% </td><td>THRa     </td></tr>
	<tr><td>Erra(NR)/HepG2-Erra-ChIP-Seq(GSE31477)/Homer         </td><td>CAAAGGTCAG          </td><td>1</td><td>0</td><td>1</td><td>2914</td><td>21.07%</td><td>25830.5</td><td>23.09%</td><td>Erra     </td></tr>
	<tr><td>Foxa3(Forkhead)/Liver-Foxa3-ChIP-Seq(GSE77670)/Homer </td><td>BSNTGTTTACWYWGN     </td><td>1</td><td>0</td><td>1</td><td> 408</td><td>2.95% </td><td> 4330.3</td><td>3.87% </td><td>Foxa3    </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer          </td><td>CCWTTGTY            </td><td>1</td><td>0</td><td>1</td><td>2403</td><td>17.38%</td><td>21634.8</td><td>19.34%</td><td>Sox3     </td></tr>
	<tr><td>Rfx1(HTH)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer       </td><td>KGTTGCCATGGCAA      </td><td>1</td><td>0</td><td>1</td><td> 205</td><td>1.48% </td><td> 2432.7</td><td>2.17% </td><td>Rfx1     </td></tr>
	<tr><td>SF1(NR)/H295R-Nr5a1-ChIP-Seq(GSE44220)/Homer         </td><td>CAAGGHCANV          </td><td>1</td><td>0</td><td>1</td><td> 481</td><td>3.48% </td><td> 5024.2</td><td>4.49% </td><td>SF1      </td></tr>
	<tr><td>Sox15(HMG)/CPA-Sox15-ChIP-Seq(GSE62909)/Homer        </td><td>RAACAATGGN          </td><td>1</td><td>0</td><td>1</td><td>1413</td><td>10.22%</td><td>13262.4</td><td>11.86%</td><td>Sox15    </td></tr>
	<tr><td>RFX(HTH)/K562-RFX3-ChIP-Seq(SRA012198)/Homer         </td><td>CGGTTGCCATGGCAAC    </td><td>1</td><td>0</td><td>1</td><td>  71</td><td>0.51% </td><td> 1118.9</td><td>1.00% </td><td>RFX      </td></tr>
	<tr><td>THRb(NR)/Liver-NR1A2-ChIP-Seq(GSE52613)/Homer        </td><td>TRAGGTCA            </td><td>1</td><td>0</td><td>1</td><td>5238</td><td>37.88%</td><td>45338.8</td><td>40.53%</td><td>THRb     </td></tr>
	<tr><td>GLIS3(Zf)/Thyroid-Glis3.GFP-ChIP-Seq(GSE103297)/Homer</td><td>CTCCCTGGGAGGCCN     </td><td>1</td><td>0</td><td>1</td><td>2225</td><td>16.09%</td><td>20311.9</td><td>18.16%</td><td>GLIS3    </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer</td><td>CCWTTGTYYB          </td><td>1</td><td>0</td><td>1</td><td>2230</td><td>16.13%</td><td>20376.0</td><td>18.22%</td><td>Sox10    </td></tr>
	<tr><td>PPARa(NR),DR1/Liver-Ppara-ChIP-Seq(GSE47954)/Homer   </td><td>VNAGGKCAAAGGTCA     </td><td>1</td><td>0</td><td>1</td><td>1298</td><td>9.39% </td><td>12426.4</td><td>11.11%</td><td>PPARa    </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer         </td><td>AGGVNCCTTTGT        </td><td>1</td><td>0</td><td>1</td><td>1102</td><td>7.97% </td><td>10800.8</td><td>9.66% </td><td>Sox9     </td></tr>
	<tr><td>Rfx2(HTH)/LoVo-RFX2-ChIP-Seq(GSE49402)/Homer         </td><td>GTTGCCATGGCAACM     </td><td>1</td><td>0</td><td>1</td><td>  79</td><td>0.57% </td><td> 1266.4</td><td>1.13% </td><td>Rfx2     </td></tr>
	<tr><td>Nr5a2(NR)/mES-Nr5a2-ChIP-Seq(GSE19019)/Homer         </td><td>BTCAAGGTCA          </td><td>1</td><td>0</td><td>1</td><td> 518</td><td>3.75% </td><td> 5712.9</td><td>5.11% </td><td>Nr5a2    </td></tr>
	<tr><td>TEAD2(TEA)/Py2T-Tead2-ChIP-Seq(GSE55709)/Homer       </td><td>CCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 560</td><td>4.05% </td><td> 6149.7</td><td>5.50% </td><td>TEAD2    </td></tr>
	<tr><td>EAR2(NR)/K562-NR2F6-ChIP-Seq(Encode)/Homer           </td><td>NRBCARRGGTCA        </td><td>1</td><td>0</td><td>1</td><td>1607</td><td>11.62%</td><td>15534.9</td><td>13.89%</td><td>EAR2     </td></tr>
	<tr><td>CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer    </td><td>ATTGCGCAAC          </td><td>1</td><td>0</td><td>1</td><td> 992</td><td>7.17% </td><td>10122.3</td><td>9.05% </td><td>CEBP     </td></tr>
	<tr><td>COUP-TFII(NR)/K562-NR2F1-ChIP-Seq(Encode)/Homer      </td><td>GKBCARAGGTCA        </td><td>1</td><td>0</td><td>1</td><td>1811</td><td>13.10%</td><td>17332.9</td><td>15.50%</td><td>COUP-TFII</td></tr>
	<tr><td>Nr5a2(NR)/Pancreas-LRH1-ChIP-Seq(GSE34295)/Homer     </td><td>BTCAAGGTCA          </td><td>1</td><td>0</td><td>1</td><td> 718</td><td>5.19% </td><td> 7693.1</td><td>6.88% </td><td>Nr5a2    </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer        </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1</td><td>0</td><td>1</td><td> 280</td><td>2.03% </td><td> 4805.8</td><td>4.30% </td><td>BORIS    </td></tr>
	<tr><td>COUP-TFII(NR)/Artia-Nr2f2-ChIP-Seq(GSE46497)/Homer   </td><td>AGRGGTCA            </td><td>1</td><td>0</td><td>1</td><td>2050</td><td>14.83%</td><td>20371.7</td><td>18.21%</td><td>COUP-TFII</td></tr>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer     </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1</td><td>0</td><td>1</td><td> 201</td><td>1.45% </td><td> 4223.5</td><td>3.78% </td><td>CTCF     </td></tr>
	<tr><td>ERRg(NR)/Kidney-ESRRG-ChIP-Seq(GSE104905)/Homer      </td><td>GTGACCTTGRVN        </td><td>1</td><td>0</td><td>1</td><td> 872</td><td>6.31% </td><td> 9229.7</td><td>8.25% </td><td>ERRg     </td></tr>
	<tr><td>Esrrb(NR)/mES-Esrrb-ChIP-Seq(GSE11431)/Homer         </td><td>KTGACCTTGA          </td><td>1</td><td>0</td><td>1</td><td> 648</td><td>4.69% </td><td> 7313.5</td><td>6.54% </td><td>Esrrb    </td></tr>
	<tr><td>RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer            </td><td>TTGAMCTTTG          </td><td>1</td><td>0</td><td>1</td><td>3616</td><td>26.15%</td><td>33469.6</td><td>29.92%</td><td>RARa     </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer       </td><td>CYRCATTCCA          </td><td>1</td><td>0</td><td>1</td><td>1095</td><td>7.92% </td><td>11897.9</td><td>10.64%</td><td>TEAD1    </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer        </td><td>TRCATTCCAG          </td><td>1</td><td>0</td><td>1</td><td>1299</td><td>9.39% </td><td>13619.2</td><td>12.18%</td><td>TEAD3    </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer </td><td>CCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 949</td><td>6.86% </td><td>10298.5</td><td>9.21% </td><td>TEAD4    </td></tr>
	<tr><td>TEAD(TEA)/Fibroblast-PU.1-ChIP-Seq(Unpublished)/Homer</td><td>YCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 740</td><td>5.35% </td><td> 8288.0</td><td>7.41% </td><td>TEAD     </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_4</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG     </td><td>1e-307</td><td>-801.00</td><td>0</td><td>5350</td><td>39.71%</td><td>27152.7</td><td>24.14%</td><td>ERG            </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                   </td><td>ACTTCCKGKT     </td><td>1e-307</td><td>-725.10</td><td>0</td><td>3759</td><td>27.90%</td><td>16979.7</td><td>15.10%</td><td>Elf4           </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT     </td><td>1e-307</td><td>-709.20</td><td>0</td><td>4490</td><td>33.33%</td><td>22014.7</td><td>19.57%</td><td>ETV1           </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG     </td><td>1e-292</td><td>-673.10</td><td>0</td><td>3760</td><td>27.91%</td><td>17431.4</td><td>15.50%</td><td>ETS1           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN   </td><td>1e-291</td><td>-671.30</td><td>0</td><td>3673</td><td>27.26%</td><td>16876.9</td><td>15.01%</td><td>Etv2           </td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH     </td><td>1e-261</td><td>-602.60</td><td>0</td><td>3699</td><td>27.45%</td><td>17669.3</td><td>15.71%</td><td>Fli1           </td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                     </td><td>AVCAGGAAGT     </td><td>1e-259</td><td>-598.10</td><td>0</td><td>4311</td><td>32.00%</td><td>21884.7</td><td>19.46%</td><td>EHF            </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                   </td><td>ACVAGGAAGT     </td><td>1e-239</td><td>-550.50</td><td>0</td><td>2858</td><td>21.21%</td><td>12673.3</td><td>11.27%</td><td>ELF5           </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer                </td><td>AGAGGAAGTG     </td><td>1e-237</td><td>-547.40</td><td>0</td><td>2308</td><td>17.13%</td><td> 9325.9</td><td>8.29% </td><td>PU.1           </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer               </td><td>RACCGGAAGT     </td><td>1e-225</td><td>-519.10</td><td>0</td><td>3060</td><td>22.71%</td><td>14241.1</td><td>12.66%</td><td>GABPA          </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG     </td><td>1e-201</td><td>-464.80</td><td>0</td><td>3351</td><td>24.87%</td><td>16703.3</td><td>14.85%</td><td>ETV4           </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                   </td><td>ANCAGGAAGT     </td><td>1e-200</td><td>-462.40</td><td>0</td><td>2812</td><td>20.87%</td><td>13160.2</td><td>11.70%</td><td>ELF3           </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN     </td><td>1e-176</td><td>-407.30</td><td>0</td><td>2810</td><td>20.86%</td><td>13688.1</td><td>12.17%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer                 </td><td>AAAGRGGAAGTG   </td><td>1e-154</td><td>-355.00</td><td>0</td><td>1307</td><td>9.70% </td><td> 4872.8</td><td>4.33% </td><td>SpiB           </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT     </td><td>1e-147</td><td>-339.50</td><td>0</td><td>2071</td><td>15.37%</td><td> 9572.5</td><td>8.51% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT     </td><td>1e-119</td><td>-274.90</td><td>0</td><td>1385</td><td>10.28%</td><td> 5907.5</td><td>5.25% </td><td>Ets1-distal    </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM     </td><td> 1e-85</td><td>-197.10</td><td>0</td><td>2545</td><td>18.89%</td><td>14489.6</td><td>12.88%</td><td>RUNX1          </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer                </td><td>ASWTCCTGBT     </td><td> 1e-84</td><td>-194.70</td><td>0</td><td>2488</td><td>18.47%</td><td>14122.3</td><td>12.56%</td><td>SPDEF          </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer                </td><td>AVCCGGAAGT     </td><td> 1e-75</td><td>-174.70</td><td>0</td><td>1342</td><td>9.96% </td><td> 6598.8</td><td>5.87% </td><td>ELF1           </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG     </td><td> 1e-66</td><td>-153.00</td><td>0</td><td>1810</td><td>13.43%</td><td>10017.8</td><td>8.91% </td><td>RUNX           </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY     </td><td> 1e-60</td><td>-138.20</td><td>0</td><td>1309</td><td>9.72% </td><td> 6821.9</td><td>6.07% </td><td>Elk1           </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                        </td><td>AACCGGAAGT     </td><td> 1e-58</td><td>-134.80</td><td>0</td><td> 922</td><td>6.84% </td><td> 4352.8</td><td>3.87% </td><td>ETS            </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer        </td><td>GCTGTGGTTW     </td><td> 1e-57</td><td>-131.60</td><td>0</td><td>1832</td><td>13.60%</td><td>10506.0</td><td>9.34% </td><td>RUNX-AML       </td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY     </td><td> 1e-54</td><td>-124.90</td><td>0</td><td>1251</td><td>9.29% </td><td> 6610.0</td><td>5.88% </td><td>Elk4           </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                 </td><td>NWAACCACADNN   </td><td> 1e-51</td><td>-119.60</td><td>0</td><td>1993</td><td>14.79%</td><td>11860.4</td><td>10.55%</td><td>RUNX2          </td></tr>
	<tr><td>ETS:E-box(ETS,bHLH)/HPC7-Scl-ChIP-Seq(GSE22178)/Homer          </td><td>AGGAARCAGCTG   </td><td> 1e-38</td><td> -88.29</td><td>0</td><td> 395</td><td>2.93% </td><td> 1591.3</td><td>1.41% </td><td>ETS:E-box      </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer          </td><td>MGGAAGTGAAAC   </td><td> 1e-29</td><td> -67.28</td><td>0</td><td>2956</td><td>21.94%</td><td>20347.1</td><td>18.09%</td><td>PU.1-IRF       </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT   </td><td> 1e-28</td><td> -65.04</td><td>0</td><td> 387</td><td>2.87% </td><td> 1742.8</td><td>1.55% </td><td>ETS:RUNX       </td></tr>
	<tr><td>Nrf2(bZIP)/Lymphoblast-Nrf2-ChIP-Seq(GSE37589)/Homer           </td><td>HTGCTGAGTCAT   </td><td> 1e-28</td><td> -64.52</td><td>0</td><td> 220</td><td>1.63% </td><td>  786.8</td><td>0.70% </td><td>Nrf2           </td></tr>
	<tr><td>NFE2L2(bZIP)/HepG2-NFE2L2-ChIP-Seq(Encode)/Homer               </td><td>AWWWTGCTGAGTCAT</td><td> 1e-27</td><td> -62.38</td><td>0</td><td> 210</td><td>1.56% </td><td>  746.4</td><td>0.66% </td><td>NFE2L2         </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>Isl1(Homeobox)/Neuron-Isl1-ChIP-Seq(GSE31456)/Homer                    </td><td>CTAATKGV            </td><td>1</td><td>0</td><td>1</td><td>2531</td><td>18.79%</td><td>23511.6</td><td>20.90%</td><td>Isl1               </td></tr>
	<tr><td>Erra(NR)/HepG2-Erra-ChIP-Seq(GSE31477)/Homer                           </td><td>CAAAGGTCAG          </td><td>1</td><td>0</td><td>1</td><td>2800</td><td>20.78%</td><td>25854.2</td><td>22.99%</td><td>Erra               </td></tr>
	<tr><td>Esrrb(NR)/mES-Esrrb-ChIP-Seq(GSE11431)/Homer                           </td><td>KTGACCTTGA          </td><td>1</td><td>0</td><td>1</td><td> 698</td><td>5.18% </td><td> 7243.2</td><td>6.44% </td><td>Esrrb              </td></tr>
	<tr><td>REST-NRSF(Zf)/Jurkat-NRSF-ChIP-Seq/Homer                               </td><td>GGMGCTGTCCATGGTGCTGA</td><td>1</td><td>0</td><td>1</td><td>   1</td><td>0.01% </td><td>  183.6</td><td>0.16% </td><td>REST-NRSF          </td></tr>
	<tr><td>RFX(HTH)/K562-RFX3-ChIP-Seq(SRA012198)/Homer                           </td><td>CGGTTGCCATGGCAAC    </td><td>1</td><td>0</td><td>1</td><td>  69</td><td>0.51% </td><td> 1115.9</td><td>0.99% </td><td>RFX                </td></tr>
	<tr><td>Sox2(HMG)/mES-Sox2-ChIP-Seq(GSE11431)/Homer                            </td><td>BCCATTGTTC          </td><td>1</td><td>0</td><td>1</td><td>1078</td><td>8.00% </td><td>10732.9</td><td>9.54% </td><td>Sox2               </td></tr>
	<tr><td>Tcf3(HMG)/mES-Tcf3-ChIP-Seq(GSE11724)/Homer                            </td><td>ASWTCAAAGG          </td><td>1</td><td>0</td><td>1</td><td> 279</td><td>2.07% </td><td> 3333.3</td><td>2.96% </td><td>Tcf3               </td></tr>
	<tr><td>Zfp281(Zf)/ES-Zfp281-ChIP-Seq(GSE81042)/Homer                          </td><td>CCCCTCCCCCAC        </td><td>1</td><td>0</td><td>1</td><td> 199</td><td>1.48% </td><td> 2562.3</td><td>2.28% </td><td>Zfp281             </td></tr>
	<tr><td>COUP-TFII(NR)/Artia-Nr2f2-ChIP-Seq(GSE46497)/Homer                     </td><td>AGRGGTCA            </td><td>1</td><td>0</td><td>1</td><td>2117</td><td>15.71%</td><td>20143.4</td><td>17.91%</td><td>COUP-TFII          </td></tr>
	<tr><td>Rfx2(HTH)/LoVo-RFX2-ChIP-Seq(GSE49402)/Homer                           </td><td>GTTGCCATGGCAACM     </td><td>1</td><td>0</td><td>1</td><td>  77</td><td>0.57% </td><td> 1271.4</td><td>1.13% </td><td>Rfx2               </td></tr>
	<tr><td>TEAD(TEA)/Fibroblast-PU.1-ChIP-Seq(Unpublished)/Homer                  </td><td>YCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 807</td><td>5.99% </td><td> 8418.1</td><td>7.48% </td><td>TEAD               </td></tr>
	<tr><td>FOXP1(Forkhead)/H9-FOXP1-ChIP-Seq(GSE31006)/Homer                      </td><td>NYYTGTTTACHN        </td><td>1</td><td>0</td><td>1</td><td> 542</td><td>4.02% </td><td> 5956.2</td><td>5.30% </td><td>FOXP1              </td></tr>
	<tr><td>Sox6(HMG)/Myotubes-Sox6-ChIP-Seq(GSE32627)/Homer                       </td><td>CCATTGTTNY          </td><td>1</td><td>0</td><td>1</td><td>2044</td><td>15.17%</td><td>19590.8</td><td>17.42%</td><td>Sox6               </td></tr>
	<tr><td>RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer                              </td><td>TTGAMCTTTG          </td><td>1</td><td>0</td><td>1</td><td>3672</td><td>27.25%</td><td>33759.2</td><td>30.02%</td><td>RARa               </td></tr>
	<tr><td>FOXM1(Forkhead)/MCF7-FOXM1-ChIP-Seq(GSE72977)/Homer                    </td><td>TRTTTACTTW          </td><td>1</td><td>0</td><td>1</td><td>1357</td><td>10.07%</td><td>13513.8</td><td>12.02%</td><td>FOXM1              </td></tr>
	<tr><td>OCT4-SOX2-TCF-NANOG(POU,Homeobox,HMG)/mES-Oct4-ChIP-Seq(GSE11431)/Homer</td><td>ATTTGCATAACAATG     </td><td>1</td><td>0</td><td>1</td><td> 186</td><td>1.38% </td><td> 2510.7</td><td>2.23% </td><td>OCT4-SOX2-TCF-NANOG</td></tr>
	<tr><td>FOXA1(Forkhead)/MCF7-FOXA1-ChIP-Seq(GSE26831)/Homer                    </td><td>WAAGTAAACA          </td><td>1</td><td>0</td><td>1</td><td>1325</td><td>9.83% </td><td>13343.1</td><td>11.86%</td><td>FOXA1              </td></tr>
	<tr><td>Sox4(HMG)/proB-Sox4-ChIP-Seq(GSE50066)/Homer                           </td><td>YCTTTGTTCC          </td><td>1</td><td>0</td><td>1</td><td>1018</td><td>7.56% </td><td>10599.7</td><td>9.42% </td><td>Sox4               </td></tr>
	<tr><td>Foxa2(Forkhead)/Liver-Foxa2-ChIP-Seq(GSE25694)/Homer                   </td><td>CYTGTTTACWYW        </td><td>1</td><td>0</td><td>1</td><td> 988</td><td>7.33% </td><td>10356.2</td><td>9.21% </td><td>Foxa2              </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer                  </td><td>CCWTTGTYYB          </td><td>1</td><td>0</td><td>1</td><td>2114</td><td>15.69%</td><td>20526.0</td><td>18.25%</td><td>Sox10              </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer                         </td><td>CYRCATTCCA          </td><td>1</td><td>0</td><td>1</td><td>1169</td><td>8.68% </td><td>12056.0</td><td>10.72%</td><td>TEAD1              </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer                            </td><td>CCWTTGTY            </td><td>1</td><td>0</td><td>1</td><td>2272</td><td>16.86%</td><td>21980.1</td><td>19.54%</td><td>Sox3               </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer                   </td><td>CCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 983</td><td>7.30% </td><td>10386.9</td><td>9.24% </td><td>TEAD4              </td></tr>
	<tr><td>Sox15(HMG)/CPA-Sox15-ChIP-Seq(GSE62909)/Homer                          </td><td>RAACAATGGN          </td><td>1</td><td>0</td><td>1</td><td>1328</td><td>9.86% </td><td>13569.8</td><td>12.06%</td><td>Sox15              </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer                          </td><td>TRCATTCCAG          </td><td>1</td><td>0</td><td>1</td><td>1357</td><td>10.07%</td><td>13835.2</td><td>12.30%</td><td>TEAD3              </td></tr>
	<tr><td>FOXA1(Forkhead)/LNCAP-FOXA1-ChIP-Seq(GSE27824)/Homer                   </td><td>WAAGTAAACA          </td><td>1</td><td>0</td><td>1</td><td>1590</td><td>11.80%</td><td>16003.1</td><td>14.23%</td><td>FOXA1              </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer                          </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1</td><td>0</td><td>1</td><td> 176</td><td>1.31% </td><td> 4847.9</td><td>4.31% </td><td>BORIS              </td></tr>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer                       </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1</td><td>0</td><td>1</td><td>  94</td><td>0.70% </td><td> 4338.7</td><td>3.86% </td><td>CTCF               </td></tr>
	<tr><td>LEF1(HMG)/H1-LEF1-ChIP-Seq(GSE64758)/Homer                             </td><td>CCTTTGATST          </td><td>1</td><td>0</td><td>1</td><td> 835</td><td>6.20% </td><td> 9221.5</td><td>8.20% </td><td>LEF1               </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer                           </td><td>AGGVNCCTTTGT        </td><td>1</td><td>0</td><td>1</td><td>1013</td><td>7.52% </td><td>10892.0</td><td>9.68% </td><td>Sox9               </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_5</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer                  </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1e-307</td><td>-4437.000</td><td>0.0000</td><td>3031</td><td>21.31%</td><td> 1865.2</td><td>2.21% </td><td>CTCF                 </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer                     </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1e-307</td><td>-3506.000</td><td>0.0000</td><td>3246</td><td>22.82%</td><td> 3089.6</td><td>3.67% </td><td>BORIS                </td></tr>
	<tr><td>E2A(bHLH),near_PU.1/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer           </td><td>NVCACCTGBN          </td><td> 1e-41</td><td>  -96.250</td><td>0.0000</td><td>2677</td><td>18.82%</td><td>12331.9</td><td>14.64%</td><td>E2A                  </td></tr>
	<tr><td>ZEB1(Zf)/PDAC-ZEB1-ChIP-Seq(GSE64557)/Homer                       </td><td>VCAGGTRDRY          </td><td> 1e-40</td><td>  -92.420</td><td>0.0000</td><td>2804</td><td>19.71%</td><td>13080.7</td><td>15.53%</td><td>ZEB1                 </td></tr>
	<tr><td>Bcl11a(Zf)/HSPC-BCL11A-ChIP-Seq(GSE104676)/Homer                  </td><td>TYTGACCASWRG        </td><td> 1e-32</td><td>  -75.590</td><td>0.0000</td><td>1312</td><td>9.22% </td><td> 5546.6</td><td>6.58% </td><td>Bcl11a               </td></tr>
	<tr><td>THRb(NR)/HepG2-THRb.Flag-ChIP-Seq(Encode)/Homer                   </td><td>GGTCACCTGAGGTCA     </td><td> 1e-31</td><td>  -73.430</td><td>0.0000</td><td>1356</td><td>9.53% </td><td> 5799.5</td><td>6.88% </td><td>THRb                 </td></tr>
	<tr><td>CTCF-SatelliteElement(Zf?)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer</td><td>TGCAGTTCCMVNWRTGGCCA</td><td> 1e-27</td><td>  -62.650</td><td>0.0000</td><td>  97</td><td>0.68% </td><td>  148.3</td><td>0.18% </td><td>CTCF-SatelliteElement</td></tr>
	<tr><td>HINFP(Zf)/K562-HINFP.eGFP-ChIP-Seq(Encode)/Homer                  </td><td>TWVGGTCCGC          </td><td> 1e-19</td><td>  -45.670</td><td>0.0000</td><td> 662</td><td>4.65% </td><td> 2697.3</td><td>3.20% </td><td>HINFP                </td></tr>
	<tr><td>ZEB2(Zf)/SNU398-ZEB2-ChIP-Seq(GSE103048)/Homer                    </td><td>GNMCAGGTGTGC        </td><td> 1e-19</td><td>  -45.490</td><td>0.0000</td><td>1550</td><td>10.90%</td><td> 7285.2</td><td>8.65% </td><td>ZEB2                 </td></tr>
	<tr><td>REST-NRSF(Zf)/Jurkat-NRSF-ChIP-Seq/Homer                          </td><td>GGMGCTGTCCATGGTGCTGA</td><td> 1e-19</td><td>  -44.520</td><td>0.0000</td><td> 112</td><td>0.79% </td><td>  243.2</td><td>0.29% </td><td>REST-NRSF            </td></tr>
	<tr><td>LRF(Zf)/Erythroblasts-ZBTB7A-ChIP-Seq(GSE74977)/Homer             </td><td>AAGACCCYYN          </td><td> 1e-18</td><td>  -42.340</td><td>0.0000</td><td>3401</td><td>23.91%</td><td>17558.4</td><td>20.84%</td><td>LRF                  </td></tr>
	<tr><td>Slug(Zf)/Mesoderm-Snai2-ChIP-Seq(GSE61475)/Homer                  </td><td>SNGCACCTGCHS        </td><td> 1e-16</td><td>  -37.840</td><td>0.0000</td><td>1148</td><td>8.07% </td><td> 5308.5</td><td>6.30% </td><td>Slug                 </td></tr>
	<tr><td>E2F4(E2F)/K562-E2F4-ChIP-Seq(GSE31477)/Homer                      </td><td>GGCGGGAAAH          </td><td> 1e-14</td><td>  -34.220</td><td>0.0000</td><td>1087</td><td>7.64% </td><td> 5058.3</td><td>6.00% </td><td>E2F4                 </td></tr>
	<tr><td>NFY(CCAAT)/Promoter/Homer                                         </td><td>RGCCAATSRG          </td><td> 1e-11</td><td>  -26.850</td><td>0.0000</td><td> 874</td><td>6.14% </td><td> 4083.4</td><td>4.85% </td><td>NFY                  </td></tr>
	<tr><td>Zfp57(Zf)/H1-ZFP57.HA-ChIP-Seq(GSE115387)/Homer                   </td><td>NANTGCSGCA          </td><td> 1e-11</td><td>  -25.360</td><td>0.0000</td><td> 843</td><td>5.93% </td><td> 3950.6</td><td>4.69% </td><td>Zfp57                </td></tr>
	<tr><td>KLF6(Zf)/PDAC-KLF6-ChIP-Seq(GSE64557)/Homer                       </td><td>MKGGGYGTGGCC        </td><td> 1e-10</td><td>  -25.310</td><td>0.0000</td><td>2443</td><td>17.18%</td><td>12742.5</td><td>15.12%</td><td>KLF6                 </td></tr>
	<tr><td>Znf263(Zf)/K562-Znf263-ChIP-Seq(GSE31477)/Homer                   </td><td>CVGTSCTCCC          </td><td> 1e-10</td><td>  -24.920</td><td>0.0000</td><td>3371</td><td>23.70%</td><td>18016.8</td><td>21.39%</td><td>Znf263               </td></tr>
	<tr><td>NRF1(NRF)/MCF7-NRF1-ChIP-Seq(Unpublished)/Homer                   </td><td>CTGCGCATGCGC        </td><td> 1e-10</td><td>  -24.570</td><td>0.0000</td><td> 238</td><td>1.67% </td><td>  891.3</td><td>1.06% </td><td>NRF1                 </td></tr>
	<tr><td>YY1(Zf)/Promoter/Homer                                            </td><td>CAAGATGGCGGC        </td><td> 1e-08</td><td>  -20.330</td><td>0.0000</td><td>  85</td><td>0.60% </td><td>  244.1</td><td>0.29% </td><td>YY1                  </td></tr>
	<tr><td>E2F6(E2F)/Hela-E2F6-ChIP-Seq(GSE31477)/Homer                      </td><td>GGCGGGAARN          </td><td> 1e-08</td><td>  -19.460</td><td>0.0000</td><td>1286</td><td>9.04% </td><td> 6497.2</td><td>7.71% </td><td>E2F6                 </td></tr>
	<tr><td>KLF3(Zf)/MEF-Klf3-ChIP-Seq(GSE44748)/Homer                        </td><td>NRGCCCCRCCCHBNN     </td><td> 1e-07</td><td>  -17.820</td><td>0.0000</td><td>1205</td><td>8.47% </td><td> 6102.7</td><td>7.24% </td><td>KLF3                 </td></tr>
	<tr><td>NRF(NRF)/Promoter/Homer                                           </td><td>STGCGCATGCGC        </td><td> 1e-07</td><td>  -17.230</td><td>0.0000</td><td> 273</td><td>1.92% </td><td> 1146.3</td><td>1.36% </td><td>NRF                  </td></tr>
	<tr><td>E2F3(E2F)/MEF-E2F3-ChIP-Seq(GSE71376)/Homer                       </td><td>BTKGGCGGGAAA        </td><td> 1e-07</td><td>  -17.130</td><td>0.0000</td><td>1438</td><td>10.11%</td><td> 7415.9</td><td>8.80% </td><td>E2F3                 </td></tr>
	<tr><td>Ptf1a(bHLH)/Panc1-Ptf1a-ChIP-Seq(GSE47459)/Homer                  </td><td>ACAGCTGTTN          </td><td> 1e-05</td><td>  -13.300</td><td>0.0000</td><td>4665</td><td>32.80%</td><td>26104.2</td><td>30.98%</td><td>Ptf1a                </td></tr>
	<tr><td>ZBTB12(Zf)/HEK293-ZBTB12.GFP-ChIP-Seq(GSE58341)/Homer             </td><td>NGNTCTAGAACCNGV     </td><td> 1e-05</td><td>  -12.800</td><td>0.0000</td><td> 461</td><td>3.24% </td><td> 2198.7</td><td>2.61% </td><td>ZBTB12               </td></tr>
	<tr><td>HIC1(Zf)/Treg-ZBTB29-ChIP-Seq(GSE99889)/Homer                     </td><td>TGCCAGCB            </td><td> 1e-05</td><td>  -12.650</td><td>0.0001</td><td>3837</td><td>26.98%</td><td>21330.6</td><td>25.32%</td><td>HIC1                 </td></tr>
	<tr><td>Pax7(Paired,Homeobox),long/Myoblast-Pax7-ChIP-Seq(GSE25064)/Homer </td><td>TAATCHGATTAC        </td><td> 1e-04</td><td>  -10.910</td><td>0.0003</td><td>  44</td><td>0.31% </td><td>  129.9</td><td>0.15% </td><td>Pax7                 </td></tr>
	<tr><td>Duxbl(Homeobox)/NIH3T3-Duxbl.HA-ChIP-Seq(GSE119782)/Homer         </td><td>TAAYCYAATCAA        </td><td> 1e-04</td><td>   -9.696</td><td>0.0009</td><td>  91</td><td>0.64% </td><td>  349.0</td><td>0.41% </td><td>Duxbl                </td></tr>
	<tr><td>STAT6(Stat)/Macrophage-Stat6-ChIP-Seq(GSE38377)/Homer             </td><td>TTCCKNAGAA          </td><td> 1e-04</td><td>   -9.672</td><td>0.0009</td><td> 695</td><td>4.89% </td><td> 3557.4</td><td>4.22% </td><td>STAT6                </td></tr>
	<tr><td>ZNF415(Zf)/HEK293-ZNF415.GFP-ChIP-Seq(GSE58341)/Homer             </td><td>GRTGMTRGAGCC        </td><td> 1e-04</td><td>   -9.477</td><td>0.0011</td><td> 845</td><td>5.94% </td><td> 4396.4</td><td>5.22% </td><td>ZNF415               </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer       </td><td>GCTGTGGTTW      </td><td>1</td><td>0</td><td>1</td><td> 872</td><td>6.13% </td><td> 6639.9</td><td>7.88% </td><td>RUNX-AML      </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer              </td><td>RACCGGAAGT      </td><td>1</td><td>0</td><td>1</td><td>1459</td><td>10.26%</td><td>10477.8</td><td>12.44%</td><td>GABPA         </td></tr>
	<tr><td>Gata4(Zf)/Heart-Gata4-ChIP-Seq(GSE35151)/Homer                </td><td>NBWGATAAGR      </td><td>1</td><td>0</td><td>1</td><td>1055</td><td>7.42% </td><td> 7875.6</td><td>9.35% </td><td>Gata4         </td></tr>
	<tr><td>TRPS1(Zf)/MCF7-TRPS1-ChIP-Seq(GSE107013)/Homer                </td><td>AGATAAGANN      </td><td>1</td><td>0</td><td>1</td><td>2108</td><td>14.82%</td><td>14644.2</td><td>17.38%</td><td>TRPS1         </td></tr>
	<tr><td>Usf2(bHLH)/C2C12-Usf2-ChIP-Seq(GSE36030)/Homer                </td><td>GTCACGTGGT      </td><td>1</td><td>0</td><td>1</td><td> 365</td><td>2.57% </td><td> 3211.1</td><td>3.81% </td><td>Usf2          </td></tr>
	<tr><td>Bapx1(Homeobox)/VertebralCol-Bapx1-ChIP-Seq(GSE36672)/Homer   </td><td>TTRAGTGSYK      </td><td>1</td><td>0</td><td>1</td><td>2645</td><td>18.60%</td><td>18992.1</td><td>22.54%</td><td>Bapx1         </td></tr>
	<tr><td>CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer             </td><td>ATTGCGCAAC      </td><td>1</td><td>0</td><td>1</td><td> 765</td><td>5.38% </td><td> 6512.6</td><td>7.73% </td><td>CEBP          </td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                    </td><td>AVCAGGAAGT      </td><td>1</td><td>0</td><td>1</td><td>1978</td><td>13.91%</td><td>14416.0</td><td>17.11%</td><td>EHF           </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                  </td><td>ANCAGGAAGT      </td><td>1</td><td>0</td><td>1</td><td>1058</td><td>7.44% </td><td> 8402.2</td><td>9.97% </td><td>ELF3          </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                  </td><td>ACTTCCKGKT      </td><td>1</td><td>0</td><td>1</td><td>1565</td><td>11.00%</td><td>12248.0</td><td>14.54%</td><td>Elf4          </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                  </td><td>ACVAGGAAGT      </td><td>1</td><td>0</td><td>1</td><td>1083</td><td>7.61% </td><td> 8768.7</td><td>10.41%</td><td>ELF5          </td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                    </td><td>ACAGGAAGTG      </td><td>1</td><td>0</td><td>1</td><td>2629</td><td>18.48%</td><td>18800.9</td><td>22.32%</td><td>ERG           </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                </td><td>ACAGGAAGTG      </td><td>1</td><td>0</td><td>1</td><td>1663</td><td>11.69%</td><td>12594.6</td><td>14.95%</td><td>ETS1          </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer     </td><td>MACAGGAAGT      </td><td>1</td><td>0</td><td>1</td><td> 447</td><td>3.14% </td><td> 3850.6</td><td>4.57% </td><td>Ets1-distal   </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                </td><td>AACCGGAAGT      </td><td>1</td><td>0</td><td>1</td><td>2283</td><td>16.05%</td><td>16324.3</td><td>19.38%</td><td>ETV1          </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                    </td><td>NNAYTTCCTGHN    </td><td>1</td><td>0</td><td>1</td><td>1538</td><td>10.81%</td><td>11694.1</td><td>13.88%</td><td>Etv2          </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer</td><td>ATTTCCTGTN      </td><td>1</td><td>0</td><td>1</td><td>1133</td><td>7.97% </td><td> 8562.0</td><td>10.16%</td><td>EWS:ERG-fusion</td></tr>
	<tr><td>Gata2(Zf)/K562-GATA2-ChIP-Seq(GSE18829)/Homer                 </td><td>BBCTTATCTS      </td><td>1</td><td>0</td><td>1</td><td> 650</td><td>4.57% </td><td> 5242.8</td><td>6.22% </td><td>Gata2         </td></tr>
	<tr><td>GATA3(Zf)/iTreg-Gata3-ChIP-Seq(GSE20898)/Homer                </td><td>AGATAASR        </td><td>1</td><td>0</td><td>1</td><td>1574</td><td>11.07%</td><td>11329.4</td><td>13.45%</td><td>GATA3         </td></tr>
	<tr><td>Gata6(Zf)/HUG1N-GATA6-ChIP-Seq(GSE51936)/Homer                </td><td>YCTTATCTBN      </td><td>1</td><td>0</td><td>1</td><td> 925</td><td>6.50% </td><td> 7155.4</td><td>8.49% </td><td>Gata6         </td></tr>
	<tr><td>Gata1(Zf)/K562-GATA1-ChIP-Seq(GSE18829)/Homer                 </td><td>SAGATAAGRV      </td><td>1</td><td>0</td><td>1</td><td> 580</td><td>4.08% </td><td> 4749.1</td><td>5.64% </td><td>Gata1         </td></tr>
	<tr><td>Mef2a(MADS)/HL1-Mef2a.biotin-ChIP-Seq(GSE21529)/Homer         </td><td>CYAAAAATAG      </td><td>1</td><td>0</td><td>1</td><td> 540</td><td>3.80% </td><td> 5563.6</td><td>6.60% </td><td>Mef2a         </td></tr>
	<tr><td>Mef2b(MADS)/HEK293-Mef2b.V5-ChIP-Seq(GSE67450)/Homer          </td><td>GCTATTTTTGGM    </td><td>1</td><td>0</td><td>1</td><td>1044</td><td>7.34% </td><td> 8512.6</td><td>10.10%</td><td>Mef2b         </td></tr>
	<tr><td>Mef2c(MADS)/GM12878-Mef2c-ChIP-Seq(GSE32465)/Homer            </td><td>DCYAAAAATAGM    </td><td>1</td><td>0</td><td>1</td><td> 632</td><td>4.44% </td><td> 5985.6</td><td>7.10% </td><td>Mef2c         </td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer                </td><td>CYTGGCABNSTGCCAR</td><td>1</td><td>0</td><td>1</td><td> 659</td><td>4.63% </td><td> 5693.0</td><td>6.76% </td><td>NF1           </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer                </td><td>VTTACGTAAYNNNNN </td><td>1</td><td>0</td><td>1</td><td> 640</td><td>4.50% </td><td> 5425.4</td><td>6.44% </td><td>NFIL3         </td></tr>
	<tr><td>EAR2(NR)/K562-NR2F6-ChIP-Seq(Encode)/Homer                    </td><td>NRBCARRGGTCA    </td><td>1</td><td>0</td><td>1</td><td>1695</td><td>11.92%</td><td>12449.4</td><td>14.78%</td><td>EAR2          </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer               </td><td>AGAGGAAGTG      </td><td>1</td><td>0</td><td>1</td><td> 735</td><td>5.17% </td><td> 6135.5</td><td>7.28% </td><td>PU.1          </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                </td><td>NWAACCACADNN    </td><td>1</td><td>0</td><td>1</td><td> 959</td><td>6.74% </td><td> 7308.8</td><td>8.68% </td><td>RUNX2         </td></tr>
	<tr><td>Sox15(HMG)/CPA-Sox15-ChIP-Seq(GSE62909)/Homer                 </td><td>RAACAATGGN      </td><td>1</td><td>0</td><td>1</td><td>1265</td><td>8.89% </td><td> 9429.0</td><td>11.19%</td><td>Sox15         </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_6</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer          </td><td>ATTGCGCAAC     </td><td>1e-307</td><td>-1942.00</td><td>0</td><td>2995</td><td>29.61%</td><td> 9333.8</td><td>8.26% </td><td>CEBP    </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer             </td><td>VTTACGTAAYNNNNN</td><td>1e-307</td><td>-1350.00</td><td>0</td><td>2291</td><td>22.65%</td><td> 7475.7</td><td>6.62% </td><td>NFIL3   </td></tr>
	<tr><td>HLF(bZIP)/HSC-HLF.Flag-ChIP-Seq(GSE69817)/Homer            </td><td>RTTATGYAAB     </td><td>1e-307</td><td> -835.80</td><td>0</td><td>2253</td><td>22.28%</td><td> 9967.8</td><td>8.82% </td><td>HLF     </td></tr>
	<tr><td>CEBP:AP1(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer      </td><td>DRTGTTGCAA     </td><td>1e-286</td><td> -658.90</td><td>0</td><td>2023</td><td>20.00%</td><td> 9523.2</td><td>8.43% </td><td>CEBP:AP1</td></tr>
	<tr><td>Atf4(bZIP)/MEF-Atf4-ChIP-Seq(GSE35681)/Homer               </td><td>MTGATGCAAT     </td><td>1e-216</td><td> -497.80</td><td>0</td><td> 966</td><td>9.55% </td><td> 3316.7</td><td>2.94% </td><td>Atf4    </td></tr>
	<tr><td>Chop(bZIP)/MEF-Chop-ChIP-Seq(GSE35681)/Homer               </td><td>ATTGCATCAT     </td><td>1e-147</td><td> -338.90</td><td>0</td><td> 714</td><td>7.06% </td><td> 2578.0</td><td>2.28% </td><td>Chop    </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer               </td><td>ACTTCCKGKT     </td><td> 1e-71</td><td> -164.00</td><td>0</td><td>2192</td><td>21.67%</td><td>16914.3</td><td>14.97%</td><td>Elf4    </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer               </td><td>ACVAGGAAGT     </td><td> 1e-69</td><td> -159.60</td><td>0</td><td>1746</td><td>17.26%</td><td>12794.0</td><td>11.33%</td><td>ELF5    </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer             </td><td>AACCGGAAGT     </td><td> 1e-60</td><td> -140.10</td><td>0</td><td>2642</td><td>26.12%</td><td>21881.4</td><td>19.37%</td><td>ETV1    </td></tr>
	<tr><td>GSC(Homeobox)/FrogEmbryos-GSC-ChIP-Seq(DRA000576)/Homer    </td><td>RGGATTAR       </td><td> 1e-60</td><td> -139.40</td><td>0</td><td>1949</td><td>19.27%</td><td>15116.9</td><td>13.38%</td><td>GSC     </td></tr>
	<tr><td>Atf1(bZIP)/K562-ATF1-ChIP-Seq(GSE31477)/Homer              </td><td>GATGACGTCA     </td><td> 1e-58</td><td> -134.00</td><td>0</td><td>1059</td><td>10.47%</td><td> 7042.5</td><td>6.23% </td><td>Atf1    </td></tr>
	<tr><td>Gfi1b(Zf)/HPC7-Gfi1b-ChIP-Seq(GSE22178)/Homer              </td><td>MAATCACTGC     </td><td> 1e-50</td><td> -116.70</td><td>0</td><td>1209</td><td>11.95%</td><td> 8667.8</td><td>7.67% </td><td>Gfi1b   </td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                 </td><td>AVCAGGAAGT     </td><td> 1e-48</td><td> -111.10</td><td>0</td><td>2542</td><td>25.13%</td><td>21668.9</td><td>19.18%</td><td>EHF     </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer             </td><td>AAAGRGGAAGTG   </td><td> 1e-46</td><td> -106.00</td><td>0</td><td> 777</td><td>7.68% </td><td> 5031.6</td><td>4.45% </td><td>SpiB    </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer               </td><td>ANCAGGAAGT     </td><td> 1e-45</td><td> -103.80</td><td>0</td><td>1661</td><td>16.42%</td><td>13171.1</td><td>11.66%</td><td>ELF3    </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer            </td><td>AGAGGAAGTG     </td><td> 1e-40</td><td>  -93.40</td><td>0</td><td>1243</td><td>12.29%</td><td> 9445.9</td><td>8.36% </td><td>PU.1    </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer             </td><td>ACAGGAAGTG     </td><td> 1e-39</td><td>  -89.81</td><td>0</td><td>2084</td><td>20.61%</td><td>17697.2</td><td>15.67%</td><td>ETS1    </td></tr>
	<tr><td>Nkx2.2(Homeobox)/NPC-Nkx2.2-ChIP-Seq(GSE61673)/Homer       </td><td>BTBRAGTGSN     </td><td> 1e-35</td><td>  -82.09</td><td>0</td><td>2806</td><td>27.74%</td><td>25308.1</td><td>22.41%</td><td>Nkx2.2  </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer           </td><td>RACCGGAAGT     </td><td> 1e-35</td><td>  -81.02</td><td>0</td><td>1720</td><td>17.01%</td><td>14342.3</td><td>12.70%</td><td>GABPA   </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                </td><td>ACCGGAAGTG     </td><td> 1e-31</td><td>  -71.99</td><td>0</td><td>1932</td><td>19.10%</td><td>16728.0</td><td>14.81%</td><td>ETV4    </td></tr>
	<tr><td>Bapx1(Homeobox)/VertebralCol-Bapx1-ChIP-Seq(GSE36672)/Homer</td><td>TTRAGTGSYK     </td><td> 1e-28</td><td>  -65.79</td><td>0</td><td>3069</td><td>30.34%</td><td>28698.1</td><td>25.41%</td><td>Bapx1   </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer      </td><td>MGGAAGTGAAAC   </td><td> 1e-28</td><td>  -65.16</td><td>0</td><td>2158</td><td>21.34%</td><td>19255.2</td><td>17.05%</td><td>PU.1-IRF</td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                 </td><td>ACAGGAAGTG     </td><td> 1e-27</td><td>  -63.35</td><td>0</td><td>2895</td><td>28.62%</td><td>26970.1</td><td>23.88%</td><td>ERG     </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer            </td><td>AVCCGGAAGT     </td><td> 1e-27</td><td>  -63.07</td><td>0</td><td> 876</td><td>8.66% </td><td> 6693.2</td><td>5.93% </td><td>ELF1    </td></tr>
	<tr><td>CRX(Homeobox)/Retina-Crx-ChIP-Seq(GSE20012)/Homer          </td><td>GCTAATCC       </td><td> 1e-25</td><td>  -58.55</td><td>0</td><td>2950</td><td>29.17%</td><td>27758.1</td><td>24.57%</td><td>CRX     </td></tr>
	<tr><td>Klf4(Zf)/mES-Klf4-ChIP-Seq(GSE11431)/Homer                 </td><td>GCCACACCCA     </td><td> 1e-23</td><td>  -53.09</td><td>0</td><td> 501</td><td>4.95% </td><td> 3486.8</td><td>3.09% </td><td>Klf4    </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                 </td><td>NNAYTTCCTGHN   </td><td> 1e-22</td><td>  -51.63</td><td>0</td><td>1899</td><td>18.78%</td><td>17120.4</td><td>15.16%</td><td>Etv2    </td></tr>
	<tr><td>Atf7(bZIP)/3T3L1-Atf7-ChIP-Seq(GSE56872)/Homer             </td><td>NGRTGACGTCAY   </td><td> 1e-20</td><td>  -46.84</td><td>0</td><td> 639</td><td>6.32% </td><td> 4860.5</td><td>4.30% </td><td>Atf7    </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                    </td><td>AACCGGAAGT     </td><td> 1e-19</td><td>  -45.45</td><td>0</td><td> 590</td><td>5.83% </td><td> 4439.6</td><td>3.93% </td><td>ETS     </td></tr>
	<tr><td>Nkx2.5(Homeobox)/HL1-Nkx2.5.biotin-ChIP-Seq(GSE21529)/Homer</td><td>RRSCACTYAA     </td><td> 1e-19</td><td>  -44.91</td><td>0</td><td>2896</td><td>28.63%</td><td>27839.2</td><td>24.65%</td><td>Nkx2.5  </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>FOXK1(Forkhead)/HEK293-FOXK1-ChIP-Seq(GSE51673)/Homer       </td><td>NVWTGTTTAC      </td><td>1</td><td>0</td><td>1</td><td> 905</td><td>8.95% </td><td>13814.7</td><td>12.23%</td><td>FOXK1       </td></tr>
	<tr><td>FOXK2(Forkhead)/U2OS-FOXK2-ChIP-Seq(E-MTAB-2204)/Homer      </td><td>SCHTGTTTACAT    </td><td>1</td><td>0</td><td>1</td><td> 559</td><td>5.53% </td><td> 8619.7</td><td>7.63% </td><td>FOXK2       </td></tr>
	<tr><td>FoxL2(Forkhead)/Ovary-FoxL2-ChIP-Seq(GSE60858)/Homer        </td><td>WWTRTAAACAVG    </td><td>1</td><td>0</td><td>1</td><td> 761</td><td>7.52% </td><td>11370.8</td><td>10.07%</td><td>FoxL2       </td></tr>
	<tr><td>FOXM1(Forkhead)/MCF7-FOXM1-ChIP-Seq(GSE72977)/Homer         </td><td>TRTTTACTTW      </td><td>1</td><td>0</td><td>1</td><td> 956</td><td>9.45% </td><td>14167.5</td><td>12.54%</td><td>FOXM1       </td></tr>
	<tr><td>Foxo3(Forkhead)/U2OS-Foxo3-ChIP-Seq(E-MTAB-2701)/Homer      </td><td>DGTAAACA        </td><td>1</td><td>0</td><td>1</td><td> 615</td><td>6.08% </td><td>10316.2</td><td>9.13% </td><td>Foxo3       </td></tr>
	<tr><td>FOXP1(Forkhead)/H9-FOXP1-ChIP-Seq(GSE31006)/Homer           </td><td>NYYTGTTTACHN    </td><td>1</td><td>0</td><td>1</td><td> 340</td><td>3.36% </td><td> 6090.6</td><td>5.39% </td><td>FOXP1       </td></tr>
	<tr><td>Gata2(Zf)/K562-GATA2-ChIP-Seq(GSE18829)/Homer               </td><td>BBCTTATCTS      </td><td>1</td><td>0</td><td>1</td><td> 546</td><td>5.40% </td><td> 8906.7</td><td>7.89% </td><td>Gata2       </td></tr>
	<tr><td>Gata4(Zf)/Heart-Gata4-ChIP-Seq(GSE35151)/Homer              </td><td>NBWGATAAGR      </td><td>1</td><td>0</td><td>1</td><td> 869</td><td>8.59% </td><td>13436.6</td><td>11.90%</td><td>Gata4       </td></tr>
	<tr><td>Gata6(Zf)/HUG1N-GATA6-ChIP-Seq(GSE51936)/Homer              </td><td>YCTTATCTBN      </td><td>1</td><td>0</td><td>1</td><td> 802</td><td>7.93% </td><td>12363.2</td><td>10.95%</td><td>Gata6       </td></tr>
	<tr><td>Gata1(Zf)/K562-GATA1-ChIP-Seq(GSE18829)/Homer               </td><td>SAGATAAGRV      </td><td>1</td><td>0</td><td>1</td><td> 484</td><td>4.79% </td><td> 7959.1</td><td>7.05% </td><td>Gata1       </td></tr>
	<tr><td>HEB(bHLH)/mES-Heb-ChIP-Seq(GSE53233)/Homer                  </td><td>VCAGCTGBNN      </td><td>1</td><td>0</td><td>1</td><td>1814</td><td>17.94%</td><td>24088.0</td><td>21.33%</td><td>HEB         </td></tr>
	<tr><td>Hoxc9(Homeobox)/Ainv15-Hoxc9-ChIP-Seq(GSE21812)/Homer       </td><td>GGCCATAAATCA    </td><td>1</td><td>0</td><td>1</td><td> 365</td><td>3.61% </td><td> 7093.2</td><td>6.28% </td><td>Hoxc9       </td></tr>
	<tr><td>LEF1(HMG)/H1-LEF1-ChIP-Seq(GSE64758)/Homer                  </td><td>CCTTTGATST      </td><td>1</td><td>0</td><td>1</td><td> 533</td><td>5.27% </td><td> 9217.4</td><td>8.16% </td><td>LEF1        </td></tr>
	<tr><td>Lhx1(Homeobox)/EmbryoCarcinoma-Lhx1-ChIP-Seq(GSE70957)/Homer</td><td>NNYTAATTAR      </td><td>1</td><td>0</td><td>1</td><td>1039</td><td>10.27%</td><td>14739.7</td><td>13.05%</td><td>Lhx1        </td></tr>
	<tr><td>Lhx3(Homeobox)/Neuron-Lhx3-ChIP-Seq(GSE31456)/Homer         </td><td>ADBTAATTAR      </td><td>1</td><td>0</td><td>1</td><td>1573</td><td>15.55%</td><td>21809.6</td><td>19.31%</td><td>Lhx3        </td></tr>
	<tr><td>NF1-halfsite(CTF)/LNCaP-NF1-ChIP-Seq(Unpublished)/Homer     </td><td>YTGCCAAG        </td><td>1</td><td>0</td><td>1</td><td>1752</td><td>17.32%</td><td>23823.8</td><td>21.09%</td><td>NF1-halfsite</td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer              </td><td>CYTGGCABNSTGCCAR</td><td>1</td><td>0</td><td>1</td><td> 373</td><td>3.69% </td><td> 6370.8</td><td>5.64% </td><td>NF1         </td></tr>
	<tr><td>NFAT(RHD)/Jurkat-NFATC1-ChIP-Seq(Jolma_et_al.)/Homer        </td><td>ATTTTCCATT      </td><td>1</td><td>0</td><td>1</td><td> 790</td><td>7.81% </td><td>11695.5</td><td>10.35%</td><td>NFAT        </td></tr>
	<tr><td>PBX2(Homeobox)/K562-PBX2-ChIP-Seq(Encode)/Homer             </td><td>RTGATTKATRGN    </td><td>1</td><td>0</td><td>1</td><td> 679</td><td>6.71% </td><td>10602.1</td><td>9.39% </td><td>PBX2        </td></tr>
	<tr><td>SCL(bHLH)/HPC7-Scl-ChIP-Seq(GSE13511)/Homer                 </td><td>AVCAGCTG        </td><td>1</td><td>0</td><td>1</td><td>4376</td><td>43.27%</td><td>54063.3</td><td>47.86%</td><td>SCL         </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer       </td><td>CCWTTGTYYB      </td><td>1</td><td>0</td><td>1</td><td>1541</td><td>15.24%</td><td>20933.1</td><td>18.53%</td><td>Sox10       </td></tr>
	<tr><td>Sox2(HMG)/mES-Sox2-ChIP-Seq(GSE11431)/Homer                 </td><td>BCCATTGTTC      </td><td>1</td><td>0</td><td>1</td><td> 724</td><td>7.16% </td><td>10937.0</td><td>9.68% </td><td>Sox2        </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer                 </td><td>CCWTTGTY        </td><td>1</td><td>0</td><td>1</td><td>1639</td><td>16.21%</td><td>22428.3</td><td>19.86%</td><td>Sox3        </td></tr>
	<tr><td>Sox4(HMG)/proB-Sox4-ChIP-Seq(GSE50066)/Homer                </td><td>YCTTTGTTCC      </td><td>1</td><td>0</td><td>1</td><td> 704</td><td>6.96% </td><td>10688.7</td><td>9.46% </td><td>Sox4        </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer                </td><td>AGGVNCCTTTGT    </td><td>1</td><td>0</td><td>1</td><td> 709</td><td>7.01% </td><td>10742.1</td><td>9.51% </td><td>Sox9        </td></tr>
	<tr><td>Tcf12(bHLH)/GM12878-Tcf12-ChIP-Seq(GSE32465)/Homer          </td><td>VCAGCTGYTG      </td><td>1</td><td>0</td><td>1</td><td> 830</td><td>8.21% </td><td>12137.2</td><td>10.75%</td><td>Tcf12       </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer              </td><td>CYRCATTCCA      </td><td>1</td><td>0</td><td>1</td><td> 792</td><td>7.83% </td><td>11880.8</td><td>10.52%</td><td>TEAD1       </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer               </td><td>TRCATTCCAG      </td><td>1</td><td>0</td><td>1</td><td> 955</td><td>9.44% </td><td>13686.5</td><td>12.12%</td><td>TEAD3       </td></tr>
	<tr><td>TRPS1(Zf)/MCF7-TRPS1-ChIP-Seq(GSE107013)/Homer              </td><td>AGATAAGANN      </td><td>1</td><td>0</td><td>1</td><td>1889</td><td>18.68%</td><td>25286.5</td><td>22.39%</td><td>TRPS1       </td></tr>
	<tr><td>ZEB1(Zf)/PDAC-ZEB1-ChIP-Seq(GSE64557)/Homer                 </td><td>VCAGGTRDRY      </td><td>1</td><td>0</td><td>1</td><td>1206</td><td>11.92%</td><td>17263.9</td><td>15.28%</td><td>ZEB1        </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_7</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>EBF2(EBF)/BrownAdipose-EBF2-ChIP-Seq(GSE97114)/Homer            </td><td>NABTCCCWDGGGAVH </td><td>1e-78</td><td>-181.60</td><td>0</td><td> 763</td><td>19.55%</td><td>11339.9</td><td>9.57% </td><td>EBF2        </td></tr>
	<tr><td>EBF(EBF)/proBcell-EBF-ChIP-Seq(GSE21978)/Homer                  </td><td>DGTCCCYRGGGA    </td><td>1e-78</td><td>-181.10</td><td>0</td><td> 310</td><td>7.94% </td><td> 2641.2</td><td>2.23% </td><td>EBF         </td></tr>
	<tr><td>E2A(bHLH),near_PU.1/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer         </td><td>NVCACCTGBN      </td><td>1e-67</td><td>-155.30</td><td>0</td><td>1051</td><td>26.93%</td><td>18887.3</td><td>15.94%</td><td>E2A         </td></tr>
	<tr><td>Mef2c(MADS)/GM12878-Mef2c-ChIP-Seq(GSE32465)/Homer              </td><td>DCYAAAAATAGM    </td><td>1e-60</td><td>-140.20</td><td>0</td><td> 567</td><td>14.53%</td><td> 8186.6</td><td>6.91% </td><td>Mef2c       </td></tr>
	<tr><td>E2A(bHLH)/proBcell-E2A-ChIP-Seq(GSE21978)/Homer                 </td><td>DNRCAGCTGY      </td><td>1e-58</td><td>-133.70</td><td>0</td><td>1146</td><td>29.37%</td><td>22135.7</td><td>18.68%</td><td>E2A         </td></tr>
	<tr><td>Slug(Zf)/Mesoderm-Snai2-ChIP-Seq(GSE61475)/Homer                </td><td>SNGCACCTGCHS    </td><td>1e-56</td><td>-130.60</td><td>0</td><td> 538</td><td>13.79%</td><td> 7815.9</td><td>6.60% </td><td>Slug        </td></tr>
	<tr><td>Ascl2(bHLH)/ESC-Ascl2-ChIP-Seq(GSE97712)/Homer                  </td><td>SSRGCAGCTGCH    </td><td>1e-53</td><td>-122.10</td><td>0</td><td> 931</td><td>23.86%</td><td>17205.2</td><td>14.52%</td><td>Ascl2       </td></tr>
	<tr><td>PU.1:IRF8(ETS:IRF)/pDC-Irf8-ChIP-Seq(GSE66899)/Homer            </td><td>GGAAGTGAAAST    </td><td>1e-52</td><td>-121.90</td><td>0</td><td> 284</td><td>7.28% </td><td> 3011.4</td><td>2.54% </td><td>PU.1:IRF8   </td></tr>
	<tr><td>Mef2a(MADS)/HL1-Mef2a.biotin-ChIP-Seq(GSE21529)/Homer           </td><td>CYAAAAATAG      </td><td>1e-51</td><td>-117.80</td><td>0</td><td> 504</td><td>12.92%</td><td> 7429.3</td><td>6.27% </td><td>Mef2a       </td></tr>
	<tr><td>ZEB1(Zf)/PDAC-ZEB1-ChIP-Seq(GSE64557)/Homer                     </td><td>VCAGGTRDRY      </td><td>1e-49</td><td>-113.10</td><td>0</td><td>1038</td><td>26.60%</td><td>20280.4</td><td>17.11%</td><td>ZEB1        </td></tr>
	<tr><td>HEB(bHLH)/mES-Heb-ChIP-Seq(GSE53233)/Homer                      </td><td>VCAGCTGBNN      </td><td>1e-41</td><td> -96.18</td><td>0</td><td>1332</td><td>34.14%</td><td>28922.7</td><td>24.40%</td><td>HEB         </td></tr>
	<tr><td>Mef2b(MADS)/HEK293-Mef2b.V5-ChIP-Seq(GSE67450)/Homer            </td><td>GCTATTTTTGGM    </td><td>1e-41</td><td> -95.37</td><td>0</td><td> 684</td><td>17.53%</td><td>12255.8</td><td>10.34%</td><td>Mef2b       </td></tr>
	<tr><td>IRF8(IRF)/BMDM-IRF8-ChIP-Seq(GSE77884)/Homer                    </td><td>GRAASTGAAAST    </td><td>1e-39</td><td> -91.40</td><td>0</td><td> 348</td><td>8.92% </td><td> 4836.2</td><td>4.08% </td><td>IRF8        </td></tr>
	<tr><td>Ptf1a(bHLH)/Panc1-Ptf1a-ChIP-Seq(GSE47459)/Homer                </td><td>ACAGCTGTTN      </td><td>1e-32</td><td> -75.79</td><td>0</td><td>1618</td><td>41.47%</td><td>38233.5</td><td>32.26%</td><td>Ptf1a       </td></tr>
	<tr><td>PAX5(Paired,Homeobox)/GM12878-PAX5-ChIP-Seq(GSE32465)/Homer     </td><td>GCAGCCAAGCRTGACH</td><td>1e-31</td><td> -71.51</td><td>0</td><td> 304</td><td>7.79% </td><td> 4434.0</td><td>3.74% </td><td>PAX5        </td></tr>
	<tr><td>Bapx1(Homeobox)/VertebralCol-Bapx1-ChIP-Seq(GSE36672)/Homer     </td><td>TTRAGTGSYK      </td><td>1e-29</td><td> -69.01</td><td>0</td><td>1323</td><td>33.91%</td><td>30386.0</td><td>25.64%</td><td>Bapx1       </td></tr>
	<tr><td>ZEB2(Zf)/SNU398-ZEB2-ChIP-Seq(GSE103048)/Homer                  </td><td>GNMCAGGTGTGC    </td><td>1e-29</td><td> -66.98</td><td>0</td><td> 594</td><td>15.22%</td><td>11266.3</td><td>9.51% </td><td>ZEB2        </td></tr>
	<tr><td>EBF1(EBF)/Near-E2A-ChIP-Seq(GSE21512)/Homer                     </td><td>GTCCCCWGGGGA    </td><td>1e-28</td><td> -65.91</td><td>0</td><td> 727</td><td>18.63%</td><td>14641.7</td><td>12.35%</td><td>EBF1        </td></tr>
	<tr><td>IRF3(IRF)/BMDM-Irf3-ChIP-Seq(GSE67343)/Homer                    </td><td>AGTTTCAKTTTC    </td><td>1e-25</td><td> -58.68</td><td>0</td><td> 308</td><td>7.89% </td><td> 4893.6</td><td>4.13% </td><td>IRF3        </td></tr>
	<tr><td>GLIS3(Zf)/Thyroid-Glis3.GFP-ChIP-Seq(GSE103297)/Homer           </td><td>CTCCCTGGGAGGCCN </td><td>1e-24</td><td> -56.95</td><td>0</td><td>1134</td><td>29.06%</td><td>26011.9</td><td>21.95%</td><td>GLIS3       </td></tr>
	<tr><td>Oct11(POU,Homeobox)/NCIH1048-POU2F3-ChIP-seq(GSE115123)/Homer   </td><td>GATTTGCATA      </td><td>1e-23</td><td> -54.79</td><td>0</td><td> 240</td><td>6.15% </td><td> 3544.5</td><td>2.99% </td><td>Oct11       </td></tr>
	<tr><td>Ascl1(bHLH)/NeuralTubes-Ascl1-ChIP-Seq(GSE55840)/Homer          </td><td>NNVVCAGCTGBN    </td><td>1e-20</td><td> -46.18</td><td>0</td><td>1004</td><td>25.73%</td><td>23246.6</td><td>19.62%</td><td>Ascl1       </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer           </td><td>MGGAAGTGAAAC    </td><td>1e-19</td><td> -44.71</td><td>0</td><td> 814</td><td>20.86%</td><td>18200.1</td><td>15.36%</td><td>PU.1-IRF    </td></tr>
	<tr><td>Oct2(POU,Homeobox)/Bcell-Oct2-ChIP-Seq(GSE21512)/Homer          </td><td>ATATGCAAAT      </td><td>1e-18</td><td> -42.48</td><td>0</td><td> 215</td><td>5.51% </td><td> 3371.4</td><td>2.84% </td><td>Oct2        </td></tr>
	<tr><td>Nkx2.2(Homeobox)/NPC-Nkx2.2-ChIP-Seq(GSE61673)/Homer            </td><td>BTBRAGTGSN      </td><td>1e-16</td><td> -37.12</td><td>0</td><td>1120</td><td>28.70%</td><td>27240.9</td><td>22.99%</td><td>Nkx2.2      </td></tr>
	<tr><td>Oct4(POU,Homeobox)/mES-Oct4-ChIP-Seq(GSE11431)/Homer            </td><td>ATTTGCATAW      </td><td>1e-15</td><td> -35.09</td><td>0</td><td> 293</td><td>7.51% </td><td> 5432.0</td><td>4.58% </td><td>Oct4        </td></tr>
	<tr><td>NFkB-p50,p52(RHD)/Monocyte-p50-ChIP-Chip(Schreiber_et_al.)/Homer</td><td>GGGGGAATCCCC    </td><td>1e-14</td><td> -33.72</td><td>0</td><td> 104</td><td>2.67% </td><td> 1313.7</td><td>1.11% </td><td>NFkB-p50,p52</td></tr>
	<tr><td>IRF1(IRF)/PBMC-IRF1-ChIP-Seq(GSE43036)/Homer                    </td><td>GAAAGTGAAAGT    </td><td>1e-12</td><td> -29.76</td><td>0</td><td> 145</td><td>3.72% </td><td> 2252.6</td><td>1.90% </td><td>IRF1        </td></tr>
	<tr><td>IRF4(IRF)/GM12878-IRF4-ChIP-Seq(GSE32465)/Homer                 </td><td>ACTGAAACCA      </td><td>1e-12</td><td> -28.20</td><td>0</td><td> 283</td><td>7.25% </td><td> 5520.5</td><td>4.66% </td><td>IRF4        </td></tr>
	<tr><td>Pax8(Paired,Homeobox)/Thyroid-Pax8-ChIP-Seq(GSE26938)/Homer     </td><td>GTCATGCHTGRCTGS </td><td>1e-12</td><td> -27.74</td><td>0</td><td> 237</td><td>6.07% </td><td> 4430.9</td><td>3.74% </td><td>Pax8        </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>BMYB(HTH)/Hela-BMYB-ChIP-Seq(GSE27030)/Homer           </td><td>NHAACBGYYV          </td><td>1</td><td>0</td><td>1</td><td> 481</td><td>12.33%</td><td>18427.9</td><td>15.55%</td><td>BMYB        </td></tr>
	<tr><td>Nanog(Homeobox)/mES-Nanog-ChIP-Seq(GSE11724)/Homer     </td><td>RGCCATTAAC          </td><td>1</td><td>0</td><td>1</td><td>1385</td><td>35.49%</td><td>47507.5</td><td>40.09%</td><td>Nanog       </td></tr>
	<tr><td>TEAD2(TEA)/Py2T-Tead2-ChIP-Seq(GSE55709)/Homer         </td><td>CCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 113</td><td>2.90% </td><td> 5660.1</td><td>4.78% </td><td>TEAD2       </td></tr>
	<tr><td>Tgif2(Homeobox)/mES-Tgif2-ChIP-Seq(GSE55404)/Homer     </td><td>TGTCANYT            </td><td>1</td><td>0</td><td>1</td><td>1201</td><td>30.78%</td><td>41811.2</td><td>35.28%</td><td>Tgif2       </td></tr>
	<tr><td>Zic(Zf)/Cerebellum-ZIC1.2-ChIP-Seq(GSE60731)/Homer     </td><td>CCTGCTGAGH          </td><td>1</td><td>0</td><td>1</td><td> 268</td><td>6.87% </td><td>11312.0</td><td>9.54% </td><td>Zic         </td></tr>
	<tr><td>STAT4(Stat)/CD4-Stat4-ChIP-Seq(GSE22104)/Homer         </td><td>NYTTCCWGGAAR        </td><td>1</td><td>0</td><td>1</td><td> 263</td><td>6.74% </td><td>11141.3</td><td>9.40% </td><td>STAT4       </td></tr>
	<tr><td>Stat3+il21(Stat)/CD4-Stat3-ChIP-Seq(GSE19198)/Homer    </td><td>SVYTTCCNGGAARB      </td><td>1</td><td>0</td><td>1</td><td> 179</td><td>4.59% </td><td> 8160.7</td><td>6.89% </td><td>Stat3+il21  </td></tr>
	<tr><td>Nkx6.1(Homeobox)/Islet-Nkx6.1-ChIP-Seq(GSE40975)/Homer </td><td>GKTAATGR            </td><td>1</td><td>0</td><td>1</td><td> 801</td><td>20.53%</td><td>29175.0</td><td>24.62%</td><td>Nkx6.1      </td></tr>
	<tr><td>Smad3(MAD)/NPC-Smad3-ChIP-Seq(GSE36673)/Homer          </td><td>TWGTCTGV            </td><td>1</td><td>0</td><td>1</td><td> 984</td><td>25.22%</td><td>35081.9</td><td>29.60%</td><td>Smad3       </td></tr>
	<tr><td>PR(NR)/T47D-PR-ChIP-Seq(GSE31130)/Homer                </td><td>VAGRACAKNCTGTBC     </td><td>1</td><td>0</td><td>1</td><td> 654</td><td>16.76%</td><td>24455.4</td><td>20.64%</td><td>PR          </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer           </td><td>AGGVNCCTTTGT        </td><td>1</td><td>0</td><td>1</td><td> 238</td><td>6.10% </td><td>10371.3</td><td>8.75% </td><td>Sox9        </td></tr>
	<tr><td>AR-halfsite(NR)/LNCaP-AR-ChIP-Seq(GSE27824)/Homer      </td><td>CCAGGAACAG          </td><td>1</td><td>0</td><td>1</td><td>1314</td><td>33.68%</td><td>45564.4</td><td>38.45%</td><td>AR-halfsite </td></tr>
	<tr><td>Tlx?(NR)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer          </td><td>CTGGCAGSCTGCCA      </td><td>1</td><td>0</td><td>1</td><td> 137</td><td>3.51% </td><td> 6954.8</td><td>5.87% </td><td>Tlx?        </td></tr>
	<tr><td>TEAD(TEA)/Fibroblast-PU.1-ChIP-Seq(Unpublished)/Homer  </td><td>YCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 142</td><td>3.64% </td><td> 7223.5</td><td>6.10% </td><td>TEAD        </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer          </td><td>TRCATTCCAG          </td><td>1</td><td>0</td><td>1</td><td> 276</td><td>7.07% </td><td>12452.4</td><td>10.51%</td><td>TEAD3       </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer   </td><td>CCWGGAATGY          </td><td>1</td><td>0</td><td>1</td><td> 192</td><td>4.92% </td><td> 9456.0</td><td>7.98% </td><td>TEAD4       </td></tr>
	<tr><td>GATA3(Zf)/iTreg-Gata3-ChIP-Seq(GSE20898)/Homer         </td><td>AGATAASR            </td><td>1</td><td>0</td><td>1</td><td> 429</td><td>10.99%</td><td>17979.9</td><td>15.17%</td><td>GATA3       </td></tr>
	<tr><td>TRPS1(Zf)/MCF7-TRPS1-ChIP-Seq(GSE107013)/Homer         </td><td>AGATAAGANN          </td><td>1</td><td>0</td><td>1</td><td> 586</td><td>15.02%</td><td>23351.5</td><td>19.70%</td><td>TRPS1       </td></tr>
	<tr><td>Gata4(Zf)/Heart-Gata4-ChIP-Seq(GSE35151)/Homer         </td><td>NBWGATAAGR          </td><td>1</td><td>0</td><td>1</td><td> 266</td><td>6.82% </td><td>12367.4</td><td>10.44%</td><td>Gata4       </td></tr>
	<tr><td>Gata1(Zf)/K562-GATA1-ChIP-Seq(GSE18829)/Homer          </td><td>SAGATAAGRV          </td><td>1</td><td>0</td><td>1</td><td> 128</td><td>3.28% </td><td> 7311.6</td><td>6.17% </td><td>Gata1       </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer          </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1</td><td>0</td><td>1</td><td>  47</td><td>1.20% </td><td> 6264.5</td><td>5.29% </td><td>BORIS       </td></tr>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer       </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1</td><td>0</td><td>1</td><td>  34</td><td>0.87% </td><td> 5372.1</td><td>4.53% </td><td>CTCF        </td></tr>
	<tr><td>Gata2(Zf)/K562-GATA2-ChIP-Seq(GSE18829)/Homer          </td><td>BBCTTATCTS          </td><td>1</td><td>0</td><td>1</td><td> 147</td><td>3.77% </td><td> 8157.2</td><td>6.88% </td><td>Gata2       </td></tr>
	<tr><td>Gata6(Zf)/HUG1N-GATA6-ChIP-Seq(GSE51936)/Homer         </td><td>YCTTATCTBN          </td><td>1</td><td>0</td><td>1</td><td> 220</td><td>5.64% </td><td>11333.5</td><td>9.56% </td><td>Gata6       </td></tr>
	<tr><td>NF1-halfsite(CTF)/LNCaP-NF1-ChIP-Seq(Unpublished)/Homer</td><td>YTGCCAAG            </td><td>1</td><td>0</td><td>1</td><td> 596</td><td>15.27%</td><td>25409.2</td><td>21.44%</td><td>NF1-halfsite</td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer         </td><td>CYTGGCABNSTGCCAR    </td><td>1</td><td>0</td><td>1</td><td> 124</td><td>3.18% </td><td> 7440.7</td><td>6.28% </td><td>NF1         </td></tr>
	<tr><td>REST-NRSF(Zf)/Jurkat-NRSF-ChIP-Seq/Homer               </td><td>GGMGCTGTCCATGGTGCTGA</td><td>1</td><td>0</td><td>1</td><td>   0</td><td>0.00% </td><td>  224.9</td><td>0.19% </td><td>REST-NRSF   </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer  </td><td>CCWTTGTYYB          </td><td>1</td><td>0</td><td>1</td><td> 437</td><td>11.20%</td><td>19360.1</td><td>16.34%</td><td>Sox10       </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer            </td><td>CCWTTGTY            </td><td>1</td><td>0</td><td>1</td><td> 475</td><td>12.17%</td><td>20479.6</td><td>17.28%</td><td>Sox3        </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer         </td><td>CYRCATTCCA          </td><td>1</td><td>0</td><td>1</td><td> 208</td><td>5.33% </td><td>10625.7</td><td>8.97% </td><td>TEAD1       </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_8</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>Nkx6.1(Homeobox)/Islet-Nkx6.1-ChIP-Seq(GSE40975)/Homer          </td><td>GKTAATGR        </td><td>1e-117</td><td>-269.50</td><td>0</td><td> 7906</td><td>33.38%</td><td>26416.4</td><td>26.61%</td><td>Nkx6.1      </td></tr>
	<tr><td>Rfx2(HTH)/LoVo-RFX2-ChIP-Seq(GSE49402)/Homer                    </td><td>GTTGCCATGGCAACM </td><td>1e-114</td><td>-263.80</td><td>0</td><td>  607</td><td>2.56% </td><td>  860.6</td><td>0.87% </td><td>Rfx2        </td></tr>
	<tr><td>Lhx1(Homeobox)/EmbryoCarcinoma-Lhx1-ChIP-Seq(GSE70957)/Homer    </td><td>NNYTAATTAR      </td><td>1e-103</td><td>-238.70</td><td>0</td><td> 3941</td><td>16.64%</td><td>11766.9</td><td>11.85%</td><td>Lhx1        </td></tr>
	<tr><td>RFX(HTH)/K562-RFX3-ChIP-Seq(SRA012198)/Homer                    </td><td>CGGTTGCCATGGCAAC</td><td>1e-101</td><td>-234.60</td><td>0</td><td>  548</td><td>2.31% </td><td>  785.0</td><td>0.79% </td><td>RFX         </td></tr>
	<tr><td>Lhx2(Homeobox)/HFSC-Lhx2-ChIP-Seq(GSE48068)/Homer               </td><td>TAATTAGN        </td><td>1e-100</td><td>-232.00</td><td>0</td><td> 3700</td><td>15.62%</td><td>10958.3</td><td>11.04%</td><td>Lhx2        </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer                     </td><td>CCWTTGTY        </td><td>1e-100</td><td>-231.70</td><td>0</td><td> 5375</td><td>22.70%</td><td>17134.9</td><td>17.26%</td><td>Sox3        </td></tr>
	<tr><td>Lhx3(Homeobox)/Neuron-Lhx3-ChIP-Seq(GSE31456)/Homer             </td><td>ADBTAATTAR      </td><td> 1e-97</td><td>-223.90</td><td>0</td><td> 5418</td><td>22.88%</td><td>17382.1</td><td>17.51%</td><td>Lhx3        </td></tr>
	<tr><td>NF1-halfsite(CTF)/LNCaP-NF1-ChIP-Seq(Unpublished)/Homer         </td><td>YTGCCAAG        </td><td> 1e-97</td><td>-223.90</td><td>0</td><td> 6732</td><td>28.43%</td><td>22408.7</td><td>22.57%</td><td>NF1-halfsite</td></tr>
	<tr><td>NF1(CTF)/LNCAP-NF1-ChIP-Seq(Unpublished)/Homer                  </td><td>CYTGGCABNSTGCCAR</td><td> 1e-97</td><td>-223.40</td><td>0</td><td> 2347</td><td>9.91% </td><td> 6292.5</td><td>6.34% </td><td>NF1         </td></tr>
	<tr><td>Rfx1(HTH)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer                  </td><td>KGTTGCCATGGCAA  </td><td> 1e-94</td><td>-217.90</td><td>0</td><td>  935</td><td>3.95% </td><td> 1849.0</td><td>1.86% </td><td>Rfx1        </td></tr>
	<tr><td>LXH9(Homeobox)/Hct116-LXH9.V5-ChIP-Seq(GSE116822)/Homer         </td><td>NGCTAATTAG      </td><td> 1e-93</td><td>-214.90</td><td>0</td><td> 4608</td><td>19.46%</td><td>14446.9</td><td>14.55%</td><td>LXH9        </td></tr>
	<tr><td>X-box(HTH)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer                 </td><td>GGTTGCCATGGCAA  </td><td> 1e-90</td><td>-208.90</td><td>0</td><td>  604</td><td>2.55% </td><td>  982.6</td><td>0.99% </td><td>X-box       </td></tr>
	<tr><td>Sox2(HMG)/mES-Sox2-ChIP-Seq(GSE11431)/Homer                     </td><td>BCCATTGTTC      </td><td> 1e-87</td><td>-201.70</td><td>0</td><td> 2829</td><td>11.95%</td><td> 8122.4</td><td>8.18% </td><td>Sox2        </td></tr>
	<tr><td>Sox10(HMG)/SciaticNerve-Sox3-ChIP-Seq(GSE35132)/Homer           </td><td>CCWTTGTYYB      </td><td> 1e-85</td><td>-197.80</td><td>0</td><td> 5071</td><td>21.41%</td><td>16371.9</td><td>16.49%</td><td>Sox10       </td></tr>
	<tr><td>Sox6(HMG)/Myotubes-Sox6-ChIP-Seq(GSE32627)/Homer                </td><td>CCATTGTTNY      </td><td> 1e-83</td><td>-192.50</td><td>0</td><td> 4751</td><td>20.06%</td><td>15228.6</td><td>15.34%</td><td>Sox6        </td></tr>
	<tr><td>Isl1(Homeobox)/Neuron-Isl1-ChIP-Seq(GSE31456)/Homer             </td><td>CTAATKGV        </td><td> 1e-76</td><td>-175.20</td><td>0</td><td> 5706</td><td>24.09%</td><td>19075.2</td><td>19.21%</td><td>Isl1        </td></tr>
	<tr><td>Dlx3(Homeobox)/Kerainocytes-Dlx3-ChIP-Seq(GSE89884)/Homer       </td><td>NDGTAATTAC      </td><td> 1e-73</td><td>-170.30</td><td>0</td><td> 2412</td><td>10.18%</td><td> 6922.4</td><td>6.97% </td><td>Dlx3        </td></tr>
	<tr><td>Nanog(Homeobox)/mES-Nanog-ChIP-Seq(GSE11724)/Homer              </td><td>RGCCATTAAC      </td><td> 1e-63</td><td>-145.50</td><td>0</td><td>11372</td><td>48.02%</td><td>42280.4</td><td>42.58%</td><td>Nanog       </td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer                    </td><td>AGGVNCCTTTGT    </td><td> 1e-59</td><td>-137.80</td><td>0</td><td> 2779</td><td>11.73%</td><td> 8538.6</td><td>8.60% </td><td>Sox9        </td></tr>
	<tr><td>Sox4(HMG)/proB-Sox4-ChIP-Seq(GSE50066)/Homer                    </td><td>YCTTTGTTCC      </td><td> 1e-56</td><td>-129.20</td><td>0</td><td> 2732</td><td>11.54%</td><td> 8459.0</td><td>8.52% </td><td>Sox4        </td></tr>
	<tr><td>TEAD3(TEA)/HepG2-TEAD3-ChIP-Seq(Encode)/Homer                   </td><td>TRCATTCCAG      </td><td> 1e-54</td><td>-124.80</td><td>0</td><td> 3442</td><td>14.53%</td><td>11134.7</td><td>11.21%</td><td>TEAD3       </td></tr>
	<tr><td>Rfx5(HTH)/GM12878-Rfx5-ChIP-Seq(GSE31477)/Homer                 </td><td>SCCTAGCAACAG    </td><td> 1e-52</td><td>-120.20</td><td>0</td><td> 1145</td><td>4.83% </td><td> 2974.1</td><td>3.00% </td><td>Rfx5        </td></tr>
	<tr><td>Sox15(HMG)/CPA-Sox15-ChIP-Seq(GSE62909)/Homer                   </td><td>RAACAATGGN      </td><td> 1e-51</td><td>-118.90</td><td>0</td><td> 3258</td><td>13.76%</td><td>10520.9</td><td>10.60%</td><td>Sox15       </td></tr>
	<tr><td>Sox17(HMG)/Endoderm-Sox17-ChIP-Seq(GSE61475)/Homer              </td><td>CCATTGTTYB      </td><td> 1e-50</td><td>-115.50</td><td>0</td><td> 2099</td><td>8.86% </td><td> 6313.9</td><td>6.36% </td><td>Sox17       </td></tr>
	<tr><td>TEAD1(TEAD)/HepG2-TEAD1-ChIP-Seq(Encode)/Homer                  </td><td>CYRCATTCCA      </td><td> 1e-49</td><td>-113.30</td><td>0</td><td> 3043</td><td>12.85%</td><td> 9789.4</td><td>9.86% </td><td>TEAD1       </td></tr>
	<tr><td>TEAD4(TEA)/Tropoblast-Tead4-ChIP-Seq(GSE37350)/Homer            </td><td>CCWGGAATGY      </td><td> 1e-46</td><td>-107.60</td><td>0</td><td> 2727</td><td>11.52%</td><td> 8687.9</td><td>8.75% </td><td>TEAD4       </td></tr>
	<tr><td>Tlx?(NR)/NPC-H3K4me1-ChIP-Seq(GSE16256)/Homer                   </td><td>CTGGCAGSCTGCCA  </td><td> 1e-38</td><td> -89.41</td><td>0</td><td> 2051</td><td>8.66% </td><td> 6417.8</td><td>6.46% </td><td>Tlx?        </td></tr>
	<tr><td>Hoxd11(Homeobox)/ChickenMSG-Hoxd11.Flag-ChIP-Seq(GSE86088)/Homer</td><td>VGCCATAAAA      </td><td> 1e-37</td><td> -86.78</td><td>0</td><td> 6752</td><td>28.51%</td><td>24652.4</td><td>24.83%</td><td>Hoxd11      </td></tr>
	<tr><td>Hoxa11(Homeobox)/ChickenMSG-Hoxa11.Flag-ChIP-Seq(GSE86088)/Homer</td><td>TTTTATGGCM      </td><td> 1e-35</td><td> -82.42</td><td>0</td><td> 6530</td><td>27.57%</td><td>23856.1</td><td>24.03%</td><td>Hoxa11      </td></tr>
	<tr><td>Pdx1(Homeobox)/Islet-Pdx1-ChIP-Seq(SRA008281)/Homer             </td><td>YCATYAATCA      </td><td> 1e-33</td><td> -77.46</td><td>0</td><td> 2894</td><td>12.22%</td><td> 9718.6</td><td>9.79% </td><td>Pdx1        </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>IRF3(IRF)/BMDM-Irf3-ChIP-Seq(GSE67343)/Homer           </td><td>AGTTTCAKTTTC   </td><td>1</td><td>0</td><td>1</td><td> 667</td><td>2.82% </td><td> 3942.2</td><td>3.97% </td><td>IRF3     </td></tr>
	<tr><td>IRF8(IRF)/BMDM-IRF8-ChIP-Seq(GSE77884)/Homer           </td><td>GRAASTGAAAST   </td><td>1</td><td>0</td><td>1</td><td> 638</td><td>2.69% </td><td> 4248.5</td><td>4.28% </td><td>IRF8     </td></tr>
	<tr><td>ISRE(IRF)/ThioMac-LPS-Expression(GSE23622)/Homer       </td><td>AGTTTCASTTTC   </td><td>1</td><td>0</td><td>1</td><td>  93</td><td>0.39% </td><td>  852.6</td><td>0.86% </td><td>ISRE     </td></tr>
	<tr><td>Jun-AP1(bZIP)/K562-cJun-ChIP-Seq(GSE31477)/Homer       </td><td>GATGASTCATCN   </td><td>1</td><td>0</td><td>1</td><td> 484</td><td>2.04% </td><td> 3442.5</td><td>3.47% </td><td>Jun-AP1  </td></tr>
	<tr><td>JunB(bZIP)/DendriticCells-Junb-ChIP-Seq(GSE36099)/Homer</td><td>RATGASTCAT     </td><td>1</td><td>0</td><td>1</td><td>1222</td><td>5.16% </td><td> 6841.8</td><td>6.89% </td><td>JunB     </td></tr>
	<tr><td>KLF3(Zf)/MEF-Klf3-ChIP-Seq(GSE44748)/Homer             </td><td>NRGCCCCRCCCHBNN</td><td>1</td><td>0</td><td>1</td><td> 824</td><td>3.48% </td><td> 5486.3</td><td>5.53% </td><td>KLF3     </td></tr>
	<tr><td>Klf4(Zf)/mES-Klf4-ChIP-Seq(GSE11431)/Homer             </td><td>GCCACACCCA     </td><td>1</td><td>0</td><td>1</td><td> 641</td><td>2.71% </td><td> 4068.1</td><td>4.10% </td><td>Klf4     </td></tr>
	<tr><td>KLF5(Zf)/LoVo-KLF5-ChIP-Seq(GSE49402)/Homer            </td><td>DGGGYGKGGC     </td><td>1</td><td>0</td><td>1</td><td>2925</td><td>12.35%</td><td>15011.5</td><td>15.12%</td><td>KLF5     </td></tr>
	<tr><td>NFE2L2(bZIP)/HepG2-NFE2L2-ChIP-Seq(Encode)/Homer       </td><td>AWWWTGCTGAGTCAT</td><td>1</td><td>0</td><td>1</td><td>  82</td><td>0.35% </td><td>  900.0</td><td>0.91% </td><td>NFE2L2   </td></tr>
	<tr><td>NF-E2(bZIP)/K562-NFE2-ChIP-Seq(GSE31477)/Homer         </td><td>GATGACTCAGCA   </td><td>1</td><td>0</td><td>1</td><td>  84</td><td>0.35% </td><td> 1172.7</td><td>1.18% </td><td>NF-E2    </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer         </td><td>VTTACGTAAYNNNNN</td><td>1</td><td>0</td><td>1</td><td>1114</td><td>4.70% </td><td> 7579.9</td><td>7.63% </td><td>NFIL3    </td></tr>
	<tr><td>Nrf2(bZIP)/Lymphoblast-Nrf2-ChIP-Seq(GSE37589)/Homer   </td><td>HTGCTGAGTCAT   </td><td>1</td><td>0</td><td>1</td><td>  80</td><td>0.34% </td><td> 1066.1</td><td>1.07% </td><td>Nrf2     </td></tr>
	<tr><td>PU.1:IRF8(ETS:IRF)/pDC-Irf8-ChIP-Seq(GSE66899)/Homer   </td><td>GGAAGTGAAAST   </td><td>1</td><td>0</td><td>1</td><td> 372</td><td>1.57% </td><td> 2857.8</td><td>2.88% </td><td>PU.1:IRF8</td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer  </td><td>MGGAAGTGAAAC   </td><td>1</td><td>0</td><td>1</td><td>3177</td><td>13.42%</td><td>16394.5</td><td>16.51%</td><td>PU.1-IRF </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer        </td><td>AGAGGAAGTG     </td><td>1</td><td>0</td><td>1</td><td> 848</td><td>3.58% </td><td> 9098.9</td><td>9.16% </td><td>PU.1     </td></tr>
	<tr><td>RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer              </td><td>TTGAMCTTTG     </td><td>1</td><td>0</td><td>1</td><td>6111</td><td>25.80%</td><td>28968.5</td><td>29.18%</td><td>RARa     </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer         </td><td>SAAACCACAG     </td><td>1</td><td>0</td><td>1</td><td>1300</td><td>5.49% </td><td> 9426.8</td><td>9.49% </td><td>RUNX     </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer      </td><td>AAACCACARM     </td><td>1</td><td>0</td><td>1</td><td>2038</td><td>8.61% </td><td>13368.1</td><td>13.46%</td><td>RUNX1    </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer         </td><td>NWAACCACADNN   </td><td>1</td><td>0</td><td>1</td><td>1527</td><td>6.45% </td><td>10831.4</td><td>10.91%</td><td>RUNX2    </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer</td><td>GCTGTGGTTW     </td><td>1</td><td>0</td><td>1</td><td>1370</td><td>5.78% </td><td> 9946.6</td><td>10.02%</td><td>RUNX-AML </td></tr>
	<tr><td>Slug(Zf)/Mesoderm-Snai2-ChIP-Seq(GSE61475)/Homer       </td><td>SNGCACCTGCHS   </td><td>1</td><td>0</td><td>1</td><td>1113</td><td>4.70% </td><td> 6544.0</td><td>6.59% </td><td>Slug     </td></tr>
	<tr><td>Sp1(Zf)/Promoter/Homer                                 </td><td>GGCCCCGCCCCC   </td><td>1</td><td>0</td><td>1</td><td> 356</td><td>1.50% </td><td> 2622.6</td><td>2.64% </td><td>Sp1      </td></tr>
	<tr><td>Sp2(Zf)/HEK293-Sp2.eGFP-ChIP-Seq(Encode)/Homer         </td><td>YGGCCCCGCCCC   </td><td>1</td><td>0</td><td>1</td><td>3903</td><td>16.48%</td><td>18581.6</td><td>18.72%</td><td>Sp2      </td></tr>
	<tr><td>Sp5(Zf)/mES-Sp5.Flag-ChIP-Seq(GSE72989)/Homer          </td><td>RGKGGGCGGAGC   </td><td>1</td><td>0</td><td>1</td><td>2404</td><td>10.15%</td><td>12195.3</td><td>12.28%</td><td>Sp5      </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer        </td><td>ASWTCCTGBT     </td><td>1</td><td>0</td><td>1</td><td>2187</td><td>9.23% </td><td>13804.5</td><td>13.90%</td><td>SPDEF    </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer         </td><td>AAAGRGGAAGTG   </td><td>1</td><td>0</td><td>1</td><td> 413</td><td>1.74% </td><td> 4684.2</td><td>4.72% </td><td>SpiB     </td></tr>
	<tr><td>THRb(NR)/HepG2-THRb.Flag-ChIP-Seq(Encode)/Homer        </td><td>GGTCACCTGAGGTCA</td><td>1</td><td>0</td><td>1</td><td>1365</td><td>5.76% </td><td> 7347.6</td><td>7.40% </td><td>THRb     </td></tr>
	<tr><td>THRa(NR)/C17.2-THRa-ChIP-Seq(GSE38347)/Homer           </td><td>GGTCANYTGAGGWCA</td><td>1</td><td>0</td><td>1</td><td> 935</td><td>3.95% </td><td> 5102.5</td><td>5.14% </td><td>THRa     </td></tr>
	<tr><td>ZEB1(Zf)/PDAC-ZEB1-ChIP-Seq(GSE64557)/Homer            </td><td>VCAGGTRDRY     </td><td>1</td><td>0</td><td>1</td><td>2741</td><td>11.57%</td><td>16527.2</td><td>16.65%</td><td>ZEB1     </td></tr>
	<tr><td>ZEB2(Zf)/SNU398-ZEB2-ChIP-Seq(GSE103048)/Homer         </td><td>GNMCAGGTGTGC   </td><td>1</td><td>0</td><td>1</td><td>1448</td><td>6.11% </td><td> 9181.0</td><td>9.25% </td><td>ZEB2     </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_9</dt>
		<dd><table class="dataframe">
<caption>A tibble: 428 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer                   </td><td>TTGAMCTTTG       </td><td>1e-243</td><td>-560.20</td><td>0</td><td>5234</td><td>43.16%</td><td>32934.4</td><td>28.91%</td><td>RARa     </td></tr>
	<tr><td>Erra(NR)/HepG2-Erra-ChIP-Seq(GSE31477)/Homer                </td><td>CAAAGGTCAG       </td><td>1e-198</td><td>-457.70</td><td>0</td><td>4100</td><td>33.81%</td><td>24938.3</td><td>21.89%</td><td>Erra     </td></tr>
	<tr><td>HNF4a(NR),DR1/HepG2-HNF4a-ChIP-Seq(GSE25021)/Homer          </td><td>CARRGKBCAAAGTYCA </td><td>1e-195</td><td>-450.30</td><td>0</td><td>1223</td><td>10.09%</td><td> 4389.6</td><td>3.85% </td><td>HNF4a    </td></tr>
	<tr><td>COUP-TFII(NR)/K562-NR2F1-ChIP-Seq(Encode)/Homer             </td><td>GKBCARAGGTCA     </td><td>1e-178</td><td>-410.10</td><td>0</td><td>2935</td><td>24.20%</td><td>16408.6</td><td>14.40%</td><td>COUP-TFII</td></tr>
	<tr><td>Esrrb(NR)/mES-Esrrb-ChIP-Seq(GSE11431)/Homer                </td><td>KTGACCTTGA       </td><td>1e-177</td><td>-409.50</td><td>0</td><td>1518</td><td>12.52%</td><td> 6440.9</td><td>5.65% </td><td>Esrrb    </td></tr>
	<tr><td>EAR2(NR)/K562-NR2F6-ChIP-Seq(Encode)/Homer                  </td><td>NRBCARRGGTCA     </td><td>1e-175</td><td>-405.10</td><td>0</td><td>2719</td><td>22.42%</td><td>14843.4</td><td>13.03%</td><td>EAR2     </td></tr>
	<tr><td>ERRg(NR)/Kidney-ESRRG-ChIP-Seq(GSE104905)/Homer             </td><td>GTGACCTTGRVN     </td><td>1e-172</td><td>-397.80</td><td>0</td><td>1777</td><td>14.65%</td><td> 8224.4</td><td>7.22% </td><td>ERRg     </td></tr>
	<tr><td>PPARa(NR),DR1/Liver-Ppara-ChIP-Seq(GSE47954)/Homer          </td><td>VNAGGKCAAAGGTCA  </td><td>1e-152</td><td>-350.60</td><td>0</td><td>2092</td><td>17.25%</td><td>10855.5</td><td>9.53% </td><td>PPARa    </td></tr>
	<tr><td>COUP-TFII(NR)/Artia-Nr2f2-ChIP-Seq(GSE46497)/Homer          </td><td>AGRGGTCA         </td><td>1e-147</td><td>-339.20</td><td>0</td><td>3216</td><td>26.52%</td><td>19501.0</td><td>17.12%</td><td>COUP-TFII</td></tr>
	<tr><td>FOXA1(Forkhead)/LNCAP-FOXA1-ChIP-Seq(GSE27824)/Homer        </td><td>WAAGTAAACA       </td><td>1e-138</td><td>-319.50</td><td>0</td><td>2743</td><td>22.62%</td><td>16076.4</td><td>14.11%</td><td>FOXA1    </td></tr>
	<tr><td>THRb(NR)/Liver-NR1A2-ChIP-Seq(GSE52613)/Homer               </td><td>TRAGGTCA         </td><td>1e-138</td><td>-318.10</td><td>0</td><td>6118</td><td>50.45%</td><td>44667.4</td><td>39.20%</td><td>THRb     </td></tr>
	<tr><td>Nr5a2(NR)/Pancreas-LRH1-ChIP-Seq(GSE34295)/Homer            </td><td>BTCAAGGTCA       </td><td>1e-137</td><td>-315.90</td><td>0</td><td>1505</td><td>12.41%</td><td> 7107.5</td><td>6.24% </td><td>Nr5a2    </td></tr>
	<tr><td>FOXA1(Forkhead)/MCF7-FOXA1-ChIP-Seq(GSE26831)/Homer         </td><td>WAAGTAAACA       </td><td>1e-135</td><td>-313.10</td><td>0</td><td>2376</td><td>19.59%</td><td>13366.0</td><td>11.73%</td><td>FOXA1    </td></tr>
	<tr><td>FOXM1(Forkhead)/MCF7-FOXM1-ChIP-Seq(GSE72977)/Homer         </td><td>TRTTTACTTW       </td><td>1e-129</td><td>-299.10</td><td>0</td><td>2361</td><td>19.47%</td><td>13429.6</td><td>11.79%</td><td>FOXM1    </td></tr>
	<tr><td>Nr5a2(NR)/mES-Nr5a2-ChIP-Seq(GSE19019)/Homer                </td><td>BTCAAGGTCA       </td><td>1e-113</td><td>-261.20</td><td>0</td><td>1146</td><td>9.45% </td><td> 5197.9</td><td>4.56% </td><td>Nr5a2    </td></tr>
	<tr><td>SF1(NR)/H295R-Nr5a1-ChIP-Seq(GSE44220)/Homer                </td><td>CAAGGHCANV       </td><td> 1e-98</td><td>-226.40</td><td>0</td><td>1022</td><td>8.43% </td><td> 4680.8</td><td>4.11% </td><td>SF1      </td></tr>
	<tr><td>Foxa2(Forkhead)/Liver-Foxa2-ChIP-Seq(GSE25694)/Homer        </td><td>CYTGTTTACWYW     </td><td> 1e-94</td><td>-216.40</td><td>0</td><td>1786</td><td>14.73%</td><td>10184.5</td><td>8.94% </td><td>Foxa2    </td></tr>
	<tr><td>RXR(NR),DR1/3T3L1-RXR-ChIP-Seq(GSE13511)/Homer              </td><td>TAGGGCAAAGGTCA   </td><td> 1e-90</td><td>-209.40</td><td>0</td><td>2009</td><td>16.57%</td><td>11968.6</td><td>10.50%</td><td>RXR      </td></tr>
	<tr><td>Fox:Ebox(Forkhead,bHLH)/Panc1-Foxa2-ChIP-Seq(GSE47459)/Homer</td><td>NNNVCTGWGYAAACASN</td><td> 1e-82</td><td>-189.00</td><td>0</td><td>1966</td><td>16.21%</td><td>11943.6</td><td>10.48%</td><td>Fox:Ebox </td></tr>
	<tr><td>PPARE(NR),DR1/3T3L1-Pparg-ChIP-Seq(GSE13511)/Homer          </td><td>TGACCTTTGCCCCA   </td><td> 1e-79</td><td>-182.80</td><td>0</td><td>1684</td><td>13.89%</td><td> 9879.9</td><td>8.67% </td><td>PPARE    </td></tr>
	<tr><td>TR4(NR),DR1/Hela-TR4-ChIP-Seq(GSE24685)/Homer               </td><td>GAGGTCAAAGGTCA   </td><td> 1e-68</td><td>-157.40</td><td>0</td><td> 325</td><td>2.68% </td><td>  966.9</td><td>0.85% </td><td>TR4      </td></tr>
	<tr><td>Foxa3(Forkhead)/Liver-Foxa3-ChIP-Seq(GSE77670)/Homer        </td><td>BSNTGTTTACWYWGN  </td><td> 1e-66</td><td>-152.50</td><td>0</td><td> 861</td><td>7.10% </td><td> 4289.7</td><td>3.76% </td><td>Foxa3    </td></tr>
	<tr><td>HNF1b(Homeobox)/PDAC-HNF1B-ChIP-Seq(GSE64557)/Homer         </td><td>GTTAATNATTAA     </td><td> 1e-63</td><td>-145.10</td><td>0</td><td> 472</td><td>3.89% </td><td> 1844.5</td><td>1.62% </td><td>HNF1b    </td></tr>
	<tr><td>Hnf1(Homeobox)/Liver-Foxa2-Chip-Seq(GSE25694)/Homer         </td><td>GGTTAAWCATTAA    </td><td> 1e-59</td><td>-137.10</td><td>0</td><td> 434</td><td>3.58% </td><td> 1672.7</td><td>1.47% </td><td>Hnf1     </td></tr>
	<tr><td>FOXK1(Forkhead)/HEK293-FOXK1-ChIP-Seq(GSE51673)/Homer       </td><td>NVWTGTTTAC       </td><td> 1e-57</td><td>-133.00</td><td>0</td><td>2055</td><td>16.95%</td><td>13619.0</td><td>11.95%</td><td>FOXK1    </td></tr>
	<tr><td>Foxf1(Forkhead)/Lung-Foxf1-ChIP-Seq(GSE77951)/Homer         </td><td>WWATRTAAACAN     </td><td> 1e-56</td><td>-130.90</td><td>0</td><td>1913</td><td>15.78%</td><td>12516.6</td><td>10.99%</td><td>Foxf1    </td></tr>
	<tr><td>FoxL2(Forkhead)/Ovary-FoxL2-ChIP-Seq(GSE60858)/Homer        </td><td>WWTRTAAACAVG     </td><td> 1e-49</td><td>-114.10</td><td>0</td><td>1744</td><td>14.38%</td><td>11491.6</td><td>10.09%</td><td>FoxL2    </td></tr>
	<tr><td>Foxo3(Forkhead)/U2OS-Foxo3-ChIP-Seq(E-MTAB-2701)/Homer      </td><td>DGTAAACA         </td><td> 1e-46</td><td>-106.20</td><td>0</td><td>1558</td><td>12.85%</td><td>10160.1</td><td>8.92% </td><td>Foxo3    </td></tr>
	<tr><td>Nur77(NR)/K562-NR4A1-ChIP-Seq(GSE31363)/Homer               </td><td>TGACCTTTNCNT     </td><td> 1e-45</td><td>-105.40</td><td>0</td><td> 433</td><td>3.57% </td><td> 1893.7</td><td>1.66% </td><td>Nur77    </td></tr>
	<tr><td>FOXP1(Forkhead)/H9-FOXP1-ChIP-Seq(GSE31006)/Homer           </td><td>NYYTGTTTACHN     </td><td> 1e-43</td><td> -99.27</td><td>0</td><td> 985</td><td>8.12% </td><td> 5840.0</td><td>5.13% </td><td>FOXP1    </td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>EHF(ETS)/LoVo-EHF-ChIP-Seq(GSE49402)/Homer                     </td><td>AVCAGGAAGT  </td><td>1</td><td>0</td><td>1</td><td>1481</td><td>12.21%</td><td>21778.7</td><td>19.11%</td><td>EHF            </td></tr>
	<tr><td>ELF1(ETS)/Jurkat-ELF1-ChIP-Seq(SRA014231)/Homer                </td><td>AVCCGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 460</td><td>3.79% </td><td> 6826.0</td><td>5.99% </td><td>ELF1           </td></tr>
	<tr><td>ELF3(ETS)/PDAC-ELF3-ChIP-Seq(GSE64557)/Homer                   </td><td>ANCAGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 813</td><td>6.70% </td><td>13477.9</td><td>11.83%</td><td>ELF3           </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer                   </td><td>ACTTCCKGKT  </td><td>1</td><td>0</td><td>1</td><td>1020</td><td>8.41% </td><td>17443.3</td><td>15.31%</td><td>Elf4           </td></tr>
	<tr><td>ELF5(ETS)/T47D-ELF5-ChIP-Seq(GSE30407)/Homer                   </td><td>ACVAGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 792</td><td>6.53% </td><td>13026.9</td><td>11.43%</td><td>ELF5           </td></tr>
	<tr><td>Elk1(ETS)/Hela-Elk1-ChIP-Seq(GSE31477)/Homer                   </td><td>HACTTCCGGY  </td><td>1</td><td>0</td><td>1</td><td> 496</td><td>4.09% </td><td> 7114.2</td><td>6.24% </td><td>Elk1           </td></tr>
	<tr><td>Elk4(ETS)/Hela-Elk4-ChIP-Seq(GSE31477)/Homer                   </td><td>NRYTTCCGGY  </td><td>1</td><td>0</td><td>1</td><td> 503</td><td>4.15% </td><td> 6998.4</td><td>6.14% </td><td>Elk4           </td></tr>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer                     </td><td>ACAGGAAGTG  </td><td>1</td><td>0</td><td>1</td><td>1851</td><td>15.26%</td><td>27558.4</td><td>24.19%</td><td>ERG            </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer                 </td><td>ACAGGAAGTG  </td><td>1</td><td>0</td><td>1</td><td>1048</td><td>8.64% </td><td>18100.9</td><td>15.89%</td><td>ETS1           </td></tr>
	<tr><td>Ets1-distal(ETS)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer      </td><td>MACAGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 285</td><td>2.35% </td><td> 6397.6</td><td>5.61% </td><td>Ets1-distal    </td></tr>
	<tr><td>ETS:E-box(ETS,bHLH)/HPC7-Scl-ChIP-Seq(GSE22178)/Homer          </td><td>AGGAARCAGCTG</td><td>1</td><td>0</td><td>1</td><td>  75</td><td>0.62% </td><td> 1740.3</td><td>1.53% </td><td>ETS:E-box      </td></tr>
	<tr><td>ETS(ETS)/Promoter/Homer                                        </td><td>AACCGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 280</td><td>2.31% </td><td> 4555.5</td><td>4.00% </td><td>ETS            </td></tr>
	<tr><td>ETS:RUNX(ETS,Runt)/Jurkat-RUNX1-ChIP-Seq(GSE17954)/Homer       </td><td>RCAGGATGTGGT</td><td>1</td><td>0</td><td>1</td><td>  62</td><td>0.51% </td><td> 1845.7</td><td>1.62% </td><td>ETS:RUNX       </td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer                 </td><td>AACCGGAAGT  </td><td>1</td><td>0</td><td>1</td><td>1478</td><td>12.19%</td><td>22730.6</td><td>19.95%</td><td>ETV1           </td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer                     </td><td>NNAYTTCCTGHN</td><td>1</td><td>0</td><td>1</td><td> 993</td><td>8.19% </td><td>17540.6</td><td>15.39%</td><td>Etv2           </td></tr>
	<tr><td>ETV4(ETS)/HepG2-ETV4-ChIP-Seq(ENCODE)/Homer                    </td><td>ACCGGAAGTG  </td><td>1</td><td>0</td><td>1</td><td>1164</td><td>9.60% </td><td>17332.7</td><td>15.21%</td><td>ETV4           </td></tr>
	<tr><td>EWS:ERG-fusion(ETS)/CADO_ES1-EWS:ERG-ChIP-Seq(SRA014231)/Homer </td><td>ATTTCCTGTN  </td><td>1</td><td>0</td><td>1</td><td> 849</td><td>7.00% </td><td>14290.3</td><td>12.54%</td><td>EWS:ERG-fusion </td></tr>
	<tr><td>EWS:FLI1-fusion(ETS)/SK_N_MC-EWS:FLI1-ChIP-Seq(SRA014231)/Homer</td><td>VACAGGAAAT  </td><td>1</td><td>0</td><td>1</td><td> 576</td><td>4.75% </td><td>10342.5</td><td>9.08% </td><td>EWS:FLI1-fusion</td></tr>
	<tr><td>Fli1(ETS)/CD8-FLI-ChIP-Seq(GSE20898)/Homer                     </td><td>NRYTTCCGGH  </td><td>1</td><td>0</td><td>1</td><td>1120</td><td>9.24% </td><td>18568.2</td><td>16.30%</td><td>Fli1           </td></tr>
	<tr><td>GABPA(ETS)/Jurkat-GABPa-ChIP-Seq(GSE17954)/Homer               </td><td>RACCGGAAGT  </td><td>1</td><td>0</td><td>1</td><td> 872</td><td>7.19% </td><td>14803.1</td><td>12.99%</td><td>GABPA          </td></tr>
	<tr><td>LRF(Zf)/Erythroblasts-ZBTB7A-ChIP-Seq(GSE74977)/Homer          </td><td>AAGACCCYYN  </td><td>1</td><td>0</td><td>1</td><td>1305</td><td>10.76%</td><td>15373.9</td><td>13.49%</td><td>LRF            </td></tr>
	<tr><td>PU.1-IRF(ETS:IRF)/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer          </td><td>MGGAAGTGAAAC</td><td>1</td><td>0</td><td>1</td><td>1574</td><td>12.98%</td><td>18135.8</td><td>15.92%</td><td>PU.1-IRF       </td></tr>
	<tr><td>PU.1(ETS)/ThioMac-PU.1-ChIP-Seq(GSE21512)/Homer                </td><td>AGAGGAAGTG  </td><td>1</td><td>0</td><td>1</td><td> 448</td><td>3.69% </td><td> 9637.2</td><td>8.46% </td><td>PU.1           </td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer                 </td><td>SAAACCACAG  </td><td>1</td><td>0</td><td>1</td><td> 686</td><td>5.66% </td><td>11267.2</td><td>9.89% </td><td>RUNX           </td></tr>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer              </td><td>AAACCACARM  </td><td>1</td><td>0</td><td>1</td><td>1076</td><td>8.87% </td><td>15972.9</td><td>14.02%</td><td>RUNX1          </td></tr>
	<tr><td>RUNX2(Runt)/PCa-RUNX2-ChIP-Seq(GSE33889)/Homer                 </td><td>NWAACCACADNN</td><td>1</td><td>0</td><td>1</td><td> 796</td><td>6.56% </td><td>13164.3</td><td>11.55%</td><td>RUNX2          </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer        </td><td>GCTGTGGTTW  </td><td>1</td><td>0</td><td>1</td><td> 724</td><td>5.97% </td><td>11744.3</td><td>10.31%</td><td>RUNX-AML       </td></tr>
	<tr><td>SPDEF(ETS)/VCaP-SPDEF-ChIP-Seq(SRA014231)/Homer                </td><td>ASWTCCTGBT  </td><td>1</td><td>0</td><td>1</td><td>1145</td><td>9.44% </td><td>14564.5</td><td>12.78%</td><td>SPDEF          </td></tr>
	<tr><td>SpiB(ETS)/OCILY3-SPIB-ChIP-Seq(GSE56857)/Homer                 </td><td>AAAGRGGAAGTG</td><td>1</td><td>0</td><td>1</td><td> 204</td><td>1.68% </td><td> 5027.2</td><td>4.41% </td><td>SpiB           </td></tr>
	<tr><td>Twist2(bHLH)/Myoblast-Twist2.Ty1-ChIP-Seq(GSE127998)/Homer     </td><td>MCAGCTGBYH  </td><td>1</td><td>0</td><td>1</td><td>2110</td><td>17.40%</td><td>23359.4</td><td>20.50%</td><td>Twist2         </td></tr>
</tbody>
</table>
</dd>
</dl>



## Add fold change


```R
df_all <- df_all_bind %>%
    mutate(percentTargetNum = (as.numeric(gsub("%", "", percentTarget, fixed = TRUE))/100)) %>%
    mutate(percentBackgroundNum = (as.numeric(gsub("%", "", percentBackground, fixed = TRUE))/100)) %>%
    mutate(percentFold = (percentTargetNum/percentBackgroundNum))
```

## Filter data

### Find top 3 per cluster to see what's on top 


```R
# 
lof_shortNames %>% map(~top_n(., n = -3, wt = logp))
```


<dl>
	<dt>$cluster_1</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer</td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1e-38</td><td>-88.47</td><td>0</td><td>1115</td><td>4.97% </td><td>3430.9</td><td>3.30%</td><td>CTCF </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer   </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1e-36</td><td>-85.01</td><td>0</td><td>1286</td><td>5.74% </td><td>4116.0</td><td>3.96%</td><td>BORIS</td></tr>
	<tr><td>Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer    </td><td>AGGVNCCTTTGT        </td><td>1e-14</td><td>-32.76</td><td>0</td><td>2324</td><td>10.37%</td><td>9205.8</td><td>8.87%</td><td>Sox9 </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_10</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>OCT4-SOX2-TCF-NANOG(POU,Homeobox,HMG)/mES-Oct4-ChIP-Seq(GSE11431)/Homer</td><td>ATTTGCATAACAATG</td><td>1e-157</td><td>-361.9</td><td>0</td><td> 450</td><td>8.85% </td><td> 2186.0</td><td>1.87% </td><td>OCT4-SOX2-TCF-NANOG</td></tr>
	<tr><td>Oct4(POU,Homeobox)/mES-Oct4-ChIP-Seq(GSE11431)/Homer                   </td><td>ATTTGCATAW     </td><td> 1e-67</td><td>-154.8</td><td>0</td><td> 556</td><td>10.93%</td><td> 5701.8</td><td>4.87% </td><td>Oct4               </td></tr>
	<tr><td>Sox3(HMG)/NPC-Sox3-ChIP-Seq(GSE33059)/Homer                            </td><td>CCWTTGTY       </td><td> 1e-52</td><td>-121.0</td><td>0</td><td>1311</td><td>25.77%</td><td>20138.1</td><td>17.20%</td><td>Sox3               </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_2</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer      </td><td>AAACCACARM</td><td>1e-98</td><td>-226.7</td><td>0</td><td>1302</td><td>25.31%</td><td>16603.4</td><td>14.13%</td><td>RUNX1   </td></tr>
	<tr><td>RUNX-AML(Runt)/CD4+-PolII-ChIP-Seq(Barski_et_al.)/Homer</td><td>GCTGTGGTTW</td><td>1e-85</td><td>-197.1</td><td>0</td><td>1012</td><td>19.67%</td><td>12224.7</td><td>10.40%</td><td>RUNX-AML</td></tr>
	<tr><td>RUNX(Runt)/HPC7-Runx1-ChIP-Seq(GSE22178)/Homer         </td><td>SAAACCACAG</td><td>1e-80</td><td>-185.7</td><td>0</td><td> 970</td><td>18.85%</td><td>11766.5</td><td>10.01%</td><td>RUNX    </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_3</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer    </td><td>ACAGGAAGTG  </td><td>1e-307</td><td>-1455</td><td>0</td><td>6165</td><td>44.59%</td><td>26477.4</td><td>23.67%</td><td>ERG </td></tr>
	<tr><td>ETS1(ETS)/Jurkat-ETS1-ChIP-Seq(GSE17954)/Homer</td><td>ACAGGAAGTG  </td><td>1e-307</td><td>-1318</td><td>0</td><td>4480</td><td>32.40%</td><td>16752.7</td><td>14.98%</td><td>ETS1</td></tr>
	<tr><td>Etv2(ETS)/ES-ER71-ChIP-Seq(GSE59402)/Homer    </td><td>NNAYTTCCTGHN</td><td>1e-307</td><td>-1315</td><td>0</td><td>4382</td><td>31.69%</td><td>16196.8</td><td>14.48%</td><td>Etv2</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_4</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer    </td><td>ACAGGAAGTG</td><td>1e-307</td><td>-801.0</td><td>0</td><td>5350</td><td>39.71%</td><td>27152.7</td><td>24.14%</td><td>ERG </td></tr>
	<tr><td>Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer  </td><td>ACTTCCKGKT</td><td>1e-307</td><td>-725.1</td><td>0</td><td>3759</td><td>27.90%</td><td>16979.7</td><td>15.10%</td><td>Elf4</td></tr>
	<tr><td>ETV1(ETS)/GIST48-ETV1-ChIP-Seq(GSE22441)/Homer</td><td>AACCGGAAGT</td><td>1e-307</td><td>-709.2</td><td>0</td><td>4490</td><td>33.33%</td><td>22014.7</td><td>19.57%</td><td>ETV1</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_5</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer       </td><td>AYAGTGCCMYCTRGTGGCCA</td><td>1e-307</td><td>-4437.00</td><td>0</td><td>3031</td><td>21.31%</td><td> 1865.2</td><td>2.21% </td><td>CTCF </td></tr>
	<tr><td>BORIS(Zf)/K562-CTCFL-ChIP-Seq(GSE32465)/Homer          </td><td>CNNBRGCGCCCCCTGSTGGC</td><td>1e-307</td><td>-3506.00</td><td>0</td><td>3246</td><td>22.82%</td><td> 3089.6</td><td>3.67% </td><td>BORIS</td></tr>
	<tr><td>E2A(bHLH),near_PU.1/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer</td><td>NVCACCTGBN          </td><td> 1e-41</td><td>  -96.25</td><td>0</td><td>2677</td><td>18.82%</td><td>12331.9</td><td>14.64%</td><td>E2A  </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_6</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer</td><td>ATTGCGCAAC     </td><td>1e-307</td><td>-1942.0</td><td>0</td><td>2995</td><td>29.61%</td><td>9333.8</td><td>8.26%</td><td>CEBP </td></tr>
	<tr><td>NFIL3(bZIP)/HepG2-NFIL3-ChIP-Seq(Encode)/Homer   </td><td>VTTACGTAAYNNNNN</td><td>1e-307</td><td>-1350.0</td><td>0</td><td>2291</td><td>22.65%</td><td>7475.7</td><td>6.62%</td><td>NFIL3</td></tr>
	<tr><td>HLF(bZIP)/HSC-HLF.Flag-ChIP-Seq(GSE69817)/Homer  </td><td>RTTATGYAAB     </td><td>1e-307</td><td> -835.8</td><td>0</td><td>2253</td><td>22.28%</td><td>9967.8</td><td>8.82%</td><td>HLF  </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_7</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>EBF2(EBF)/BrownAdipose-EBF2-ChIP-Seq(GSE97114)/Homer   </td><td>NABTCCCWDGGGAVH</td><td>1e-78</td><td>-181.6</td><td>0</td><td> 763</td><td>19.55%</td><td>11339.9</td><td>9.57% </td><td>EBF2</td></tr>
	<tr><td>EBF(EBF)/proBcell-EBF-ChIP-Seq(GSE21978)/Homer         </td><td>DGTCCCYRGGGA   </td><td>1e-78</td><td>-181.1</td><td>0</td><td> 310</td><td>7.94% </td><td> 2641.2</td><td>2.23% </td><td>EBF </td></tr>
	<tr><td>E2A(bHLH),near_PU.1/Bcell-PU.1-ChIP-Seq(GSE21512)/Homer</td><td>NVCACCTGBN     </td><td>1e-67</td><td>-155.3</td><td>0</td><td>1051</td><td>26.93%</td><td>18887.3</td><td>15.94%</td><td>E2A </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_8</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>Nkx6.1(Homeobox)/Islet-Nkx6.1-ChIP-Seq(GSE40975)/Homer      </td><td>GKTAATGR       </td><td>1e-117</td><td>-269.5</td><td>0</td><td>7906</td><td>33.38%</td><td>26416.4</td><td>26.61%</td><td>Nkx6.1</td></tr>
	<tr><td>Rfx2(HTH)/LoVo-RFX2-ChIP-Seq(GSE49402)/Homer                </td><td>GTTGCCATGGCAACM</td><td>1e-114</td><td>-263.8</td><td>0</td><td> 607</td><td>2.56% </td><td>  860.6</td><td>0.87% </td><td>Rfx2  </td></tr>
	<tr><td>Lhx1(Homeobox)/EmbryoCarcinoma-Lhx1-ChIP-Seq(GSE70957)/Homer</td><td>NNYTAATTAR     </td><td>1e-103</td><td>-238.7</td><td>0</td><td>3941</td><td>16.64%</td><td>11766.9</td><td>11.85%</td><td>Lhx1  </td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster_9</dt>
		<dd><table class="dataframe">
<caption>A tibble: 3 × 10</caption>
<thead>
	<tr><th scope=col>MotifName</th><th scope=col>Consensus</th><th scope=col>p</th><th scope=col>logp</th><th scope=col>q</th><th scope=col>numTarget</th><th scope=col>percentTarget</th><th scope=col>numBackground</th><th scope=col>percentBackground</th><th scope=col>MotifNameShort</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer         </td><td>TTGAMCTTTG      </td><td>1e-243</td><td>-560.2</td><td>0</td><td>5234</td><td>43.16%</td><td>32934.4</td><td>28.91%</td><td>RARa </td></tr>
	<tr><td>Erra(NR)/HepG2-Erra-ChIP-Seq(GSE31477)/Homer      </td><td>CAAAGGTCAG      </td><td>1e-198</td><td>-457.7</td><td>0</td><td>4100</td><td>33.81%</td><td>24938.3</td><td>21.89%</td><td>Erra </td></tr>
	<tr><td>HNF4a(NR),DR1/HepG2-HNF4a-ChIP-Seq(GSE25021)/Homer</td><td>CARRGKBCAAAGTYCA</td><td>1e-195</td><td>-450.3</td><td>0</td><td>1223</td><td>10.09%</td><td> 4389.6</td><td>3.85% </td><td>HNF4a</td></tr>
</tbody>
</table>
</dd>
</dl>



### Subset by select TFs


```R
MotifsToKeep <- c("Sox9(HMG)/Limb-SOX9-ChIP-Seq(GSE73225)/Homer","OCT4-SOX2-TCF-NANOG(POU,Homeobox,HMG)/mES-Oct4-ChIP-Seq(GSE11431)/Homer",
                  "RUNX1(Runt)/Jurkat-RUNX1-ChIP-Seq(GSE29180)/Homer", "ERG(ETS)/VCaP-ERG-ChIP-Seq(GSE14097)/Homer", 
                  "Elf4(ETS)/BMDM-Elf4-ChIP-Seq(GSE88699)/Homer", 
                      "CTCF(Zf)/CD4+-CTCF-ChIP-Seq(Barski_et_al.)/Homer", "CEBP(bZIP)/ThioMac-CEBPb-ChIP-Seq(GSE21512)/Homer",
                  "EBF2(EBF)/BrownAdipose-EBF2-ChIP-Seq(GSE97114)/Homer", "Nkx6.1(Homeobox)/Islet-Nkx6.1-ChIP-Seq(GSE40975)/Homer", "RARa(NR)/K562-RARa-ChIP-Seq(Encode)/Homer")
```


```R
df_sub <- df_all %>% filter(MotifName %in% MotifsToKeep)
```


```R
df_sub <- df_all %>% filter(MotifName %in% MotifsToKeep)
df_sub$MotifNameShort = factor(df_sub$MotifNameShort, levels = 
                               c("OCT4-SOX2-TCF-NANOG", "Nkx6.1","RARa", "CEBP", "RUNX1",
                                 "EBF2", "CTCF", "Sox9", "ERG", "Elf4"))

df_sub$clusterID = factor(df_sub$clusterID, levels = 
                          c("cluster_4","cluster_3","cluster_1","cluster_5","cluster_7",
                                                      "cluster_2","cluster_6","cluster_9","cluster_8","cluster_10"))
                          
                          #c("cluster_10","cluster_8","cluster_9","cluster_6","cluster_2", "cluster_7","cluster_5","cluster_1","cluster_3","cluster_4"))
```


```R
unique(df_sub$clusterID)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>cluster_1</li><li>cluster_10</li><li>cluster_2</li><li>cluster_3</li><li>cluster_4</li><li>cluster_5</li><li>cluster_6</li><li>cluster_7</li><li>cluster_8</li><li>cluster_9</li></ol>

<details>
	<summary style=display:list-item;cursor:pointer>
		<strong>Levels</strong>:
	</summary>
	<style>
	.list-inline {list-style: none; margin:0; padding: 0}
	.list-inline>li {display: inline-block}
	.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
	</style>
	<ol class=list-inline><li>'cluster_4'</li><li>'cluster_3'</li><li>'cluster_1'</li><li>'cluster_5'</li><li>'cluster_7'</li><li>'cluster_2'</li><li>'cluster_6'</li><li>'cluster_9'</li><li>'cluster_8'</li><li>'cluster_10'</li></ol>
</details>


## Graph


```R
library(scales)
```

    
    Attaching package: ‘scales’
    
    
    The following object is masked from ‘package:purrr’:
    
        discard
    
    
    The following object is masked from ‘package:readr’:
    
        col_factor
    
    



```R
df_sub_rescaled <- plyr::ddply(.data = df_sub, ~ MotifName, .fun = transform, 
                                    rescale = rescale(percentFold))

```


```R
setwd("/data/hodges_lab/Tim/MethylationHeatmap_paper/HOMER_seed86_Jul15/")

col.pal <- brewer.pal(9,"YlGnBu")


hm_scaled <- ggplot(df_sub_rescaled, aes(x=MotifNameShort, y = clusterID)) +
    geom_tile(aes(fill = rescale))  + 
    scale_fill_gradientn(colours=col.pal) +
theme(axis.text=element_text(size=14),
          axis.text.x = element_text(angle=45, hjust=1),
          axis.line = element_line(colour = "black"),
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          panel.border = element_blank(),
          panel.background = element_blank()) +
    scale_x_discrete(position = "bottom") 

ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/heatmap_scaled.pdf", hm_scaled)

hm_scaled
```

    Saving 6.67 x 6.67 in image
    



![png](output_107_1.png)



```R

```


```R

```


```R
library(Sushi)
```

    Loading required package: zoo
    
    
    Attaching package: ‘zoo’
    
    
    The following objects are masked from ‘package:base’:
    
        as.Date, as.Date.numeric
    
    
    Loading required package: biomaRt
    


# interHMR shuffle


```R
/data/hodges_lab/Tim/finalAnalyses_HMRs/interHMRdistances/run_interHMRDists_Neutrophhil.slrm
```

# Gene Ontology

## Load libraries


```R
library(tidyverse)
library(ggplot2)
library(RColorBrewer)
library(pheatmap)
library(data.table)
print("Libraries loaded.")
```

    [1] "Libraries loaded."


## Load data


```R
setwd("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT_output_noBackground")
list.files()
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster10.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster2.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster3.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster4.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster5.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster6.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster7.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster8.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster9.tsv'</li></ol>




```R

lofn_shown <- list.files(pattern="shown-GOBiologicalProcess.k10s86.noBG.*")
lofn_shown # List of File Names
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster10.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster2.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster3.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster4.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster5.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster6.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster7.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster8.tsv'</li><li>'shown-GOBiologicalProcess.k10s86.noBG.cluster9.tsv'</li></ol>




```R

locids_shown <- lofn_shown %>% map(~gsub("shown-GOBiologicalProcess.k10s86.noBG.", "", .)) %>% map(~gsub(".tsv", "", .)) #List of Cluster IDs

locids_shown
```


<ol>
	<li>'cluster10'</li>
	<li>'cluster2'</li>
	<li>'cluster3'</li>
	<li>'cluster4'</li>
	<li>'cluster5'</li>
	<li>'cluster6'</li>
	<li>'cluster7'</li>
	<li>'cluster8'</li>
	<li>'cluster9'</li>
</ol>




```R
# Define column names (GREAT-provided ones are not that friendly)
CNAMES_s = c("TermName","HyperRank","HyperRawPValue","HyperFDRQVal", "HyperFoldEnrichment", "HyperForegroundRegionHits", "HyperTotalRegions", "HyperRegionSetCoverage", "HyperForegroundGeneHits", "TotalGenesAnnotated")

# Load all into list
lofs <- map(lofn_shown, ~ read_tsv(., skip = 2, col_names = CNAMES_s)) 

names(lofs) <- locids_shown
```

    [1mRows: [22m[34m11[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m15[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m20[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m  (1): TermName
    [32mdbl[39m (12): HyperRank, HyperRawPValue, HyperFDRQVal, HyperFoldEnrichment, Hype...
    [33mlgl[39m  (1): X14
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
names(lofs)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'cluster10'</li><li>'cluster2'</li><li>'cluster3'</li><li>'cluster4'</li><li>'cluster5'</li><li>'cluster6'</li><li>'cluster7'</li><li>'cluster8'</li><li>'cluster9'</li></ol>




```R
lofs_top5 <- lofs %>% map(~top_n(., n = -5, wt = HyperRawPValue))
lofs_top5
```


<dl>
	<dt>$cluster10</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ventral spinal cord interneuron specification  </td><td> 89</td><td>9.573274e-08</td><td>0.0000141394</td><td>2.888112</td><td>34</td><td>0.006683704</td><td>370</td><td>0.001089930</td><td>3.167304</td><td>10</td><td>11</td><td>0.001878287</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment</td><td>120</td><td>1.548752e-06</td><td>0.0001696529</td><td>2.505620</td><td>35</td><td>0.006880283</td><td>555</td><td>0.010384003</td><td>2.554959</td><td>11</td><td>15</td><td>0.002066116</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron differentiation</td><td>127</td><td>2.432619e-06</td><td>0.0002517856</td><td>2.322813</td><td>39</td><td>0.007666601</td><td>415</td><td>0.001950209</td><td>2.664262</td><td>13</td><td>17</td><td>0.002441773</td><td>NA</td></tr>
	<tr><td>regulation of endocrine process                </td><td>142</td><td>5.950002e-06</td><td>0.0005507942</td><td>2.023479</td><td>49</td><td>0.009632396</td><td>742</td><td>0.040502455</td><td>1.742017</td><td>22</td><td>44</td><td>0.004132231</td><td>NA</td></tr>
	<tr><td>pharyngeal arch artery morphogenesis           </td><td>290</td><td>1.521941e-04</td><td>0.0068985912</td><td>2.529320</td><td>21</td><td>0.004128170</td><td>780</td><td>0.049644384</td><td>2.986315</td><td> 6</td><td> 7</td><td>0.001126972</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster2</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>leukocyte activation                        </td><td>4</td><td>1.884225e-91</td><td>6.192034e-88</td><td>2.165484</td><td>792</td><td>0.15393590</td><td>85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.06607395</td><td>NA</td></tr>
	<tr><td>cell activation                             </td><td>5</td><td>6.588506e-88</td><td>1.732118e-84</td><td>2.021410</td><td>883</td><td>0.17162290</td><td>69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.07597494</td><td>NA</td></tr>
	<tr><td>lymphocyte activation                       </td><td>6</td><td>1.694145e-87</td><td>3.711589e-84</td><td>2.711217</td><td>507</td><td>0.09854227</td><td>59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.03232976</td><td>NA</td></tr>
	<tr><td>leukocyte cell-cell adhesion                </td><td>7</td><td>1.805449e-82</td><td>3.390375e-79</td><td>2.985228</td><td>413</td><td>0.08027211</td><td>36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.02667205</td><td>NA</td></tr>
	<tr><td>positive regulation of immune system process</td><td>8</td><td>1.515236e-79</td><td>2.489722e-76</td><td>2.029000</td><td>799</td><td>0.15529640</td><td>98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.06708426</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster3</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>regulation of neutrophil activation                     </td><td>368</td><td>1.656167e-15</td><td>5.915847e-14</td><td>4.527465</td><td> 43</td><td>0.003109858</td><td>1118</td><td>0.016382421</td><td>2.075993</td><td> 9</td><td> 9</td><td>0.001007275</td><td>NA</td></tr>
	<tr><td>negative regulation of leukocyte degranulation          </td><td>369</td><td>1.989750e-15</td><td>7.088147e-14</td><td>3.750587</td><td> 53</td><td>0.003833080</td><td>1381</td><td>0.039497612</td><td>1.887267</td><td>10</td><td>11</td><td>0.001119194</td><td>NA</td></tr>
	<tr><td>negative regulation of peptidyl-tyrosine phosphorylation</td><td>402</td><td>4.746925e-14</td><td>1.552197e-12</td><td>2.163150</td><td>119</td><td>0.008606350</td><td>1421</td><td>0.042320619</td><td>1.413442</td><td>32</td><td>47</td><td>0.003581421</td><td>NA</td></tr>
	<tr><td>regulation of interleukin-4 production                  </td><td>410</td><td>8.146994e-14</td><td>2.612006e-12</td><td>2.312470</td><td>101</td><td>0.007304549</td><td>1273</td><td>0.027604531</td><td>1.596918</td><td>20</td><td>26</td><td>0.002238388</td><td>NA</td></tr>
	<tr><td>cardiac epithelial to mesenchymal transition            </td><td>418</td><td>1.542224e-13</td><td>4.849889e-12</td><td>2.004822</td><td>137</td><td>0.009908151</td><td> 722</td><td>0.001353885</td><td>1.768439</td><td>23</td><td>27</td><td>0.002574147</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster4</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>platelet activation                                         </td><td>243</td><td>3.008796e-35</td><td>1.627598e-33</td><td>2.030922</td><td>373</td><td>0.02768500</td><td>549</td><td>2.557751e-04</td><td>1.379287</td><td>92</td><td>139</td><td>0.010335920</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway                         </td><td>342</td><td>5.334162e-24</td><td>2.050221e-22</td><td>2.196593</td><td>207</td><td>0.01536406</td><td>712</td><td>1.830093e-03</td><td>1.453262</td><td>53</td><td> 76</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>positive regulation of T cell differentiation               </td><td>347</td><td>8.557288e-24</td><td>3.241659e-22</td><td>2.006928</td><td>254</td><td>0.01885252</td><td>402</td><td>1.561131e-05</td><td>1.598626</td><td>56</td><td> 73</td><td>0.006291428</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway involved in phagocytosis</td><td>348</td><td>8.592601e-24</td><td>3.245682e-22</td><td>2.197010</td><td>205</td><td>0.01521562</td><td>610</td><td>5.398365e-04</td><td>1.505056</td><td>52</td><td> 72</td><td>0.005842040</td><td>NA</td></tr>
	<tr><td>Fc receptor mediated stimulatory signaling pathway          </td><td>352</td><td>1.769939e-23</td><td>6.609616e-22</td><td>2.164341</td><td>209</td><td>0.01551251</td><td>623</td><td>6.502433e-04</td><td>1.492540</td><td>53</td><td> 74</td><td>0.005954387</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster5</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>dorsal spinal cord development                  </td><td> 90</td><td>2.588511e-24</td><td>3.780664e-22</td><td>3.025152</td><td>117</td><td>0.008226113</td><td>741</td><td>0.01285583</td><td>1.619457</td><td>19</td><td>21</td><td>0.001833446</td><td>NA</td></tr>
	<tr><td>spinal cord association neuron differentiation  </td><td> 97</td><td>6.079666e-21</td><td>8.238888e-19</td><td>3.437898</td><td> 83</td><td>0.005835618</td><td>983</td><td>0.04641332</td><td>1.662074</td><td>13</td><td>14</td><td>0.001254463</td><td>NA</td></tr>
	<tr><td>negative regulation of Notch signaling pathway  </td><td>135</td><td>1.560153e-15</td><td>1.519127e-13</td><td>2.433946</td><td>104</td><td>0.007312100</td><td>547</td><td>0.00204315</td><td>1.572965</td><td>29</td><td>33</td><td>0.002798417</td><td>NA</td></tr>
	<tr><td>regulation of mesenchymal cell apoptotic process</td><td>140</td><td>5.356475e-15</td><td>5.029347e-13</td><td>2.409294</td><td>102</td><td>0.007171483</td><td>770</td><td>0.01574086</td><td>1.789926</td><td>12</td><td>12</td><td>0.001157966</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment </td><td>162</td><td>6.339008e-14</td><td>5.143596e-12</td><td>2.406830</td><td> 94</td><td>0.006609014</td><td>886</td><td>0.03063835</td><td>1.670597</td><td>14</td><td>15</td><td>0.001350960</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster6</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>myeloid leukocyte activation                       </td><td>15</td><td>1.618950e-113</td><td>1.418740e-110</td><td>2.294861</td><td>909</td><td>0.08987542</td><td>39</td><td>7.460357e-14</td><td>1.404322</td><td>329</td><td>560</td><td>0.04239691</td><td>NA</td></tr>
	<tr><td>myeloid cell activation involved in immune response</td><td>21</td><td>2.444107e-104</td><td>1.529895e-101</td><td>2.348170</td><td>801</td><td>0.07919715</td><td>67</td><td>1.517078e-12</td><td>1.402204</td><td>298</td><td>508</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>leukocyte degranulation                            </td><td>23</td><td>1.100051e-102</td><td>6.287031e-100</td><td>2.356930</td><td>783</td><td>0.07741744</td><td>76</td><td>2.716302e-12</td><td>1.401562</td><td>292</td><td>498</td><td>0.03762887</td><td>NA</td></tr>
	<tr><td>myeloid leukocyte mediated immunity                </td><td>25</td><td>3.227605e-100</td><td> 1.697075e-97</td><td>2.317745</td><td>790</td><td>0.07810955</td><td>75</td><td>2.729572e-12</td><td>1.396706</td><td>298</td><td>510</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>cell activation involved in immune response        </td><td>26</td><td>3.444435e-100</td><td> 1.741427e-97</td><td>2.133804</td><td>937</td><td>0.09264386</td><td>88</td><td>5.977176e-12</td><td>1.356890</td><td>344</td><td>606</td><td>0.04432990</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster7</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>immune response-regulating cell surface receptor signaling pathway</td><td>36</td><td>1.740206e-26</td><td>6.354169e-24</td><td>2.166753</td><td>231</td><td>0.05920041</td><td>343</td><td>3.187349e-03</td><td>1.413045</td><td>100</td><td>317</td><td>0.024148760</td><td>NA</td></tr>
	<tr><td>immune response-activating cell surface receptor signaling pathway</td><td>37</td><td>3.504343e-26</td><td>1.244989e-23</td><td>2.274283</td><td>206</td><td>0.05279344</td><td>375</td><td>6.164949e-03</td><td>1.414532</td><td> 90</td><td>285</td><td>0.021733880</td><td>NA</td></tr>
	<tr><td>immune response-activating signal transduction                    </td><td>43</td><td>2.064109e-25</td><td>6.309933e-23</td><td>2.036269</td><td>255</td><td>0.06535110</td><td>296</td><td>1.358810e-03</td><td>1.399063</td><td>119</td><td>381</td><td>0.028737020</td><td>NA</td></tr>
	<tr><td>B cell receptor signaling pathway                                 </td><td>46</td><td>5.808631e-25</td><td>1.659879e-22</td><td>4.353879</td><td> 75</td><td>0.01922091</td><td>160</td><td>2.471433e-05</td><td>2.815593</td><td> 22</td><td> 35</td><td>0.005312726</td><td>NA</td></tr>
	<tr><td>adaptive immune response                                          </td><td>67</td><td>2.481028e-20</td><td>4.867629e-18</td><td>2.166776</td><td>175</td><td>0.04484880</td><td>558</td><td>3.213934e-02</td><td>1.358905</td><td> 81</td><td>267</td><td>0.019560490</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster8</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>mammary gland epithelium development         </td><td>214</td><td>8.347727e-44</td><td>5.127611e-42</td><td>2.048944</td><td>461</td><td>0.019466260</td><td> 711</td><td>0.001869430</td><td>1.496692</td><td>42</td><td>55</td><td>0.004437870</td><td>NA</td></tr>
	<tr><td>corpus callosum development                  </td><td>298</td><td>4.280383e-32</td><td>1.888109e-30</td><td>3.443714</td><td>131</td><td>0.005531627</td><td>1287</td><td>0.047214430</td><td>1.698626</td><td>13</td><td>15</td><td>0.001373626</td><td>NA</td></tr>
	<tr><td>regulation of vascular permeability          </td><td>408</td><td>6.763732e-25</td><td>2.179148e-23</td><td>2.309902</td><td>194</td><td>0.008191876</td><td> 807</td><td>0.003953369</td><td>1.633295</td><td>25</td><td>30</td><td>0.002641589</td><td>NA</td></tr>
	<tr><td>regulation of catenin import into nucleus    </td><td>409</td><td>9.730355e-25</td><td>3.127274e-23</td><td>2.151625</td><td>225</td><td>0.009500887</td><td> 784</td><td>0.003332869</td><td>1.714959</td><td>21</td><td>24</td><td>0.002218935</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron specification</td><td>418</td><td>3.553676e-24</td><td>1.117538e-22</td><td>2.645736</td><td>145</td><td>0.006122794</td><td> 902</td><td>0.008863674</td><td>1.959954</td><td>11</td><td>11</td><td>0.001162299</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster9</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>steroid metabolic process                   </td><td>38</td><td>1.328991e-42</td><td>4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td>282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td>226</td><td>0.016781720</td><td>NA</td></tr>
	<tr><td>sterol metabolic process                    </td><td>46</td><td>2.897808e-40</td><td>8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td>850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td>129</td><td>0.009045465</td><td>NA</td></tr>
	<tr><td>cholesterol metabolic process               </td><td>50</td><td>4.301673e-38</td><td>1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td>910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td>111</td><td>0.007855273</td><td>NA</td></tr>
	<tr><td>secondary alcohol metabolic process         </td><td>51</td><td>1.322869e-37</td><td>3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td>868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td>116</td><td>0.008212330</td><td>NA</td></tr>
	<tr><td>high-density lipoprotein particle remodeling</td><td>80</td><td>1.265443e-30</td><td>2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td>921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td> 17</td><td>0.001666270</td><td>NA</td></tr>
</tbody>
</table>
</dd>
</dl>




```R
names(lofs_top5)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'cluster10'</li><li>'cluster2'</li><li>'cluster3'</li><li>'cluster4'</li><li>'cluster5'</li><li>'cluster6'</li><li>'cluster7'</li><li>'cluster8'</li><li>'cluster9'</li></ol>



### Top 5 per cluster - shown


```R
lofs_top5 <- lofs %>% map(~top_n(., n = -5, wt = HyperRawPValue))
lofs_top5

dfs_top5 <- rbindlist(lofs_top5, idcol = TRUE)
```


<dl>
	<dt>$cluster10</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ventral spinal cord interneuron specification  </td><td> 89</td><td>9.573274e-08</td><td>0.0000141394</td><td>2.888112</td><td>34</td><td>0.006683704</td><td>370</td><td>0.001089930</td><td>3.167304</td><td>10</td><td>11</td><td>0.001878287</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment</td><td>120</td><td>1.548752e-06</td><td>0.0001696529</td><td>2.505620</td><td>35</td><td>0.006880283</td><td>555</td><td>0.010384003</td><td>2.554959</td><td>11</td><td>15</td><td>0.002066116</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron differentiation</td><td>127</td><td>2.432619e-06</td><td>0.0002517856</td><td>2.322813</td><td>39</td><td>0.007666601</td><td>415</td><td>0.001950209</td><td>2.664262</td><td>13</td><td>17</td><td>0.002441773</td><td>NA</td></tr>
	<tr><td>regulation of endocrine process                </td><td>142</td><td>5.950002e-06</td><td>0.0005507942</td><td>2.023479</td><td>49</td><td>0.009632396</td><td>742</td><td>0.040502455</td><td>1.742017</td><td>22</td><td>44</td><td>0.004132231</td><td>NA</td></tr>
	<tr><td>pharyngeal arch artery morphogenesis           </td><td>290</td><td>1.521941e-04</td><td>0.0068985912</td><td>2.529320</td><td>21</td><td>0.004128170</td><td>780</td><td>0.049644384</td><td>2.986315</td><td> 6</td><td> 7</td><td>0.001126972</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster2</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>leukocyte activation                        </td><td>4</td><td>1.884225e-91</td><td>6.192034e-88</td><td>2.165484</td><td>792</td><td>0.15393590</td><td>85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.06607395</td><td>NA</td></tr>
	<tr><td>cell activation                             </td><td>5</td><td>6.588506e-88</td><td>1.732118e-84</td><td>2.021410</td><td>883</td><td>0.17162290</td><td>69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.07597494</td><td>NA</td></tr>
	<tr><td>lymphocyte activation                       </td><td>6</td><td>1.694145e-87</td><td>3.711589e-84</td><td>2.711217</td><td>507</td><td>0.09854227</td><td>59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.03232976</td><td>NA</td></tr>
	<tr><td>leukocyte cell-cell adhesion                </td><td>7</td><td>1.805449e-82</td><td>3.390375e-79</td><td>2.985228</td><td>413</td><td>0.08027211</td><td>36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.02667205</td><td>NA</td></tr>
	<tr><td>positive regulation of immune system process</td><td>8</td><td>1.515236e-79</td><td>2.489722e-76</td><td>2.029000</td><td>799</td><td>0.15529640</td><td>98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.06708426</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster3</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>regulation of neutrophil activation                     </td><td>368</td><td>1.656167e-15</td><td>5.915847e-14</td><td>4.527465</td><td> 43</td><td>0.003109858</td><td>1118</td><td>0.016382421</td><td>2.075993</td><td> 9</td><td> 9</td><td>0.001007275</td><td>NA</td></tr>
	<tr><td>negative regulation of leukocyte degranulation          </td><td>369</td><td>1.989750e-15</td><td>7.088147e-14</td><td>3.750587</td><td> 53</td><td>0.003833080</td><td>1381</td><td>0.039497612</td><td>1.887267</td><td>10</td><td>11</td><td>0.001119194</td><td>NA</td></tr>
	<tr><td>negative regulation of peptidyl-tyrosine phosphorylation</td><td>402</td><td>4.746925e-14</td><td>1.552197e-12</td><td>2.163150</td><td>119</td><td>0.008606350</td><td>1421</td><td>0.042320619</td><td>1.413442</td><td>32</td><td>47</td><td>0.003581421</td><td>NA</td></tr>
	<tr><td>regulation of interleukin-4 production                  </td><td>410</td><td>8.146994e-14</td><td>2.612006e-12</td><td>2.312470</td><td>101</td><td>0.007304549</td><td>1273</td><td>0.027604531</td><td>1.596918</td><td>20</td><td>26</td><td>0.002238388</td><td>NA</td></tr>
	<tr><td>cardiac epithelial to mesenchymal transition            </td><td>418</td><td>1.542224e-13</td><td>4.849889e-12</td><td>2.004822</td><td>137</td><td>0.009908151</td><td> 722</td><td>0.001353885</td><td>1.768439</td><td>23</td><td>27</td><td>0.002574147</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster4</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>platelet activation                                         </td><td>243</td><td>3.008796e-35</td><td>1.627598e-33</td><td>2.030922</td><td>373</td><td>0.02768500</td><td>549</td><td>2.557751e-04</td><td>1.379287</td><td>92</td><td>139</td><td>0.010335920</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway                         </td><td>342</td><td>5.334162e-24</td><td>2.050221e-22</td><td>2.196593</td><td>207</td><td>0.01536406</td><td>712</td><td>1.830093e-03</td><td>1.453262</td><td>53</td><td> 76</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>positive regulation of T cell differentiation               </td><td>347</td><td>8.557288e-24</td><td>3.241659e-22</td><td>2.006928</td><td>254</td><td>0.01885252</td><td>402</td><td>1.561131e-05</td><td>1.598626</td><td>56</td><td> 73</td><td>0.006291428</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway involved in phagocytosis</td><td>348</td><td>8.592601e-24</td><td>3.245682e-22</td><td>2.197010</td><td>205</td><td>0.01521562</td><td>610</td><td>5.398365e-04</td><td>1.505056</td><td>52</td><td> 72</td><td>0.005842040</td><td>NA</td></tr>
	<tr><td>Fc receptor mediated stimulatory signaling pathway          </td><td>352</td><td>1.769939e-23</td><td>6.609616e-22</td><td>2.164341</td><td>209</td><td>0.01551251</td><td>623</td><td>6.502433e-04</td><td>1.492540</td><td>53</td><td> 74</td><td>0.005954387</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster5</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>dorsal spinal cord development                  </td><td> 90</td><td>2.588511e-24</td><td>3.780664e-22</td><td>3.025152</td><td>117</td><td>0.008226113</td><td>741</td><td>0.01285583</td><td>1.619457</td><td>19</td><td>21</td><td>0.001833446</td><td>NA</td></tr>
	<tr><td>spinal cord association neuron differentiation  </td><td> 97</td><td>6.079666e-21</td><td>8.238888e-19</td><td>3.437898</td><td> 83</td><td>0.005835618</td><td>983</td><td>0.04641332</td><td>1.662074</td><td>13</td><td>14</td><td>0.001254463</td><td>NA</td></tr>
	<tr><td>negative regulation of Notch signaling pathway  </td><td>135</td><td>1.560153e-15</td><td>1.519127e-13</td><td>2.433946</td><td>104</td><td>0.007312100</td><td>547</td><td>0.00204315</td><td>1.572965</td><td>29</td><td>33</td><td>0.002798417</td><td>NA</td></tr>
	<tr><td>regulation of mesenchymal cell apoptotic process</td><td>140</td><td>5.356475e-15</td><td>5.029347e-13</td><td>2.409294</td><td>102</td><td>0.007171483</td><td>770</td><td>0.01574086</td><td>1.789926</td><td>12</td><td>12</td><td>0.001157966</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment </td><td>162</td><td>6.339008e-14</td><td>5.143596e-12</td><td>2.406830</td><td> 94</td><td>0.006609014</td><td>886</td><td>0.03063835</td><td>1.670597</td><td>14</td><td>15</td><td>0.001350960</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster6</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>myeloid leukocyte activation                       </td><td>15</td><td>1.618950e-113</td><td>1.418740e-110</td><td>2.294861</td><td>909</td><td>0.08987542</td><td>39</td><td>7.460357e-14</td><td>1.404322</td><td>329</td><td>560</td><td>0.04239691</td><td>NA</td></tr>
	<tr><td>myeloid cell activation involved in immune response</td><td>21</td><td>2.444107e-104</td><td>1.529895e-101</td><td>2.348170</td><td>801</td><td>0.07919715</td><td>67</td><td>1.517078e-12</td><td>1.402204</td><td>298</td><td>508</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>leukocyte degranulation                            </td><td>23</td><td>1.100051e-102</td><td>6.287031e-100</td><td>2.356930</td><td>783</td><td>0.07741744</td><td>76</td><td>2.716302e-12</td><td>1.401562</td><td>292</td><td>498</td><td>0.03762887</td><td>NA</td></tr>
	<tr><td>myeloid leukocyte mediated immunity                </td><td>25</td><td>3.227605e-100</td><td> 1.697075e-97</td><td>2.317745</td><td>790</td><td>0.07810955</td><td>75</td><td>2.729572e-12</td><td>1.396706</td><td>298</td><td>510</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>cell activation involved in immune response        </td><td>26</td><td>3.444435e-100</td><td> 1.741427e-97</td><td>2.133804</td><td>937</td><td>0.09264386</td><td>88</td><td>5.977176e-12</td><td>1.356890</td><td>344</td><td>606</td><td>0.04432990</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster7</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>immune response-regulating cell surface receptor signaling pathway</td><td>36</td><td>1.740206e-26</td><td>6.354169e-24</td><td>2.166753</td><td>231</td><td>0.05920041</td><td>343</td><td>3.187349e-03</td><td>1.413045</td><td>100</td><td>317</td><td>0.024148760</td><td>NA</td></tr>
	<tr><td>immune response-activating cell surface receptor signaling pathway</td><td>37</td><td>3.504343e-26</td><td>1.244989e-23</td><td>2.274283</td><td>206</td><td>0.05279344</td><td>375</td><td>6.164949e-03</td><td>1.414532</td><td> 90</td><td>285</td><td>0.021733880</td><td>NA</td></tr>
	<tr><td>immune response-activating signal transduction                    </td><td>43</td><td>2.064109e-25</td><td>6.309933e-23</td><td>2.036269</td><td>255</td><td>0.06535110</td><td>296</td><td>1.358810e-03</td><td>1.399063</td><td>119</td><td>381</td><td>0.028737020</td><td>NA</td></tr>
	<tr><td>B cell receptor signaling pathway                                 </td><td>46</td><td>5.808631e-25</td><td>1.659879e-22</td><td>4.353879</td><td> 75</td><td>0.01922091</td><td>160</td><td>2.471433e-05</td><td>2.815593</td><td> 22</td><td> 35</td><td>0.005312726</td><td>NA</td></tr>
	<tr><td>adaptive immune response                                          </td><td>67</td><td>2.481028e-20</td><td>4.867629e-18</td><td>2.166776</td><td>175</td><td>0.04484880</td><td>558</td><td>3.213934e-02</td><td>1.358905</td><td> 81</td><td>267</td><td>0.019560490</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster8</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>mammary gland epithelium development         </td><td>214</td><td>8.347727e-44</td><td>5.127611e-42</td><td>2.048944</td><td>461</td><td>0.019466260</td><td> 711</td><td>0.001869430</td><td>1.496692</td><td>42</td><td>55</td><td>0.004437870</td><td>NA</td></tr>
	<tr><td>corpus callosum development                  </td><td>298</td><td>4.280383e-32</td><td>1.888109e-30</td><td>3.443714</td><td>131</td><td>0.005531627</td><td>1287</td><td>0.047214430</td><td>1.698626</td><td>13</td><td>15</td><td>0.001373626</td><td>NA</td></tr>
	<tr><td>regulation of vascular permeability          </td><td>408</td><td>6.763732e-25</td><td>2.179148e-23</td><td>2.309902</td><td>194</td><td>0.008191876</td><td> 807</td><td>0.003953369</td><td>1.633295</td><td>25</td><td>30</td><td>0.002641589</td><td>NA</td></tr>
	<tr><td>regulation of catenin import into nucleus    </td><td>409</td><td>9.730355e-25</td><td>3.127274e-23</td><td>2.151625</td><td>225</td><td>0.009500887</td><td> 784</td><td>0.003332869</td><td>1.714959</td><td>21</td><td>24</td><td>0.002218935</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron specification</td><td>418</td><td>3.553676e-24</td><td>1.117538e-22</td><td>2.645736</td><td>145</td><td>0.006122794</td><td> 902</td><td>0.008863674</td><td>1.959954</td><td>11</td><td>11</td><td>0.001162299</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster9</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>steroid metabolic process                   </td><td>38</td><td>1.328991e-42</td><td>4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td>282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td>226</td><td>0.016781720</td><td>NA</td></tr>
	<tr><td>sterol metabolic process                    </td><td>46</td><td>2.897808e-40</td><td>8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td>850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td>129</td><td>0.009045465</td><td>NA</td></tr>
	<tr><td>cholesterol metabolic process               </td><td>50</td><td>4.301673e-38</td><td>1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td>910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td>111</td><td>0.007855273</td><td>NA</td></tr>
	<tr><td>secondary alcohol metabolic process         </td><td>51</td><td>1.322869e-37</td><td>3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td>868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td>116</td><td>0.008212330</td><td>NA</td></tr>
	<tr><td>high-density lipoprotein particle remodeling</td><td>80</td><td>1.265443e-30</td><td>2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td>921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td> 17</td><td>0.001666270</td><td>NA</td></tr>
</tbody>
</table>
</dd>
</dl>




```R
dfs_top5
```


<table class="dataframe">
<caption>A data.table: 45 × 15</caption>
<thead>
	<tr><th scope=col>.id</th><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron specification                     </td><td> 89</td><td> 9.573274e-08</td><td> 1.413940e-05</td><td>2.888112</td><td> 34</td><td>0.006683704</td><td> 370</td><td>1.089930e-03</td><td>3.167304</td><td> 10</td><td>  11</td><td>0.001878287</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron fate commitment                   </td><td>120</td><td> 1.548752e-06</td><td> 1.696529e-04</td><td>2.505620</td><td> 35</td><td>0.006880283</td><td> 555</td><td>1.038400e-02</td><td>2.554959</td><td> 11</td><td>  15</td><td>0.002066116</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron differentiation                   </td><td>127</td><td> 2.432619e-06</td><td> 2.517856e-04</td><td>2.322813</td><td> 39</td><td>0.007666601</td><td> 415</td><td>1.950209e-03</td><td>2.664262</td><td> 13</td><td>  17</td><td>0.002441773</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>regulation of endocrine process                                   </td><td>142</td><td> 5.950002e-06</td><td> 5.507942e-04</td><td>2.023479</td><td> 49</td><td>0.009632396</td><td> 742</td><td>4.050246e-02</td><td>1.742017</td><td> 22</td><td>  44</td><td>0.004132231</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>pharyngeal arch artery morphogenesis                              </td><td>290</td><td> 1.521941e-04</td><td> 6.898591e-03</td><td>2.529320</td><td> 21</td><td>0.004128170</td><td> 780</td><td>4.964438e-02</td><td>2.986315</td><td>  6</td><td>   7</td><td>0.001126972</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte activation                                              </td><td>  4</td><td> 1.884225e-91</td><td> 6.192034e-88</td><td>2.165484</td><td>792</td><td>0.153935900</td><td>  85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.066073950</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>cell activation                                                   </td><td>  5</td><td> 6.588506e-88</td><td> 1.732118e-84</td><td>2.021410</td><td>883</td><td>0.171622900</td><td>  69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.075974940</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>lymphocyte activation                                             </td><td>  6</td><td> 1.694145e-87</td><td> 3.711589e-84</td><td>2.711217</td><td>507</td><td>0.098542270</td><td>  59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.032329760</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte cell-cell adhesion                                      </td><td>  7</td><td> 1.805449e-82</td><td> 3.390375e-79</td><td>2.985228</td><td>413</td><td>0.080272110</td><td>  36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.026672050</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>positive regulation of immune system process                      </td><td>  8</td><td> 1.515236e-79</td><td> 2.489722e-76</td><td>2.029000</td><td>799</td><td>0.155296400</td><td>  98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.067084260</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>regulation of neutrophil activation                               </td><td>368</td><td> 1.656167e-15</td><td> 5.915847e-14</td><td>4.527465</td><td> 43</td><td>0.003109858</td><td>1118</td><td>1.638242e-02</td><td>2.075993</td><td>  9</td><td>   9</td><td>0.001007275</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>negative regulation of leukocyte degranulation                    </td><td>369</td><td> 1.989750e-15</td><td> 7.088147e-14</td><td>3.750587</td><td> 53</td><td>0.003833080</td><td>1381</td><td>3.949761e-02</td><td>1.887267</td><td> 10</td><td>  11</td><td>0.001119194</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>negative regulation of peptidyl-tyrosine phosphorylation          </td><td>402</td><td> 4.746925e-14</td><td> 1.552197e-12</td><td>2.163150</td><td>119</td><td>0.008606350</td><td>1421</td><td>4.232062e-02</td><td>1.413442</td><td> 32</td><td>  47</td><td>0.003581421</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>regulation of interleukin-4 production                            </td><td>410</td><td> 8.146994e-14</td><td> 2.612006e-12</td><td>2.312470</td><td>101</td><td>0.007304549</td><td>1273</td><td>2.760453e-02</td><td>1.596918</td><td> 20</td><td>  26</td><td>0.002238388</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>cardiac epithelial to mesenchymal transition                      </td><td>418</td><td> 1.542224e-13</td><td> 4.849889e-12</td><td>2.004822</td><td>137</td><td>0.009908151</td><td> 722</td><td>1.353885e-03</td><td>1.768439</td><td> 23</td><td>  27</td><td>0.002574147</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>platelet activation                                               </td><td>243</td><td> 3.008796e-35</td><td> 1.627598e-33</td><td>2.030922</td><td>373</td><td>0.027685000</td><td> 549</td><td>2.557751e-04</td><td>1.379287</td><td> 92</td><td> 139</td><td>0.010335920</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc-gamma receptor signaling pathway                               </td><td>342</td><td> 5.334162e-24</td><td> 2.050221e-22</td><td>2.196593</td><td>207</td><td>0.015364060</td><td> 712</td><td>1.830093e-03</td><td>1.453262</td><td> 53</td><td>  76</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>positive regulation of T cell differentiation                     </td><td>347</td><td> 8.557288e-24</td><td> 3.241659e-22</td><td>2.006928</td><td>254</td><td>0.018852520</td><td> 402</td><td>1.561131e-05</td><td>1.598626</td><td> 56</td><td>  73</td><td>0.006291428</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc-gamma receptor signaling pathway involved in phagocytosis      </td><td>348</td><td> 8.592601e-24</td><td> 3.245682e-22</td><td>2.197010</td><td>205</td><td>0.015215620</td><td> 610</td><td>5.398365e-04</td><td>1.505056</td><td> 52</td><td>  72</td><td>0.005842040</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc receptor mediated stimulatory signaling pathway                </td><td>352</td><td> 1.769939e-23</td><td> 6.609616e-22</td><td>2.164341</td><td>209</td><td>0.015512510</td><td> 623</td><td>6.502433e-04</td><td>1.492540</td><td> 53</td><td>  74</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>dorsal spinal cord development                                    </td><td> 90</td><td> 2.588511e-24</td><td> 3.780664e-22</td><td>3.025152</td><td>117</td><td>0.008226113</td><td> 741</td><td>1.285583e-02</td><td>1.619457</td><td> 19</td><td>  21</td><td>0.001833446</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>spinal cord association neuron differentiation                    </td><td> 97</td><td> 6.079666e-21</td><td> 8.238888e-19</td><td>3.437898</td><td> 83</td><td>0.005835618</td><td> 983</td><td>4.641332e-02</td><td>1.662074</td><td> 13</td><td>  14</td><td>0.001254463</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>negative regulation of Notch signaling pathway                    </td><td>135</td><td> 1.560153e-15</td><td> 1.519127e-13</td><td>2.433946</td><td>104</td><td>0.007312100</td><td> 547</td><td>2.043150e-03</td><td>1.572965</td><td> 29</td><td>  33</td><td>0.002798417</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>regulation of mesenchymal cell apoptotic process                  </td><td>140</td><td> 5.356475e-15</td><td> 5.029347e-13</td><td>2.409294</td><td>102</td><td>0.007171483</td><td> 770</td><td>1.574086e-02</td><td>1.789926</td><td> 12</td><td>  12</td><td>0.001157966</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>ventral spinal cord interneuron fate commitment                   </td><td>162</td><td> 6.339008e-14</td><td> 5.143596e-12</td><td>2.406830</td><td> 94</td><td>0.006609014</td><td> 886</td><td>3.063835e-02</td><td>1.670597</td><td> 14</td><td>  15</td><td>0.001350960</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid leukocyte activation                                      </td><td> 15</td><td>1.618950e-113</td><td>1.418740e-110</td><td>2.294861</td><td>909</td><td>0.089875420</td><td>  39</td><td>7.460357e-14</td><td>1.404322</td><td>329</td><td> 560</td><td>0.042396910</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid cell activation involved in immune response               </td><td> 21</td><td>2.444107e-104</td><td>1.529895e-101</td><td>2.348170</td><td>801</td><td>0.079197150</td><td>  67</td><td>1.517078e-12</td><td>1.402204</td><td>298</td><td> 508</td><td>0.038402060</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>leukocyte degranulation                                           </td><td> 23</td><td>1.100051e-102</td><td>6.287031e-100</td><td>2.356930</td><td>783</td><td>0.077417440</td><td>  76</td><td>2.716302e-12</td><td>1.401562</td><td>292</td><td> 498</td><td>0.037628870</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid leukocyte mediated immunity                               </td><td> 25</td><td>3.227605e-100</td><td> 1.697075e-97</td><td>2.317745</td><td>790</td><td>0.078109550</td><td>  75</td><td>2.729572e-12</td><td>1.396706</td><td>298</td><td> 510</td><td>0.038402060</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>cell activation involved in immune response                       </td><td> 26</td><td>3.444435e-100</td><td> 1.741427e-97</td><td>2.133804</td><td>937</td><td>0.092643860</td><td>  88</td><td>5.977176e-12</td><td>1.356890</td><td>344</td><td> 606</td><td>0.044329900</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-regulating cell surface receptor signaling pathway</td><td> 36</td><td> 1.740206e-26</td><td> 6.354169e-24</td><td>2.166753</td><td>231</td><td>0.059200410</td><td> 343</td><td>3.187349e-03</td><td>1.413045</td><td>100</td><td> 317</td><td>0.024148760</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-activating cell surface receptor signaling pathway</td><td> 37</td><td> 3.504343e-26</td><td> 1.244989e-23</td><td>2.274283</td><td>206</td><td>0.052793440</td><td> 375</td><td>6.164949e-03</td><td>1.414532</td><td> 90</td><td> 285</td><td>0.021733880</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-activating signal transduction                    </td><td> 43</td><td> 2.064109e-25</td><td> 6.309933e-23</td><td>2.036269</td><td>255</td><td>0.065351100</td><td> 296</td><td>1.358810e-03</td><td>1.399063</td><td>119</td><td> 381</td><td>0.028737020</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>B cell receptor signaling pathway                                 </td><td> 46</td><td> 5.808631e-25</td><td> 1.659879e-22</td><td>4.353879</td><td> 75</td><td>0.019220910</td><td> 160</td><td>2.471433e-05</td><td>2.815593</td><td> 22</td><td>  35</td><td>0.005312726</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>adaptive immune response                                          </td><td> 67</td><td> 2.481028e-20</td><td> 4.867629e-18</td><td>2.166776</td><td>175</td><td>0.044848800</td><td> 558</td><td>3.213934e-02</td><td>1.358905</td><td> 81</td><td> 267</td><td>0.019560490</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>mammary gland epithelium development                              </td><td>214</td><td> 8.347727e-44</td><td> 5.127611e-42</td><td>2.048944</td><td>461</td><td>0.019466260</td><td> 711</td><td>1.869430e-03</td><td>1.496692</td><td> 42</td><td>  55</td><td>0.004437870</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>corpus callosum development                                       </td><td>298</td><td> 4.280383e-32</td><td> 1.888109e-30</td><td>3.443714</td><td>131</td><td>0.005531627</td><td>1287</td><td>4.721443e-02</td><td>1.698626</td><td> 13</td><td>  15</td><td>0.001373626</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>regulation of vascular permeability                               </td><td>408</td><td> 6.763732e-25</td><td> 2.179148e-23</td><td>2.309902</td><td>194</td><td>0.008191876</td><td> 807</td><td>3.953369e-03</td><td>1.633295</td><td> 25</td><td>  30</td><td>0.002641589</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>regulation of catenin import into nucleus                         </td><td>409</td><td> 9.730355e-25</td><td> 3.127274e-23</td><td>2.151625</td><td>225</td><td>0.009500887</td><td> 784</td><td>3.332869e-03</td><td>1.714959</td><td> 21</td><td>  24</td><td>0.002218935</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>ventral spinal cord interneuron specification                     </td><td>418</td><td> 3.553676e-24</td><td> 1.117538e-22</td><td>2.645736</td><td>145</td><td>0.006122794</td><td> 902</td><td>8.863674e-03</td><td>1.959954</td><td> 11</td><td>  11</td><td>0.001162299</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>steroid metabolic process                                         </td><td> 38</td><td> 1.328991e-42</td><td> 4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td> 282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td> 226</td><td>0.016781720</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>sterol metabolic process                                          </td><td> 46</td><td> 2.897808e-40</td><td> 8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td> 850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td> 129</td><td>0.009045465</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>cholesterol metabolic process                                     </td><td> 50</td><td> 4.301673e-38</td><td> 1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td> 910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td> 111</td><td>0.007855273</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>secondary alcohol metabolic process                               </td><td> 51</td><td> 1.322869e-37</td><td> 3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td> 868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td> 116</td><td>0.008212330</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>high-density lipoprotein particle remodeling                      </td><td> 80</td><td> 1.265443e-30</td><td> 2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td> 921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td>  17</td><td>0.001666270</td><td>NA</td></tr>
</tbody>
</table>




```R
dfs_top5$.id
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'cluster10'</li><li>'cluster10'</li><li>'cluster10'</li><li>'cluster10'</li><li>'cluster10'</li><li>'cluster2'</li><li>'cluster2'</li><li>'cluster2'</li><li>'cluster2'</li><li>'cluster2'</li><li>'cluster3'</li><li>'cluster3'</li><li>'cluster3'</li><li>'cluster3'</li><li>'cluster3'</li><li>'cluster4'</li><li>'cluster4'</li><li>'cluster4'</li><li>'cluster4'</li><li>'cluster4'</li><li>'cluster5'</li><li>'cluster5'</li><li>'cluster5'</li><li>'cluster5'</li><li>'cluster5'</li><li>'cluster6'</li><li>'cluster6'</li><li>'cluster6'</li><li>'cluster6'</li><li>'cluster6'</li><li>'cluster7'</li><li>'cluster7'</li><li>'cluster7'</li><li>'cluster7'</li><li>'cluster7'</li><li>'cluster8'</li><li>'cluster8'</li><li>'cluster8'</li><li>'cluster8'</li><li>'cluster8'</li><li>'cluster9'</li><li>'cluster9'</li><li>'cluster9'</li><li>'cluster9'</li><li>'cluster9'</li></ol>



## Clean - for heatmap

### Combine results from all clusters (top 500 per) into one Df


```R
df_shown <- rbindlist(lofs, idcol = TRUE)
```


```R
df_shown
```


<table class="dataframe">
<caption>A data.table: 166 × 15</caption>
<thead>
	<tr><th scope=col>.id</th><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron specification       </td><td> 89</td><td>9.573274e-08</td><td>1.413940e-05</td><td>2.888112</td><td> 34</td><td>0.006683704</td><td>370</td><td>1.089930e-03</td><td>3.167304</td><td> 10</td><td>  11</td><td>0.0018782870</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron fate commitment     </td><td>120</td><td>1.548752e-06</td><td>1.696529e-04</td><td>2.505620</td><td> 35</td><td>0.006880283</td><td>555</td><td>1.038400e-02</td><td>2.554959</td><td> 11</td><td>  15</td><td>0.0020661160</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron differentiation     </td><td>127</td><td>2.432619e-06</td><td>2.517856e-04</td><td>2.322813</td><td> 39</td><td>0.007666601</td><td>415</td><td>1.950209e-03</td><td>2.664262</td><td> 13</td><td>  17</td><td>0.0024417730</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>regulation of endocrine process                     </td><td>142</td><td>5.950002e-06</td><td>5.507942e-04</td><td>2.023479</td><td> 49</td><td>0.009632396</td><td>742</td><td>4.050246e-02</td><td>1.742017</td><td> 22</td><td>  44</td><td>0.0041322310</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>pharyngeal arch artery morphogenesis                </td><td>290</td><td>1.521941e-04</td><td>6.898591e-03</td><td>2.529320</td><td> 21</td><td>0.004128170</td><td>780</td><td>4.964438e-02</td><td>2.986315</td><td>  6</td><td>   7</td><td>0.0011269720</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>parasympathetic nervous system development          </td><td>293</td><td>1.624581e-04</td><td>7.288436e-03</td><td>2.009900</td><td> 34</td><td>0.006683704</td><td>628</td><td>1.928685e-02</td><td>2.322690</td><td> 12</td><td>  18</td><td>0.0022539440</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>tricuspid valve morphogenesis                       </td><td>319</td><td>2.592101e-04</td><td>1.068124e-02</td><td>3.099152</td><td> 14</td><td>0.002752113</td><td>722</td><td>3.541844e-02</td><td>3.484035</td><td>  5</td><td>   5</td><td>0.0009391435</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>dorsal/ventral axis specification                   </td><td>394</td><td>5.499568e-04</td><td>1.834818e-02</td><td>2.046798</td><td> 27</td><td>0.005307647</td><td>757</td><td>4.394007e-02</td><td>2.322690</td><td> 10</td><td>  15</td><td>0.0018782870</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>notochord morphogenesis                             </td><td>469</td><td>9.530229e-04</td><td>2.671106e-02</td><td>2.144385</td><td> 22</td><td>0.004324749</td><td>659</td><td>2.290360e-02</td><td>2.787228</td><td>  8</td><td>  10</td><td>0.0015026300</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>pulmonary valve morphogenesis                       </td><td>499</td><td>1.189508e-03</td><td>3.133483e-02</td><td>2.067087</td><td> 23</td><td>0.004521329</td><td>467</td><td>3.835016e-03</td><td>2.903362</td><td> 10</td><td>  12</td><td>0.0018782870</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>negative regulation of NF-kappaB import into nucleus</td><td>554</td><td>1.642159e-03</td><td>3.896422e-02</td><td>2.091983</td><td> 21</td><td>0.004128170</td><td>628</td><td>1.928685e-02</td><td>2.322690</td><td> 12</td><td>  18</td><td>0.0022539440</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte activation                                </td><td>  4</td><td>1.884225e-91</td><td>6.192034e-88</td><td>2.165484</td><td>792</td><td>0.153935900</td><td> 85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.0660739500</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>cell activation                                     </td><td>  5</td><td>6.588506e-88</td><td>1.732118e-84</td><td>2.021410</td><td>883</td><td>0.171622900</td><td> 69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.0759749400</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>lymphocyte activation                               </td><td>  6</td><td>1.694145e-87</td><td>3.711589e-84</td><td>2.711217</td><td>507</td><td>0.098542270</td><td> 59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.0323297600</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte cell-cell adhesion                        </td><td>  7</td><td>1.805449e-82</td><td>3.390375e-79</td><td>2.985228</td><td>413</td><td>0.080272110</td><td> 36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.0266720500</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>positive regulation of immune system process        </td><td>  8</td><td>1.515236e-79</td><td>2.489722e-76</td><td>2.029000</td><td>799</td><td>0.155296400</td><td> 98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.0670842600</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte aggregation                               </td><td>  9</td><td>2.497743e-75</td><td>3.648092e-72</td><td>2.983776</td><td>378</td><td>0.073469390</td><td> 57</td><td>7.421132e-13</td><td>1.915293</td><td>116</td><td> 227</td><td>0.0234390800</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of leukocyte cell-cell adhesion          </td><td> 10</td><td>1.247484e-71</td><td>1.639818e-68</td><td>2.576343</td><td>454</td><td>0.088241010</td><td> 62</td><td>1.135495e-12</td><td>1.752175</td><td>151</td><td> 323</td><td>0.0305112100</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte differentiation                           </td><td> 11</td><td>1.343791e-68</td><td>1.605830e-65</td><td>2.559834</td><td>440</td><td>0.085519920</td><td> 83</td><td>1.884733e-11</td><td>1.737497</td><td>140</td><td> 302</td><td>0.0282885400</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>lymphocyte differentiation                          </td><td> 12</td><td>2.748472e-67</td><td>3.010722e-64</td><td>2.806633</td><td>371</td><td>0.072108840</td><td> 89</td><td>4.573005e-11</td><td>1.856978</td><td>109</td><td> 220</td><td>0.0220246500</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>lymphocyte aggregation                              </td><td> 13</td><td>1.271555e-66</td><td>1.285738e-63</td><td>2.869122</td><td>355</td><td>0.068999030</td><td> 65</td><td>1.403305e-12</td><td>1.916413</td><td>113</td><td> 221</td><td>0.0228329000</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>T cell activation                                   </td><td> 15</td><td>4.513072e-65</td><td>3.954955e-62</td><td>2.846798</td><td>351</td><td>0.068221570</td><td> 73</td><td>4.712547e-12</td><td>1.899686</td><td>111</td><td> 219</td><td>0.0224287700</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of T cell activation                     </td><td> 16</td><td>5.009166e-65</td><td>4.115343e-62</td><td>2.568666</td><td>415</td><td>0.080660840</td><td> 80</td><td>9.184438e-12</td><td>1.740157</td><td>143</td><td> 308</td><td>0.0288947300</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of lymphocyte activation                 </td><td> 17</td><td>3.320979e-63</td><td>2.567898e-60</td><td>2.291479</td><td>498</td><td>0.096793000</td><td> 82</td><td>1.262365e-11</td><td>1.639763</td><td>175</td><td> 400</td><td>0.0353606800</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of leukocyte activation                  </td><td> 18</td><td>2.294184e-62</td><td>1.675392e-59</td><td>2.187359</td><td>540</td><td>0.104956300</td><td> 76</td><td>7.970414e-12</td><td>1.598186</td><td>197</td><td> 462</td><td>0.0398060200</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of cell activation                       </td><td> 19</td><td>1.000337e-61</td><td>6.920753e-59</td><td>2.132693</td><td>564</td><td>0.109621000</td><td> 56</td><td>6.728224e-13</td><td>1.603073</td><td>213</td><td> 498</td><td>0.0430390000</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>hemopoiesis                                         </td><td> 20</td><td>1.025782e-59</td><td>6.741952e-57</td><td>2.056202</td><td>592</td><td>0.115063200</td><td> 55</td><td>5.783305e-13</td><td>1.595841</td><td>218</td><td> 512</td><td>0.0440493000</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>regulation of cell-cell adhesion                    </td><td> 24</td><td>5.816550e-58</td><td>3.185773e-55</td><td>2.174968</td><td>509</td><td>0.098931000</td><td> 47</td><td>8.858292e-14</td><td>1.704506</td><td>181</td><td> 398</td><td>0.0365730500</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>single organismal cell-cell adhesion                </td><td> 27</td><td>1.405011e-54</td><td>6.840322e-52</td><td>2.179283</td><td>478</td><td>0.092905730</td><td> 43</td><td>1.311770e-14</td><td>1.765000</td><td>170</td><td> 361</td><td>0.0343503700</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>single organism cell adhesion                       </td><td> 29</td><td>1.193101e-51</td><td>5.408039e-49</td><td>2.103317</td><td>489</td><td>0.095043730</td><td> 53</td><td>3.516714e-13</td><td>1.699236</td><td>175</td><td> 386</td><td>0.0353606800</td><td>NA</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>cluster8</td><td>rostrocaudal neural tube patterning               </td><td>553</td><td>6.766008e-20</td><td>1.608303e-18</td><td>2.718420</td><td>112</td><td>0.004729330</td><td>1224</td><td>4.174413e-02</td><td>1.796624</td><td> 11</td><td> 12</td><td>0.0011622990</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>metanephric tubule morphogenesis                  </td><td>574</td><td>2.821657e-19</td><td>6.461791e-18</td><td>2.782869</td><td>104</td><td>0.004391521</td><td>1003</td><td>1.563112e-02</td><td>1.959954</td><td> 10</td><td> 10</td><td>0.0010566360</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>metanephric nephron tubule development            </td><td>595</td><td>1.140949e-18</td><td>2.520634e-17</td><td>2.236692</td><td>152</td><td>0.006418377</td><td>1164</td><td>3.012855e-02</td><td>1.714959</td><td> 14</td><td> 16</td><td>0.0014792900</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>positive regulation of receptor recycling         </td><td>600</td><td>1.264764e-18</td><td>2.770887e-17</td><td>2.736654</td><td>103</td><td>0.004349295</td><td> 997</td><td>1.537026e-02</td><td>1.819957</td><td> 13</td><td> 14</td><td>0.0013736260</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>dorsal spinal cord development                    </td><td>618</td><td>4.016296e-18</td><td>8.542753e-17</td><td>2.251657</td><td>145</td><td>0.006122794</td><td>1301</td><td>4.749944e-02</td><td>1.586629</td><td> 17</td><td> 21</td><td>0.0017962810</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>metanephric nephron epithelium development        </td><td>644</td><td>1.456248e-17</td><td>2.972419e-16</td><td>2.163691</td><td>153</td><td>0.006460603</td><td>1310</td><td>4.837181e-02</td><td>1.633295</td><td> 15</td><td> 18</td><td>0.0015849540</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>commissural neuron axon guidance                  </td><td>686</td><td>8.023672e-17</td><td>1.537481e-15</td><td>2.566937</td><td>103</td><td>0.004349295</td><td>1268</td><td>4.753852e-02</td><td>1.959954</td><td>  8</td><td>  8</td><td>0.0008453085</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>metanephric nephron tubule morphogenesis          </td><td>726</td><td>3.803265e-16</td><td>6.886215e-15</td><td>2.699764</td><td> 90</td><td>0.003800355</td><td>1268</td><td>4.753852e-02</td><td>1.959954</td><td>  8</td><td>  8</td><td>0.0008453085</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>positive regulation of catenin import into nucleus</td><td>808</td><td>8.441303e-15</td><td>1.373279e-13</td><td>2.159226</td><td>127</td><td>0.005362723</td><td> 902</td><td>8.863674e-03</td><td>1.959954</td><td> 11</td><td> 11</td><td>0.0011622990</td><td>NA</td></tr>
	<tr><td>cluster8</td><td>negative regulation of Notch signaling pathway    </td><td>818</td><td>9.889266e-15</td><td>1.589174e-13</td><td>2.038067</td><td>145</td><td>0.006122794</td><td> 811</td><td>4.003136e-03</td><td>1.603598</td><td> 27</td><td> 33</td><td>0.0028529160</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>steroid metabolic process                         </td><td> 38</td><td>1.328991e-42</td><td>4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td> 282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td>226</td><td>0.0167817200</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>sterol metabolic process                          </td><td> 46</td><td>2.897808e-40</td><td>8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td> 850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td>129</td><td>0.0090454650</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>cholesterol metabolic process                     </td><td> 50</td><td>4.301673e-38</td><td>1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td> 910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td>111</td><td>0.0078552730</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>secondary alcohol metabolic process               </td><td> 51</td><td>1.322869e-37</td><td>3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td> 868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td>116</td><td>0.0082123300</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>high-density lipoprotein particle remodeling      </td><td> 80</td><td>1.265443e-30</td><td>2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td> 921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td> 17</td><td>0.0016662700</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>regulation of plasma lipoprotein particle levels  </td><td>102</td><td>4.291431e-28</td><td>5.530477e-26</td><td>2.688594</td><td>165</td><td>0.013607130</td><td> 332</td><td>3.868608e-05</td><td>1.625104</td><td> 53</td><td> 72</td><td>0.0063080220</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>reverse cholesterol transport                     </td><td>123</td><td>2.504759e-26</td><td>2.676834e-24</td><td>5.426608</td><td> 64</td><td>0.005277915</td><td> 921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td> 17</td><td>0.0016662700</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>lipid homeostasis                                 </td><td>147</td><td>8.146991e-25</td><td>7.285183e-23</td><td>2.175361</td><td>219</td><td>0.018060370</td><td> 570</td><td>2.124018e-03</td><td>1.414635</td><td> 66</td><td>103</td><td>0.0078552730</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>cholesterol homeostasis                           </td><td>168</td><td>6.098296e-23</td><td>4.771554e-21</td><td>2.568825</td><td>144</td><td>0.011875310</td><td> 977</td><td>3.211630e-02</td><td>1.421901</td><td> 38</td><td> 59</td><td>0.0045227330</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>protein-lipid complex subunit organization        </td><td>175</td><td>2.016057e-22</td><td>1.514347e-20</td><td>2.844373</td><td>118</td><td>0.009731156</td><td> 607</td><td>3.377070e-03</td><td>1.597051</td><td> 34</td><td> 47</td><td>0.0040466560</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>plasma lipoprotein particle clearance             </td><td>189</td><td>2.180515e-21</td><td>1.516554e-19</td><td>2.911916</td><td>108</td><td>0.008906482</td><td> 718</td><td>8.198033e-03</td><td>1.600574</td><td> 29</td><td> 40</td><td>0.0034515590</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>plasma lipoprotein particle organization          </td><td>192</td><td>2.588346e-21</td><td>1.772073e-19</td><td>2.922148</td><td>107</td><td>0.008824015</td><td> 646</td><td>4.206188e-03</td><td>1.605592</td><td> 32</td><td> 44</td><td>0.0038086170</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>plasma lipoprotein particle remodeling            </td><td>196</td><td>4.566835e-21</td><td>3.062808e-19</td><td>3.392556</td><td> 85</td><td>0.007009731</td><td> 693</td><td>6.478840e-03</td><td>1.734613</td><td> 22</td><td> 28</td><td>0.0026184240</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>regulation of cholesterol metabolic process       </td><td>220</td><td>1.233610e-19</td><td>7.370820e-18</td><td>2.691838</td><td>112</td><td>0.009236352</td><td> 914</td><td>2.670447e-02</td><td>1.457908</td><td> 35</td><td> 53</td><td>0.0041656750</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>regulation of mitochondrial membrane permeability </td><td>247</td><td>1.018448e-18</td><td>5.420040e-17</td><td>2.229164</td><td>153</td><td>0.012617520</td><td> 516</td><td>1.316471e-03</td><td>1.512116</td><td> 50</td><td> 73</td><td>0.0059509640</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>cholesterol transport                             </td><td>259</td><td>5.255437e-18</td><td>2.667286e-16</td><td>2.448611</td><td>121</td><td>0.009978558</td><td>1001</td><td>3.620966e-02</td><td>1.443489</td><td> 34</td><td> 52</td><td>0.0040466560</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>regulation of membrane permeability               </td><td>270</td><td>1.264016e-17</td><td>6.153885e-16</td><td>2.099933</td><td>164</td><td>0.013524660</td><td> 486</td><td>8.799036e-04</td><td>1.499048</td><td> 55</td><td> 81</td><td>0.0065460600</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>sterol transport                                  </td><td>309</td><td>3.573940e-16</td><td>1.520370e-14</td><td>2.246945</td><td>128</td><td>0.010555830</td><td>1048</td><td>4.626573e-02</td><td>1.398203</td><td> 38</td><td> 60</td><td>0.0045227330</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>xenobiotic metabolic process                      </td><td>341</td><td>4.749604e-15</td><td>1.830896e-13</td><td>2.011085</td><td>153</td><td>0.012617520</td><td> 950</td><td>3.147291e-02</td><td>1.316122</td><td> 62</td><td>104</td><td>0.0073791950</td><td>NA</td></tr>
	<tr><td>cluster9</td><td>foregut morphogenesis                             </td><td>419</td><td>4.220069e-13</td><td>1.323933e-11</td><td>2.699608</td><td> 71</td><td>0.005855187</td><td> 703</td><td>6.778817e-03</td><td>2.207689</td><td> 10</td><td> 10</td><td>0.0011901930</td><td>NA</td></tr>
</tbody>
</table>




```R
lofs_top5
```


<dl>
	<dt>$cluster10</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ventral spinal cord interneuron specification  </td><td> 89</td><td>9.573274e-08</td><td>0.0000141394</td><td>2.888112</td><td>34</td><td>0.006683704</td><td>370</td><td>0.001089930</td><td>3.167304</td><td>10</td><td>11</td><td>0.001878287</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment</td><td>120</td><td>1.548752e-06</td><td>0.0001696529</td><td>2.505620</td><td>35</td><td>0.006880283</td><td>555</td><td>0.010384003</td><td>2.554959</td><td>11</td><td>15</td><td>0.002066116</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron differentiation</td><td>127</td><td>2.432619e-06</td><td>0.0002517856</td><td>2.322813</td><td>39</td><td>0.007666601</td><td>415</td><td>0.001950209</td><td>2.664262</td><td>13</td><td>17</td><td>0.002441773</td><td>NA</td></tr>
	<tr><td>regulation of endocrine process                </td><td>142</td><td>5.950002e-06</td><td>0.0005507942</td><td>2.023479</td><td>49</td><td>0.009632396</td><td>742</td><td>0.040502455</td><td>1.742017</td><td>22</td><td>44</td><td>0.004132231</td><td>NA</td></tr>
	<tr><td>pharyngeal arch artery morphogenesis           </td><td>290</td><td>1.521941e-04</td><td>0.0068985912</td><td>2.529320</td><td>21</td><td>0.004128170</td><td>780</td><td>0.049644384</td><td>2.986315</td><td> 6</td><td> 7</td><td>0.001126972</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster2</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>leukocyte activation                        </td><td>4</td><td>1.884225e-91</td><td>6.192034e-88</td><td>2.165484</td><td>792</td><td>0.15393590</td><td>85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.06607395</td><td>NA</td></tr>
	<tr><td>cell activation                             </td><td>5</td><td>6.588506e-88</td><td>1.732118e-84</td><td>2.021410</td><td>883</td><td>0.17162290</td><td>69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.07597494</td><td>NA</td></tr>
	<tr><td>lymphocyte activation                       </td><td>6</td><td>1.694145e-87</td><td>3.711589e-84</td><td>2.711217</td><td>507</td><td>0.09854227</td><td>59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.03232976</td><td>NA</td></tr>
	<tr><td>leukocyte cell-cell adhesion                </td><td>7</td><td>1.805449e-82</td><td>3.390375e-79</td><td>2.985228</td><td>413</td><td>0.08027211</td><td>36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.02667205</td><td>NA</td></tr>
	<tr><td>positive regulation of immune system process</td><td>8</td><td>1.515236e-79</td><td>2.489722e-76</td><td>2.029000</td><td>799</td><td>0.15529640</td><td>98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.06708426</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster3</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>regulation of neutrophil activation                     </td><td>368</td><td>1.656167e-15</td><td>5.915847e-14</td><td>4.527465</td><td> 43</td><td>0.003109858</td><td>1118</td><td>0.016382421</td><td>2.075993</td><td> 9</td><td> 9</td><td>0.001007275</td><td>NA</td></tr>
	<tr><td>negative regulation of leukocyte degranulation          </td><td>369</td><td>1.989750e-15</td><td>7.088147e-14</td><td>3.750587</td><td> 53</td><td>0.003833080</td><td>1381</td><td>0.039497612</td><td>1.887267</td><td>10</td><td>11</td><td>0.001119194</td><td>NA</td></tr>
	<tr><td>negative regulation of peptidyl-tyrosine phosphorylation</td><td>402</td><td>4.746925e-14</td><td>1.552197e-12</td><td>2.163150</td><td>119</td><td>0.008606350</td><td>1421</td><td>0.042320619</td><td>1.413442</td><td>32</td><td>47</td><td>0.003581421</td><td>NA</td></tr>
	<tr><td>regulation of interleukin-4 production                  </td><td>410</td><td>8.146994e-14</td><td>2.612006e-12</td><td>2.312470</td><td>101</td><td>0.007304549</td><td>1273</td><td>0.027604531</td><td>1.596918</td><td>20</td><td>26</td><td>0.002238388</td><td>NA</td></tr>
	<tr><td>cardiac epithelial to mesenchymal transition            </td><td>418</td><td>1.542224e-13</td><td>4.849889e-12</td><td>2.004822</td><td>137</td><td>0.009908151</td><td> 722</td><td>0.001353885</td><td>1.768439</td><td>23</td><td>27</td><td>0.002574147</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster4</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>platelet activation                                         </td><td>243</td><td>3.008796e-35</td><td>1.627598e-33</td><td>2.030922</td><td>373</td><td>0.02768500</td><td>549</td><td>2.557751e-04</td><td>1.379287</td><td>92</td><td>139</td><td>0.010335920</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway                         </td><td>342</td><td>5.334162e-24</td><td>2.050221e-22</td><td>2.196593</td><td>207</td><td>0.01536406</td><td>712</td><td>1.830093e-03</td><td>1.453262</td><td>53</td><td> 76</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>positive regulation of T cell differentiation               </td><td>347</td><td>8.557288e-24</td><td>3.241659e-22</td><td>2.006928</td><td>254</td><td>0.01885252</td><td>402</td><td>1.561131e-05</td><td>1.598626</td><td>56</td><td> 73</td><td>0.006291428</td><td>NA</td></tr>
	<tr><td>Fc-gamma receptor signaling pathway involved in phagocytosis</td><td>348</td><td>8.592601e-24</td><td>3.245682e-22</td><td>2.197010</td><td>205</td><td>0.01521562</td><td>610</td><td>5.398365e-04</td><td>1.505056</td><td>52</td><td> 72</td><td>0.005842040</td><td>NA</td></tr>
	<tr><td>Fc receptor mediated stimulatory signaling pathway          </td><td>352</td><td>1.769939e-23</td><td>6.609616e-22</td><td>2.164341</td><td>209</td><td>0.01551251</td><td>623</td><td>6.502433e-04</td><td>1.492540</td><td>53</td><td> 74</td><td>0.005954387</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster5</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>dorsal spinal cord development                  </td><td> 90</td><td>2.588511e-24</td><td>3.780664e-22</td><td>3.025152</td><td>117</td><td>0.008226113</td><td>741</td><td>0.01285583</td><td>1.619457</td><td>19</td><td>21</td><td>0.001833446</td><td>NA</td></tr>
	<tr><td>spinal cord association neuron differentiation  </td><td> 97</td><td>6.079666e-21</td><td>8.238888e-19</td><td>3.437898</td><td> 83</td><td>0.005835618</td><td>983</td><td>0.04641332</td><td>1.662074</td><td>13</td><td>14</td><td>0.001254463</td><td>NA</td></tr>
	<tr><td>negative regulation of Notch signaling pathway  </td><td>135</td><td>1.560153e-15</td><td>1.519127e-13</td><td>2.433946</td><td>104</td><td>0.007312100</td><td>547</td><td>0.00204315</td><td>1.572965</td><td>29</td><td>33</td><td>0.002798417</td><td>NA</td></tr>
	<tr><td>regulation of mesenchymal cell apoptotic process</td><td>140</td><td>5.356475e-15</td><td>5.029347e-13</td><td>2.409294</td><td>102</td><td>0.007171483</td><td>770</td><td>0.01574086</td><td>1.789926</td><td>12</td><td>12</td><td>0.001157966</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron fate commitment </td><td>162</td><td>6.339008e-14</td><td>5.143596e-12</td><td>2.406830</td><td> 94</td><td>0.006609014</td><td>886</td><td>0.03063835</td><td>1.670597</td><td>14</td><td>15</td><td>0.001350960</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster6</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>myeloid leukocyte activation                       </td><td>15</td><td>1.618950e-113</td><td>1.418740e-110</td><td>2.294861</td><td>909</td><td>0.08987542</td><td>39</td><td>7.460357e-14</td><td>1.404322</td><td>329</td><td>560</td><td>0.04239691</td><td>NA</td></tr>
	<tr><td>myeloid cell activation involved in immune response</td><td>21</td><td>2.444107e-104</td><td>1.529895e-101</td><td>2.348170</td><td>801</td><td>0.07919715</td><td>67</td><td>1.517078e-12</td><td>1.402204</td><td>298</td><td>508</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>leukocyte degranulation                            </td><td>23</td><td>1.100051e-102</td><td>6.287031e-100</td><td>2.356930</td><td>783</td><td>0.07741744</td><td>76</td><td>2.716302e-12</td><td>1.401562</td><td>292</td><td>498</td><td>0.03762887</td><td>NA</td></tr>
	<tr><td>myeloid leukocyte mediated immunity                </td><td>25</td><td>3.227605e-100</td><td> 1.697075e-97</td><td>2.317745</td><td>790</td><td>0.07810955</td><td>75</td><td>2.729572e-12</td><td>1.396706</td><td>298</td><td>510</td><td>0.03840206</td><td>NA</td></tr>
	<tr><td>cell activation involved in immune response        </td><td>26</td><td>3.444435e-100</td><td> 1.741427e-97</td><td>2.133804</td><td>937</td><td>0.09264386</td><td>88</td><td>5.977176e-12</td><td>1.356890</td><td>344</td><td>606</td><td>0.04432990</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster7</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>immune response-regulating cell surface receptor signaling pathway</td><td>36</td><td>1.740206e-26</td><td>6.354169e-24</td><td>2.166753</td><td>231</td><td>0.05920041</td><td>343</td><td>3.187349e-03</td><td>1.413045</td><td>100</td><td>317</td><td>0.024148760</td><td>NA</td></tr>
	<tr><td>immune response-activating cell surface receptor signaling pathway</td><td>37</td><td>3.504343e-26</td><td>1.244989e-23</td><td>2.274283</td><td>206</td><td>0.05279344</td><td>375</td><td>6.164949e-03</td><td>1.414532</td><td> 90</td><td>285</td><td>0.021733880</td><td>NA</td></tr>
	<tr><td>immune response-activating signal transduction                    </td><td>43</td><td>2.064109e-25</td><td>6.309933e-23</td><td>2.036269</td><td>255</td><td>0.06535110</td><td>296</td><td>1.358810e-03</td><td>1.399063</td><td>119</td><td>381</td><td>0.028737020</td><td>NA</td></tr>
	<tr><td>B cell receptor signaling pathway                                 </td><td>46</td><td>5.808631e-25</td><td>1.659879e-22</td><td>4.353879</td><td> 75</td><td>0.01922091</td><td>160</td><td>2.471433e-05</td><td>2.815593</td><td> 22</td><td> 35</td><td>0.005312726</td><td>NA</td></tr>
	<tr><td>adaptive immune response                                          </td><td>67</td><td>2.481028e-20</td><td>4.867629e-18</td><td>2.166776</td><td>175</td><td>0.04484880</td><td>558</td><td>3.213934e-02</td><td>1.358905</td><td> 81</td><td>267</td><td>0.019560490</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster8</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>mammary gland epithelium development         </td><td>214</td><td>8.347727e-44</td><td>5.127611e-42</td><td>2.048944</td><td>461</td><td>0.019466260</td><td> 711</td><td>0.001869430</td><td>1.496692</td><td>42</td><td>55</td><td>0.004437870</td><td>NA</td></tr>
	<tr><td>corpus callosum development                  </td><td>298</td><td>4.280383e-32</td><td>1.888109e-30</td><td>3.443714</td><td>131</td><td>0.005531627</td><td>1287</td><td>0.047214430</td><td>1.698626</td><td>13</td><td>15</td><td>0.001373626</td><td>NA</td></tr>
	<tr><td>regulation of vascular permeability          </td><td>408</td><td>6.763732e-25</td><td>2.179148e-23</td><td>2.309902</td><td>194</td><td>0.008191876</td><td> 807</td><td>0.003953369</td><td>1.633295</td><td>25</td><td>30</td><td>0.002641589</td><td>NA</td></tr>
	<tr><td>regulation of catenin import into nucleus    </td><td>409</td><td>9.730355e-25</td><td>3.127274e-23</td><td>2.151625</td><td>225</td><td>0.009500887</td><td> 784</td><td>0.003332869</td><td>1.714959</td><td>21</td><td>24</td><td>0.002218935</td><td>NA</td></tr>
	<tr><td>ventral spinal cord interneuron specification</td><td>418</td><td>3.553676e-24</td><td>1.117538e-22</td><td>2.645736</td><td>145</td><td>0.006122794</td><td> 902</td><td>0.008863674</td><td>1.959954</td><td>11</td><td>11</td><td>0.001162299</td><td>NA</td></tr>
</tbody>
</table>
</dd>
	<dt>$cluster9</dt>
		<dd><table class="dataframe">
<caption>A spec_tbl_df: 5 × 14</caption>
<thead>
	<tr><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>steroid metabolic process                   </td><td>38</td><td>1.328991e-42</td><td>4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td>282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td>226</td><td>0.016781720</td><td>NA</td></tr>
	<tr><td>sterol metabolic process                    </td><td>46</td><td>2.897808e-40</td><td>8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td>850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td>129</td><td>0.009045465</td><td>NA</td></tr>
	<tr><td>cholesterol metabolic process               </td><td>50</td><td>4.301673e-38</td><td>1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td>910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td>111</td><td>0.007855273</td><td>NA</td></tr>
	<tr><td>secondary alcohol metabolic process         </td><td>51</td><td>1.322869e-37</td><td>3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td>868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td>116</td><td>0.008212330</td><td>NA</td></tr>
	<tr><td>high-density lipoprotein particle remodeling</td><td>80</td><td>1.265443e-30</td><td>2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td>921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td> 17</td><td>0.001666270</td><td>NA</td></tr>
</tbody>
</table>
</dd>
</dl>



## Clean - for bargraphs by individual cluster 


```R
res_cluster2 <- lofs_top5$cluster2 # Fetal
res_cluster3 <- lofs_top5$cluster3 # ALL
res_cluster4 <- lofs_top5$cluster4 # liver/hepatic
res_cluster5 <- lofs_top5$cluster5 # B cell
res_cluster6 <- lofs_top5$cluster6 # T cell/lymph
res_cluster7 <- lofs_top5$cluster7 # macrophage
res_cluster8 <- lofs_top5$cluster8 # hematopoietic
res_cluster9 <- lofs_top5$cluster9 # Fetal/Endocrine
res_cluster10 <- lofs_top5$cluster10 # Differentiated

print("Done.")

# ORder
res_cluster2$TermName <- reorder(res_cluster2$TermName, -res_cluster2$HyperFDRQVal) 
res_cluster3$TermName <- reorder(res_cluster3$TermName, -res_cluster3$HyperFDRQVal) 
res_cluster4$TermName <- reorder(res_cluster4$TermName, -res_cluster4$HyperFDRQVal)
res_cluster5$TermName <- reorder(res_cluster5$TermName, -res_cluster5$HyperFDRQVal) 
res_cluster6$TermName <- reorder(res_cluster6$TermName, -res_cluster6$HyperFDRQVal)
res_cluster7$TermName <- reorder(res_cluster7$TermName, -res_cluster7$HyperFDRQVal) 
res_cluster8$TermName <- reorder(res_cluster8$TermName, -res_cluster8$HyperFDRQVal) 
res_cluster9$TermName <- reorder(res_cluster9$TermName, -res_cluster9$HyperFDRQVal)
res_cluster10$TermName <- reorder(res_cluster10$TermName, -res_cluster10$HyperFDRQVal) 

print("Done.")
```

    [1] "Done."
    [1] "Done."



```R
dfs_top5
```


<table class="dataframe">
<caption>A data.table: 45 × 15</caption>
<thead>
	<tr><th scope=col>.id</th><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron specification                     </td><td> 89</td><td> 9.573274e-08</td><td> 1.413940e-05</td><td>2.888112</td><td> 34</td><td>0.006683704</td><td> 370</td><td>1.089930e-03</td><td>3.167304</td><td> 10</td><td>  11</td><td>0.001878287</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron fate commitment                   </td><td>120</td><td> 1.548752e-06</td><td> 1.696529e-04</td><td>2.505620</td><td> 35</td><td>0.006880283</td><td> 555</td><td>1.038400e-02</td><td>2.554959</td><td> 11</td><td>  15</td><td>0.002066116</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>ventral spinal cord interneuron differentiation                   </td><td>127</td><td> 2.432619e-06</td><td> 2.517856e-04</td><td>2.322813</td><td> 39</td><td>0.007666601</td><td> 415</td><td>1.950209e-03</td><td>2.664262</td><td> 13</td><td>  17</td><td>0.002441773</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>regulation of endocrine process                                   </td><td>142</td><td> 5.950002e-06</td><td> 5.507942e-04</td><td>2.023479</td><td> 49</td><td>0.009632396</td><td> 742</td><td>4.050246e-02</td><td>1.742017</td><td> 22</td><td>  44</td><td>0.004132231</td><td>NA</td></tr>
	<tr><td>cluster10</td><td>pharyngeal arch artery morphogenesis                              </td><td>290</td><td> 1.521941e-04</td><td> 6.898591e-03</td><td>2.529320</td><td> 21</td><td>0.004128170</td><td> 780</td><td>4.964438e-02</td><td>2.986315</td><td>  6</td><td>   7</td><td>0.001126972</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte activation                                              </td><td>  4</td><td> 1.884225e-91</td><td> 6.192034e-88</td><td>2.165484</td><td>792</td><td>0.153935900</td><td>  85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.066073950</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>cell activation                                                   </td><td>  5</td><td> 6.588506e-88</td><td> 1.732118e-84</td><td>2.021410</td><td>883</td><td>0.171622900</td><td>  69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.075974940</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>lymphocyte activation                                             </td><td>  6</td><td> 1.694145e-87</td><td> 3.711589e-84</td><td>2.711217</td><td>507</td><td>0.098542270</td><td>  59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.032329760</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>leukocyte cell-cell adhesion                                      </td><td>  7</td><td> 1.805449e-82</td><td> 3.390375e-79</td><td>2.985228</td><td>413</td><td>0.080272110</td><td>  36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.026672050</td><td>NA</td></tr>
	<tr><td>cluster2 </td><td>positive regulation of immune system process                      </td><td>  8</td><td> 1.515236e-79</td><td> 2.489722e-76</td><td>2.029000</td><td>799</td><td>0.155296400</td><td>  98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.067084260</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>regulation of neutrophil activation                               </td><td>368</td><td> 1.656167e-15</td><td> 5.915847e-14</td><td>4.527465</td><td> 43</td><td>0.003109858</td><td>1118</td><td>1.638242e-02</td><td>2.075993</td><td>  9</td><td>   9</td><td>0.001007275</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>negative regulation of leukocyte degranulation                    </td><td>369</td><td> 1.989750e-15</td><td> 7.088147e-14</td><td>3.750587</td><td> 53</td><td>0.003833080</td><td>1381</td><td>3.949761e-02</td><td>1.887267</td><td> 10</td><td>  11</td><td>0.001119194</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>negative regulation of peptidyl-tyrosine phosphorylation          </td><td>402</td><td> 4.746925e-14</td><td> 1.552197e-12</td><td>2.163150</td><td>119</td><td>0.008606350</td><td>1421</td><td>4.232062e-02</td><td>1.413442</td><td> 32</td><td>  47</td><td>0.003581421</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>regulation of interleukin-4 production                            </td><td>410</td><td> 8.146994e-14</td><td> 2.612006e-12</td><td>2.312470</td><td>101</td><td>0.007304549</td><td>1273</td><td>2.760453e-02</td><td>1.596918</td><td> 20</td><td>  26</td><td>0.002238388</td><td>NA</td></tr>
	<tr><td>cluster3 </td><td>cardiac epithelial to mesenchymal transition                      </td><td>418</td><td> 1.542224e-13</td><td> 4.849889e-12</td><td>2.004822</td><td>137</td><td>0.009908151</td><td> 722</td><td>1.353885e-03</td><td>1.768439</td><td> 23</td><td>  27</td><td>0.002574147</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>platelet activation                                               </td><td>243</td><td> 3.008796e-35</td><td> 1.627598e-33</td><td>2.030922</td><td>373</td><td>0.027685000</td><td> 549</td><td>2.557751e-04</td><td>1.379287</td><td> 92</td><td> 139</td><td>0.010335920</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc-gamma receptor signaling pathway                               </td><td>342</td><td> 5.334162e-24</td><td> 2.050221e-22</td><td>2.196593</td><td>207</td><td>0.015364060</td><td> 712</td><td>1.830093e-03</td><td>1.453262</td><td> 53</td><td>  76</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>positive regulation of T cell differentiation                     </td><td>347</td><td> 8.557288e-24</td><td> 3.241659e-22</td><td>2.006928</td><td>254</td><td>0.018852520</td><td> 402</td><td>1.561131e-05</td><td>1.598626</td><td> 56</td><td>  73</td><td>0.006291428</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc-gamma receptor signaling pathway involved in phagocytosis      </td><td>348</td><td> 8.592601e-24</td><td> 3.245682e-22</td><td>2.197010</td><td>205</td><td>0.015215620</td><td> 610</td><td>5.398365e-04</td><td>1.505056</td><td> 52</td><td>  72</td><td>0.005842040</td><td>NA</td></tr>
	<tr><td>cluster4 </td><td>Fc receptor mediated stimulatory signaling pathway                </td><td>352</td><td> 1.769939e-23</td><td> 6.609616e-22</td><td>2.164341</td><td>209</td><td>0.015512510</td><td> 623</td><td>6.502433e-04</td><td>1.492540</td><td> 53</td><td>  74</td><td>0.005954387</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>dorsal spinal cord development                                    </td><td> 90</td><td> 2.588511e-24</td><td> 3.780664e-22</td><td>3.025152</td><td>117</td><td>0.008226113</td><td> 741</td><td>1.285583e-02</td><td>1.619457</td><td> 19</td><td>  21</td><td>0.001833446</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>spinal cord association neuron differentiation                    </td><td> 97</td><td> 6.079666e-21</td><td> 8.238888e-19</td><td>3.437898</td><td> 83</td><td>0.005835618</td><td> 983</td><td>4.641332e-02</td><td>1.662074</td><td> 13</td><td>  14</td><td>0.001254463</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>negative regulation of Notch signaling pathway                    </td><td>135</td><td> 1.560153e-15</td><td> 1.519127e-13</td><td>2.433946</td><td>104</td><td>0.007312100</td><td> 547</td><td>2.043150e-03</td><td>1.572965</td><td> 29</td><td>  33</td><td>0.002798417</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>regulation of mesenchymal cell apoptotic process                  </td><td>140</td><td> 5.356475e-15</td><td> 5.029347e-13</td><td>2.409294</td><td>102</td><td>0.007171483</td><td> 770</td><td>1.574086e-02</td><td>1.789926</td><td> 12</td><td>  12</td><td>0.001157966</td><td>NA</td></tr>
	<tr><td>cluster5 </td><td>ventral spinal cord interneuron fate commitment                   </td><td>162</td><td> 6.339008e-14</td><td> 5.143596e-12</td><td>2.406830</td><td> 94</td><td>0.006609014</td><td> 886</td><td>3.063835e-02</td><td>1.670597</td><td> 14</td><td>  15</td><td>0.001350960</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid leukocyte activation                                      </td><td> 15</td><td>1.618950e-113</td><td>1.418740e-110</td><td>2.294861</td><td>909</td><td>0.089875420</td><td>  39</td><td>7.460357e-14</td><td>1.404322</td><td>329</td><td> 560</td><td>0.042396910</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid cell activation involved in immune response               </td><td> 21</td><td>2.444107e-104</td><td>1.529895e-101</td><td>2.348170</td><td>801</td><td>0.079197150</td><td>  67</td><td>1.517078e-12</td><td>1.402204</td><td>298</td><td> 508</td><td>0.038402060</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>leukocyte degranulation                                           </td><td> 23</td><td>1.100051e-102</td><td>6.287031e-100</td><td>2.356930</td><td>783</td><td>0.077417440</td><td>  76</td><td>2.716302e-12</td><td>1.401562</td><td>292</td><td> 498</td><td>0.037628870</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>myeloid leukocyte mediated immunity                               </td><td> 25</td><td>3.227605e-100</td><td> 1.697075e-97</td><td>2.317745</td><td>790</td><td>0.078109550</td><td>  75</td><td>2.729572e-12</td><td>1.396706</td><td>298</td><td> 510</td><td>0.038402060</td><td>NA</td></tr>
	<tr><td>cluster6 </td><td>cell activation involved in immune response                       </td><td> 26</td><td>3.444435e-100</td><td> 1.741427e-97</td><td>2.133804</td><td>937</td><td>0.092643860</td><td>  88</td><td>5.977176e-12</td><td>1.356890</td><td>344</td><td> 606</td><td>0.044329900</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-regulating cell surface receptor signaling pathway</td><td> 36</td><td> 1.740206e-26</td><td> 6.354169e-24</td><td>2.166753</td><td>231</td><td>0.059200410</td><td> 343</td><td>3.187349e-03</td><td>1.413045</td><td>100</td><td> 317</td><td>0.024148760</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-activating cell surface receptor signaling pathway</td><td> 37</td><td> 3.504343e-26</td><td> 1.244989e-23</td><td>2.274283</td><td>206</td><td>0.052793440</td><td> 375</td><td>6.164949e-03</td><td>1.414532</td><td> 90</td><td> 285</td><td>0.021733880</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>immune response-activating signal transduction                    </td><td> 43</td><td> 2.064109e-25</td><td> 6.309933e-23</td><td>2.036269</td><td>255</td><td>0.065351100</td><td> 296</td><td>1.358810e-03</td><td>1.399063</td><td>119</td><td> 381</td><td>0.028737020</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>B cell receptor signaling pathway                                 </td><td> 46</td><td> 5.808631e-25</td><td> 1.659879e-22</td><td>4.353879</td><td> 75</td><td>0.019220910</td><td> 160</td><td>2.471433e-05</td><td>2.815593</td><td> 22</td><td>  35</td><td>0.005312726</td><td>NA</td></tr>
	<tr><td>cluster7 </td><td>adaptive immune response                                          </td><td> 67</td><td> 2.481028e-20</td><td> 4.867629e-18</td><td>2.166776</td><td>175</td><td>0.044848800</td><td> 558</td><td>3.213934e-02</td><td>1.358905</td><td> 81</td><td> 267</td><td>0.019560490</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>mammary gland epithelium development                              </td><td>214</td><td> 8.347727e-44</td><td> 5.127611e-42</td><td>2.048944</td><td>461</td><td>0.019466260</td><td> 711</td><td>1.869430e-03</td><td>1.496692</td><td> 42</td><td>  55</td><td>0.004437870</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>corpus callosum development                                       </td><td>298</td><td> 4.280383e-32</td><td> 1.888109e-30</td><td>3.443714</td><td>131</td><td>0.005531627</td><td>1287</td><td>4.721443e-02</td><td>1.698626</td><td> 13</td><td>  15</td><td>0.001373626</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>regulation of vascular permeability                               </td><td>408</td><td> 6.763732e-25</td><td> 2.179148e-23</td><td>2.309902</td><td>194</td><td>0.008191876</td><td> 807</td><td>3.953369e-03</td><td>1.633295</td><td> 25</td><td>  30</td><td>0.002641589</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>regulation of catenin import into nucleus                         </td><td>409</td><td> 9.730355e-25</td><td> 3.127274e-23</td><td>2.151625</td><td>225</td><td>0.009500887</td><td> 784</td><td>3.332869e-03</td><td>1.714959</td><td> 21</td><td>  24</td><td>0.002218935</td><td>NA</td></tr>
	<tr><td>cluster8 </td><td>ventral spinal cord interneuron specification                     </td><td>418</td><td> 3.553676e-24</td><td> 1.117538e-22</td><td>2.645736</td><td>145</td><td>0.006122794</td><td> 902</td><td>8.863674e-03</td><td>1.959954</td><td> 11</td><td>  11</td><td>0.001162299</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>steroid metabolic process                                         </td><td> 38</td><td> 1.328991e-42</td><td> 4.597260e-40</td><td>2.058328</td><td>438</td><td>0.036120730</td><td> 282</td><td>7.061466e-06</td><td>1.377363</td><td>141</td><td> 226</td><td>0.016781720</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>sterol metabolic process                                          </td><td> 46</td><td> 2.897808e-40</td><td> 8.280801e-38</td><td>2.422384</td><td>291</td><td>0.023998020</td><td> 850</td><td>1.936534e-02</td><td>1.300654</td><td> 76</td><td> 129</td><td>0.009045465</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>cholesterol metabolic process                                     </td><td> 50</td><td> 4.301673e-38</td><td> 1.130910e-35</td><td>2.514487</td><td>256</td><td>0.021111660</td><td> 910</td><td>2.651760e-02</td><td>1.312680</td><td> 66</td><td> 111</td><td>0.007855273</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>secondary alcohol metabolic process                               </td><td> 51</td><td> 1.322869e-37</td><td> 3.409630e-35</td><td>2.470852</td><td>261</td><td>0.021524000</td><td> 868</td><td>2.186563e-02</td><td>1.313194</td><td> 69</td><td> 116</td><td>0.008212330</td><td>NA</td></tr>
	<tr><td>cluster9 </td><td>high-density lipoprotein particle remodeling                      </td><td> 80</td><td> 1.265443e-30</td><td> 2.079281e-28</td><td>6.407355</td><td> 65</td><td>0.005360383</td><td> 921</td><td>2.866618e-02</td><td>1.818097</td><td> 14</td><td>  17</td><td>0.001666270</td><td>NA</td></tr>
</tbody>
</table>



## Plot - bargraphs


```R
dfs_top5 %>% filter(.id == "cluster2")
```


<table class="dataframe">
<caption>A data.table: 5 × 15</caption>
<thead>
	<tr><th scope=col>.id</th><th scope=col>TermName</th><th scope=col>HyperRank</th><th scope=col>HyperRawPValue</th><th scope=col>HyperFDRQVal</th><th scope=col>HyperFoldEnrichment</th><th scope=col>HyperForegroundRegionHits</th><th scope=col>HyperTotalRegions</th><th scope=col>HyperRegionSetCoverage</th><th scope=col>HyperForegroundGeneHits</th><th scope=col>TotalGenesAnnotated</th><th scope=col>X11</th><th scope=col>X12</th><th scope=col>X13</th><th scope=col>X14</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;lgl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>cluster2</td><td>leukocyte activation                        </td><td>4</td><td>1.884225e-91</td><td>6.192034e-88</td><td>2.165484</td><td>792</td><td>0.15393590</td><td>85</td><td>2.944076e-11</td><td>1.415249</td><td>327</td><td> 866</td><td>0.06607395</td><td>NA</td></tr>
	<tr><td>cluster2</td><td>cell activation                             </td><td>5</td><td>6.588506e-88</td><td>1.732118e-84</td><td>2.021410</td><td>883</td><td>0.17162290</td><td>69</td><td>3.352097e-12</td><td>1.399463</td><td>376</td><td>1007</td><td>0.07597494</td><td>NA</td></tr>
	<tr><td>cluster2</td><td>lymphocyte activation                       </td><td>6</td><td>1.694145e-87</td><td>3.711589e-84</td><td>2.711217</td><td>507</td><td>0.09854227</td><td>59</td><td>8.451907e-13</td><td>1.728198</td><td>160</td><td> 347</td><td>0.03232976</td><td>NA</td></tr>
	<tr><td>cluster2</td><td>leukocyte cell-cell adhesion                </td><td>7</td><td>1.805449e-82</td><td>3.390375e-79</td><td>2.985228</td><td>413</td><td>0.08027211</td><td>36</td><td>5.582798e-15</td><td>1.932578</td><td>132</td><td> 256</td><td>0.02667205</td><td>NA</td></tr>
	<tr><td>cluster2</td><td>positive regulation of immune system process</td><td>8</td><td>1.515236e-79</td><td>2.489722e-76</td><td>2.029000</td><td>799</td><td>0.15529640</td><td>98</td><td>1.428192e-10</td><td>1.395007</td><td>332</td><td> 892</td><td>0.06708426</td><td>NA</td></tr>
</tbody>
</table>




```R
plot_GO <- function(resfile){
    ggplot(resfile, aes(x = -log10(HyperFDRQVal), y = TermName)) +
    geom_bar(stat = "identity") +
    theme_minimal() +
    theme(aspect.ratio = 1)
}

```


```R
for (i in 2:10){
    dfs_top5 %>% filter(.id == paste0("cluster", i)) %>% plot_GO()
}
```


```R
plot_GO <- function(resfile){
    ggplot(resfile, aes(x = -log10(HyperFDRQVal), y = TermName)) +
    geom_bar(stat = "identity") +
    theme_minimal() +
    theme(aspect.ratio = 1)
}

print("Cluster 2")
plot_GO(res_cluster2)
print("Cluster 3")
plot_GO(res_cluster3)
print("Cluster 4")
plot_GO(res_cluster4)
print("Cluster 5")
plot_GO(res_cluster5)
print("Cluster 6")
plot_GO(res_cluster6)
print("Cluster 7")
plot_GO(res_cluster7)
print("Cluster 8")
plot_GO(res_cluster8)
print("Cluster 9")
plot_GO(res_cluster9)
print("Cluster 10")
plot_GO(res_cluster10)
```

    [1] "Cluster 2"
    [1] "Cluster 3"



![png](output_140_1.png)


    [1] "Cluster 4"



![png](output_140_3.png)


    [1] "Cluster 5"



![png](output_140_5.png)


    [1] "Cluster 6"



![png](output_140_7.png)


    [1] "Cluster 7"



![png](output_140_9.png)


    [1] "Cluster 8"



![png](output_140_11.png)


    [1] "Cluster 9"



![png](output_140_13.png)


    [1] "Cluster 10"



![png](output_140_15.png)



![png](output_140_16.png)



```R

p_c2 <- plot_GO(res_cluster2)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster2.pdf", p_c2)

p_c3 <- plot_GO(res_cluster3)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster3.pdf", p_c3)

p_c4 <- plot_GO(res_cluster4)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster4.pdf", p_c4)

p_c5 <- plot_GO(res_cluster5)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster5.pdf", p_c5)



```

    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    



```R


p_c6 <- plot_GO(res_cluster6)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster6.pdf", p_c6)

p_c7 <- plot_GO(res_cluster7)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster7.pdf", p_c7)

p_c8 <- plot_GO(res_cluster8)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster8.pdf", p_c8)

p_c9 <- plot_GO(res_cluster9)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster9.pdf", p_c9)

p_c10 <- plot_GO(res_cluster10)
ggsave("/data/hodges_lab/Tim/MethylationHeatmap_paper/GREAT.10ct.cluster10.pdf", p_c10)
```

    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    
    Saving 6.67 x 6.67 in image
    



```R

```


```R

```


```R

```


```R

```
