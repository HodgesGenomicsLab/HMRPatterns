# Compute cluster groups 


```R
WRK_DIR=/data/hodges_lab/Tim/ClusterTesting/
mkdir -p ${WRK_DIR}
```


```R
# RefSeq TSS/Exon file
TSSExon_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/referenceFiles/ncbiRefSeqCurated_NM.promotersUp2000Down1000AndExons.txt 
```


```R
# B cell - filtered for RefSeq TSS/Exon file 
BCL_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/Bcell.minsize50.filtforrefseqTSSexons.txt

wc -l ${BCL_FILE}
```

    34070 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/Bcell.minsize50.filtforrefseqTSSexons.txt



```R
# B cell - HMR file as downloaded
BCL_BASE_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/startingBEDs/Bcell.hmr.bed
wc -l ${BCL_BASE_FILE}
```

    54998 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/startingBEDs/Bcell.hmr.bed



```R

```

## Unclustered - current method 


```R
awk 'BEGIN{OFS=FS="\t"}{if (($3-$2)>49) print $1,$2,$3}' ${BCL_BASE_FILE} | bedtools merge -c 2 -o count -d 6000 -i - | awk 'BEGIN{FS=OFS="\t"}{if ($4<2) print}' - | awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3}' - | bedtools intersect -v -a - -b ${TSSExon_FILE} > ${WRK_DIR}Bcell_unclustered_hpl.current.txt

echo "Found unclustered HMRs."
```

    Found unclustered HMRs.


## Unclustered - RefSeq filter first (More inclusive)


```R
bedtools merge -c 2 -o count -d 6000 -i ${BCL_FILE} | awk 'BEGIN{FS=OFS="\t"}{if ($4<2) print}' - | awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3}' - > ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.txt

echo "Done."
```

    Done.


### Unclustered - RefSeq - cell specific 


```R
bedtools intersect -u -a ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.txt -b /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_all_cellspecific_hpl.txt > ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt
```


```R

```


```R

```

## Clusters of two - internal clusters 


```R
head ${TSSExon_FILE}
```

    chr1	67090	70090	NM_001005484.1
    chr1	69090	70008	NM_001005484.1
    chr1	365658	368658	NM_001005221.2
    chr1	367658	368597	NM_001005221.2
    chr1	621034	624034	NM_001005277.1
    chr1	621095	622034	NM_001005277.1
    chr1	859110	862110	NM_152486.3
    chr1	861110	861180	NM_152486.3
    chr1	861301	861393	NM_152486.3
    chr1	865534	865716	NM_152486.3



```R
head /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/referenceFiles/hg19.chrom.sizes.twoCol.sorted
```

    chr1	249250621
    chr10	135534747
    chr11	135006516
    chr12	133851895
    chr13	115169878
    chr14	107349540
    chr15	102531392
    chr16	90354753
    chr17	81195210
    chr18	78077248



```R
awk 'BEGIN{OFS=FS="\t"}{if ($1 !~ /\_/)print $1,$2,$3}' ${TSSExon_FILE} | bedtools sort -i - | bedtools complement -i - -g /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/referenceFiles/hg19.chrom.sizes.twoCol.sorted > ${WRK_DIR}Bcell_whitelist.txt
echo "Made whitelist."

```

    Made whitelist.



```R
head ${WRK_DIR}Bcell_whitelist.txt
head ${WRK_DIR}Bcell_whitelistRegions_contain2ormoreHMRs_hpl.txt
```

    chr1	0	67090
    chr1	70090	365658
    chr1	368658	621034
    chr1	624034	859110
    chr1	862110	865534
    chr1	865716	866418
    chr1	866469	871151
    chr1	871276	874419
    chr1	874509	874654
    chr1	874840	876523
    chr1	368658	621034	4
    chr1	624034	859110	13
    chr1	866469	871151	2
    chr1	919473	934343	2
    chr1	991496	1006346	6
    chr1	1011686	1017202	2
    chr1	1053469	1107259	9
    chr1	1184102	1189291	2
    chr1	1512243	1533391	2
    chr1	1537515	1548794	2



```R
head -n 15 ${WRK_DIR}Bcell_whitelistRegions_cluster_contain2ormoreHMRs_individualHMRs_temp_hpl.txt
```

    chr1	521533	521660	chr1	368658	621034	4
    chr1	564470	566009	chr1	368658	621034	4
    chr1	566458	566879	chr1	368658	621034	4
    chr1	567166	570301	chr1	368658	621034	4
    chr1	713671	715041	chr1	624034	859110	13
    chr1	724219	724516	chr1	624034	859110	13
    chr1	762003	763205	chr1	624034	859110	13
    chr1	794016	794456	chr1	624034	859110	13
    chr1	801089	801505	chr1	624034	859110	13
    chr1	804991	805500	chr1	624034	859110	13
    chr1	832618	833196	chr1	624034	859110	13
    chr1	833785	834596	chr1	624034	859110	13
    chr1	839724	841039	chr1	624034	859110	13
    chr1	842095	842689	chr1	624034	859110	13
    chr1	845310	845847	chr1	624034	859110	13



```R
head ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl.txt
```

    chr1	801089	805500	2
    chr1	867226	870886	2
    chr1	931262	933045	2
    chr1	1013125	1016103	2
    chr1	1185531	1186514	2
    chr1	1538029	1542805	2
    chr1	1609040	1610648	2
    chr1	1792416	1796593	2
    chr1	1941843	1946688	2
    chr1	1976113	1978261	2



```R
wc -l ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl_BED.txt
wc -l ${WRK_DIR}Bcell_internalClusters_contain2HMRs_individualHMRs_hpl.txt
```

    3602 /data/hodges_lab/Tim/ClusterTesting/Bcell_internalClusters_contain2HMRs_hpl_BED.txt
    7204 /data/hodges_lab/Tim/ClusterTesting/Bcell_internalClusters_contain2HMRs_individualHMRs_hpl.txt



```R
echo "Start."

awk 'BEGIN{OFS=FS="\t"}{if ($1 !~ /\_/)print $1,$2,$3}' ${TSSExon_FILE} | bedtools sort -i - | bedtools complement -i - -g /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/referenceFiles/hg19.chrom.sizes.twoCol.sorted > ${WRK_DIR}Bcell_whitelist.txt
echo "Made whitelist."


# (a) Find whitelist regions with 2+ HMRs
bedtools intersect -c -F 1.0 -a ${WRK_DIR}Bcell_whitelist.txt -b ${BCL_FILE} | awk 'BEGIN{OFS=FS="\t"}{if ($4>1) print}' - > ${WRK_DIR}Bcell_whitelistRegions_contain2ormoreHMRs_hpl.txt
echo "Found whitelist regions that contain 2+ HMRs."

# (b)Find what HMRs are in these to create a double BED file in a parsable list for custom merging: [1-3]: BED coordinates of Whitelist region [4]: #HMR in Whitelist region, [5-7]: BED coordinates of HMRs in Whitelist region
# Diagnostic: bedtools intersect -loj -F 1.0 -a Bcell_whitelistRegions_contain3ormoreHMRs.txt -b Bcell.HMR.min50.txt | awk 'BEGIN{OFS=FS="\t"}{print}' - | bedtools sort -i - | head
# awk 'BEGIN{OFS=FS="\t"}{print $5,$6,$7,$1,$2,$3,$4}' temp.txt | head

bedtools intersect -loj -F 1.0 -a ${WRK_DIR}Bcell_whitelistRegions_contain2ormoreHMRs_hpl.txt -b ${BCL_FILE} | awk 'BEGIN{OFS=FS="\t"}{print $5,$6,$7,$1,$2,$3,$4}' - | bedtools sort -i - > ${WRK_DIR}Bcell_whitelistRegions_cluster_contain2ormoreHMRs_individualHMRs_temp_hpl.txt
echo "Created double BED for whitelist regions that contain 2+ HMRs."

# (c) Custom merge within these regions
awk -v whitelistStart=1 -v hmrsCount=1 -v clusterChr=1 -v clusterStart=1 -v clusterEnd=2 'BEGIN{OFS=FS="\t";dist=6000;whitelistStart=1;hmrsCount=1;clusterChr=1;clusterStart=1;clusterEnd=2;} {
# Check if we are in the same WhitelistBoundary
if ($5!=whitelistStart) {
print clusterChr,clusterStart,clusterEnd,hmrsCount;
whitelistStart=$5;
hmrsCount=1;
clusterChr=$1;
clusterStart=$2;
clusterEnd=$3;
} else {
# case if (1) we are staying within a Whitelist boundary, but (2) the previous HMR was >6000bp away
if (($2-clusterEnd)>6000) {
print clusterChr,clusterStart,clusterEnd,hmrsCount;
clusterStart=$2;
clusterEnd=$3;
hmrsCount=1;
} else {
clusterEnd=$3;
hmrsCount+=1;
}
}
}' ${WRK_DIR}Bcell_whitelistRegions_cluster_contain2ormoreHMRs_individualHMRs_temp_hpl.txt | awk 'BEGIN{OFS=FS="\t"}{if ($4==2) print $0}' - > ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl.txt

echo "Found internalClusters containing exactly 2 HMRs."

#########################
#########################
#########################
# Remove unplaced contigs, causes issues downline 
awk 'BEGIN{OFS=FS="\t"}{if ($1 !~ /\_/)print $1,$2,$3}' ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl.txt > ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl_BED.txt
echo -e "\n"


##### ((5)) internalClusters_individualHMRs 
#####
bedtools intersect -u -a ${BCL_FILE} -b ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl_BED.txt > ${WRK_DIR}Bcell_internalClusters_contain2HMRs_individualHMRs_hpl.txt
echo "Found the HMRs composing internalClusters containing exactly 2 HMRs."



```

    Start.
    Made whitelist.
    Found whitelist regions that contain 2+ HMRs.
    Created double BED for whitelist regions that contain 2+ HMRs.
    Found internalClusters containing exactly 2 HMRs.
    
    
    Found the HMRs composing internalClusters containing 3+ HMRs.


## Clusters of three - internal clusters


```R
echo "Starting."

awk 'BEGIN{OFS=FS="\t"}{if ($1 !~ /\_/)print $1,$2,$3}' ${TSSExon_FILE} | bedtools sort -i - | bedtools complement -i - -g /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/referenceFiles/hg19.chrom.sizes.twoCol.sorted > ${WRK_DIR}Bcell_whitelist.txt
echo "Made whitelist."


# (a) Find whitelist regions with 3+ HMRs
bedtools intersect -c -F 1.0 -a ${WRK_DIR}Bcell_whitelist.txt -b ${BCL_FILE} | awk 'BEGIN{OFS=FS="\t"}{if ($4>2) print}' - > ${WRK_DIR}Bcell_whitelistRegions_contain3ormoreHMRs_hpl.txt
echo "Found whitelist regions that contain 3+ HMRs."


bedtools intersect -loj -F 1.0 -a ${WRK_DIR}Bcell_whitelistRegions_contain3ormoreHMRs_hpl.txt -b ${BCL_FILE} | awk 'BEGIN{OFS=FS="\t"}{print $5,$6,$7,$1,$2,$3,$4}' - | bedtools sort -i - > ${WRK_DIR}Bcell_whitelistRegions_cluster_individualHMRs_temp_hpl.txt

echo "Created double BED for whitelist regions that contain 3+ HMRs."

# (c) Custom merge within these regions
awk -v whitelistStart=1 -v hmrsCount=1 -v clusterChr=1 -v clusterStart=1 -v clusterEnd=2 'BEGIN{OFS=FS="\t";dist=6000;whitelistStart=1;hmrsCount=1;clusterChr=1;clusterStart=1;clusterEnd=2;} {
# Check if we are in the same WhitelistBoundary
if ($5!=whitelistStart) {
print clusterChr,clusterStart,clusterEnd,hmrsCount;
whitelistStart=$5;
hmrsCount=1;
clusterChr=$1;
clusterStart=$2;
clusterEnd=$3;
} else {
# case if (1) we are staying within a Whitelist boundary, but (2) the previous HMR was >6000bp away
if (($2-clusterEnd)>6000) {
print clusterChr,clusterStart,clusterEnd,hmrsCount;
clusterStart=$2;
clusterEnd=$3;
hmrsCount=1;
} else {
clusterEnd=$3;
hmrsCount+=1;
}
}
}' ${WRK_DIR}Bcell_whitelistRegions_cluster_individualHMRs_temp_hpl.txt | awk 'BEGIN{OFS=FS="\t"}{if ($4>2) print $0}' - > ${WRK_DIR}Bcell_internalClusters_hpl.txt
echo "Found internalClusters containing 3+ HMRs."

#########################
#########################
#########################
# Remove unplaced contigs, causes issues downline 
awk 'BEGIN{OFS=FS="\t"}{if ($1 !~ /\_/)print $1,$2,$3}' ${WRK_DIR}Bcell_internalClusters_hpl.txt > ${WRK_DIR}Bcell_internalClusters_hpl_BED.txt
echo -e "\n"


##### ((5)) internalClusters_individualHMRs 
#####
bedtools intersect -u -a ${BCL_FILE} -b ${WRK_DIR}Bcell_internalClusters_hpl_BED.txt > ${WRK_DIR}Bcell_internalClusters_individualHMRs_hpl.txt
echo "Found the HMRs composing internalClusters containing 3+ HMRs."



```

    Starting.
    Made whitelist.
    Found whitelist regions that contain 3+ HMRs.
    Created double BED for whitelist regions that contain 3+ HMRs.
    Found internalClusters containing 3+ HMRs.
    
    
    Found the HMRs composing internalClusters containing 3+ HMRs.



```R
 bedtools merge -c 2 -o count -d 6000 -i ${BCL_FILE} | awk 'BEGIN{FS=OFS="\t"}{if ($4==2) print}' - | wc -l
```

    3734



```R
wc -l ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl.txt
```

    3602 /data/hodges_lab/Tim/ClusterTesting/Bcell_internalClusters_contain2HMRs_hpl.txt



```R
wc -l ${WRK_DIR}Bcell_internalClusters_contain2HMRs_individualHMRs_hpl.txt
wc -l ${WRK_DIR}Bcell_internalClusters_individualHMRs_hpl.txt

```

    7204 /data/hodges_lab/Tim/ClusterTesting/Bcell_internalClusters_contain2HMRs_individualHMRs_hpl.txt
    5974 /data/hodges_lab/Tim/ClusterTesting/Bcell_internalClusters_individualHMRs_hpl.txt


# Get 2-HMR clusters that contain a cell specific 


```R
${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl_BED.txt 
```


```R
bedtools intersect -u -a ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl_BED.txt -b /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_all_cellspecific_hpl.txt > ${WRK_DIR}Bcell_internalClusters_contain2HMRs_hpl.containsCS.txt
```


```R
echo "Done."
```

    Done.


# nnRNA

# Get 2NN


```R
HOME_DIR=/data/hodges_lab/Tim/nnRNA_TPM_EHGM/
mkdir -p ${HOME_DIR}
REF_DIR=${HOME_DIR}reference_files/

# Directory 
mkdir -p ${HOME_DIR}intermediate_files
cd ${HOME_DIR}intermediate_files

INTER_DIR=${HOME_DIR}intermediate_files/
REF_DIR=${HOME_DIR}reference_files/
OUT_DIR=${HOME_DIR}output_files/

echo "Done."
```

    Done.



```R
# Bcell 
bedtools sort -i ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{print }' - > ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt

echo "Done."
```

    Done.



```R
# Initalize HMR files 
CLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt
UNCLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_cellspecific_hpl.txt
UNCLUSTERED_CS_ALL_FILE=/data/hodges_lab/Tim/ClusterTesting/Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt
echo "Done."
```

    Done.



```R
wc -l $CLUSTERED_CS_FILE
wc -l $UNCLUSTERED_CS_FILE
wc -l $UNCLUSTERED_CS_ALL_FILE
```

    756 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt
    1844 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_cellspecific_hpl.txt
    2270 /data/hodges_lab/Tim/ClusterTesting/Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt



```R
# Initalize HMR files 
CLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt
UNCLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_cellspecific_hpl.txt
UNCLUSTERED_CS_ALL_FILE=/data/hodges_lab/Tim/ClusterTesting/Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt

awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_ClusteredCS"}' ${CLUSTERED_CS_FILE} | bedtools sort -i - > ${INTER_DIR}Bcell.clustered_cs.tmp_sorted.txt
awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_UnclusteredCS"}' ${UNCLUSTERED_CS_FILE} | bedtools sort -i - > ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt
awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_UnclusteredLooseCS"}' ${UNCLUSTERED_CS_ALL_FILE} | bedtools sort -i - > ${INTER_DIR}Bcell.unclustered_loose_cs.tmp_sorted.txt

echo "Done."
```

    Done.



```R
# Clusters contain cell specific 
```


```R
## How many clusters are represented by the individual clustered cell specific HMRs
bedtools intersect -u -a /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_hpl.txt -b /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt > ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt

wc -l ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt

awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_ClusteredCS"}' ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt | bedtools sort -i - > ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt
```

    484 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_internalClusters_hpl.containsCellSpecificHMR.txt



```R
# Clusters contain cell specific - closest 2NN genes
```


```R
bedtools closest -d -k 2 -a ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.



```R
# bedtools closest -d -k 2 -a ${INTER_DIR}Bcell.clustered_cs.tmp_sorted.txt -b ${REF_DIR}GM_ENSGGENESYMBOL_minTPM0.sorted.txt > ${INTER_DIR}Bcell_clustered_cellspecific.2NN.GM_ENSGGENESYMBOL_minTPM0.txt

bedtools closest -d -k 2 -a ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.



```R
# bedtools closest -d -k 2 -a ${INTER_DIR}Bcell.clustered_cs.tmp_sorted.txt -b ${REF_DIR}GM_ENSGGENESYMBOL_minTPM0.sorted.txt > ${INTER_DIR}Bcell_clustered_cellspecific.2NN.GM_ENSGGENESYMBOL_minTPM0.txt

bedtools closest -d -k 2 -a ${INTER_DIR}Bcell.unclustered_loose_cs.tmp_sorted.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.



```R

```


```R

```


```R

```


```R
wc -l ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt
wc -l ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt
wc -l ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt
```

    970 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt
    3678 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt
    4533 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt



```R
wc -l Bcell_clusters_containscellspecific.2NN.GM_ENSGGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
```

    968 Bcell_clusters_containscellspecific.2NN.GM_ENSGGENESYMBOL_minTPM0.ContinuousBEDFormat.txt


# TAD Filter


```R
# Intersect 2NN file with TADs

# First, create an HMR-Gene end-to-end BED file:
#"ChrHMRProm","StartHMRProm","EndHMRProm","ChrHMR","StartHMR","EndHMR","ChrProm","StartProm","EndProm","ENSEMBL","TPM","HMRPromDist","HMRGroup"

# Check if HMR is before the TSS, else, TSS before  
awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt 

awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt


awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt

echo "Made continuous BED file."

```

    Made continuous BED file.



```R
bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt

bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt  \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt

bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt  \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt


echo "Done."
```

    Done.



```R
wc -l ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
wc -l ${INTER_DIR}Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt
wc -l ${INTER_DIR}Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt
wc -l ${INTER_DIR}Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt
```

    970 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
    760 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt
    2492 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt
    3227 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt


# Remove gene reps 


```R
library(tidyverse)
library(ggplot2)
library(ggpubr)

#Set working directory 
setwd("/data/hodges_lab/Tim/nnRNA_TPM_EHGM/output_files/")

print("Loaded libraries.")
```

    [1] "Loaded libraries."



```R
Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist")) 


Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist"))

Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist"))
```

    [1mRows: [22m[34m760[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m2492[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m3227[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.


Remove rep call 


```R
Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM <- Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% dplyr::select(ENSEMBL, TPM, HMRTSSDist) %>% dplyr::distinct(ENSEMBL, TPM, .keep_all = TRUE) %>% mutate(HMRGroup = "Bcell_clustered") %>% arrange(ENSEMBL)

Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM <- Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% dplyr::select(ENSEMBL, TPM, HMRTSSDist) %>% dplyr::distinct(ENSEMBL, TPM, .keep_all = TRUE) %>% mutate(HMRGroup = "Bcell_unclustered") %>% arrange(ENSEMBL)

Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM <- Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% dplyr::select(ENSEMBL, TPM, HMRTSSDist) %>% dplyr::distinct(ENSEMBL, TPM, .keep_all = TRUE) %>% mutate(HMRGroup = "Bcell_unclustered") %>% arrange(ENSEMBL)

nrow(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM)
head(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM, 3)
nrow(Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM)
head(Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM, 3)
nrow(Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM)
head(Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM, 3)
```


670



<table class="dataframe">
<caption>A tibble: 3 × 4</caption>
<thead>
	<tr><th scope=col>ENSEMBL</th><th scope=col>TPM</th><th scope=col>HMRTSSDist</th><th scope=col>HMRGroup</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ENSG00000002822</td><td>21.650</td><td>304807</td><td>Bcell_clustered</td></tr>
	<tr><td>ENSG00000004848</td><td> 0.005</td><td>  9410</td><td>Bcell_clustered</td></tr>
	<tr><td>ENSG00000006116</td><td> 0.010</td><td>234975</td><td>Bcell_clustered</td></tr>
</tbody>
</table>




2068



<table class="dataframe">
<caption>A tibble: 3 × 4</caption>
<thead>
	<tr><th scope=col>ENSEMBL</th><th scope=col>TPM</th><th scope=col>HMRTSSDist</th><th scope=col>HMRGroup</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ENSG00000000460</td><td> 8.440</td><td>18308</td><td>Bcell_unclustered</td></tr>
	<tr><td>ENSG00000002549</td><td>51.545</td><td>15615</td><td>Bcell_unclustered</td></tr>
	<tr><td>ENSG00000002587</td><td> 0.185</td><td>40332</td><td>Bcell_unclustered</td></tr>
</tbody>
</table>




2639



<table class="dataframe">
<caption>A tibble: 3 × 4</caption>
<thead>
	<tr><th scope=col>ENSEMBL</th><th scope=col>TPM</th><th scope=col>HMRTSSDist</th><th scope=col>HMRGroup</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>ENSG00000000460</td><td> 8.440</td><td>18308</td><td>Bcell_unclustered</td></tr>
	<tr><td>ENSG00000002549</td><td>51.545</td><td>15615</td><td>Bcell_unclustered</td></tr>
	<tr><td>ENSG00000002587</td><td> 0.185</td><td>40332</td><td>Bcell_unclustered</td></tr>
</tbody>
</table>



# STATS


```R
wilcox.test(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM, Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM)
```


    
    	Wilcoxon rank sum test with continuity correction
    
    data:  Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM and Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM
    W = 923002, p-value = 0.07788
    alternative hypothesis: true location shift is not equal to 0




```R
wilcox.test(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM, Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM)
```


    
    	Wilcoxon rank sum test with continuity correction
    
    data:  Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM and Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM
    W = 740714, p-value = 0.007028
    alternative hypothesis: true location shift is not equal to 0




```R
wilcox.test(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM, Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM)
```


    
    	Wilcoxon rank sum test with continuity correction
    
    data:  Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM and Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM
    W = 740714, p-value = 0.007028
    alternative hypothesis: true location shift is not equal to 0




```R
wilcox.test(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM, Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM)
```


    
    	Wilcoxon rank sum test with continuity correction
    
    data:  Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM and Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM
    W = 923002, p-value = 0.07788
    alternative hypothesis: true location shift is not equal to 0




```R
wilcox.test(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM, Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM)
```


    
    	Wilcoxon rank sum test with continuity correction
    
    data:  Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM and Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM$TPM
    W = 740714, p-value = 0.007028
    alternative hypothesis: true location shift is not equal to 0




```R
Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin %>% 
  group_by(HMRGroup) %>% 
  summarise(n = n())

Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin %>% 
  group_by(HMRGroup, distBin) %>% 
  summarise(n = n())

```


    Error in group_by(., HMRGroup): object 'Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin' not found
    Traceback:


    1. Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin %>% 
     .     group_by(HMRGroup) %>% summarise(n = n())

    2. summarise(., n = n())

    3. group_by(., HMRGroup)


# Plot


```R
Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM <- 
rbind(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM, Bcell_unclustered_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM)


Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM <- 
rbind(Bcell_clusters_containsCS.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM, Bcell_unclustered_loose_cellspecific.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM)
```


```R
Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin <- Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM %>% 
  mutate(distBin = case_when(
    HMRTSSDist < 10000 ~ "0-10",
    HMRTSSDist >= 10000 & HMRTSSDist < 20000 ~ "10-20",
    HMRTSSDist >= 20000 & HMRTSSDist < 30000 ~ "20-30",
    HMRTSSDist >= 30000 & HMRTSSDist < 40000 ~ "30-40",
    HMRTSSDist >= 40000 & HMRTSSDist < 50000 ~ "40-50",
    HMRTSSDist >= 50000 & HMRTSSDist < 100000 ~ "50-100",
    HMRTSSDist >= 100000 ~ ">100"
  ))

print("Done.")

Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin <- Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM %>% 
  mutate(distBin = case_when(
    HMRTSSDist < 10000 ~ "0-10",
    HMRTSSDist >= 10000 & HMRTSSDist < 20000 ~ "10-20",
    HMRTSSDist >= 20000 & HMRTSSDist < 30000 ~ "20-30",
    HMRTSSDist >= 30000 & HMRTSSDist < 40000 ~ "30-40",
    HMRTSSDist >= 40000 & HMRTSSDist < 50000 ~ "40-50",
    HMRTSSDist >= 50000 & HMRTSSDist < 100000 ~ "50-100",
    HMRTSSDist >= 100000 ~ ">100"
  ))

print("Done.")
```

    [1] "Done."
    [1] "Done."



```R
Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin$distBin <- factor(Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin$distBin, levels = c("0-10", "10-20", "20-30", "30-40", "40-50", "50-100", ">100"))

print("Done.")

Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin$distBin <- factor(Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin$distBin, levels = c("0-10", "10-20", "20-30", "30-40", "40-50", "50-100", ">100"))

print("Done.")
```

    [1] "Done."
    [1] "Done."



```R
ggplot(Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin, aes(x=HMRGroup, y=log10(TPM))) +
  geom_boxplot(aes(fill=HMRGroup)) +
  theme_classic() +
  ggtitle("ENSGnoVersion_withGENESYMBOL Bcell - All") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  xlab("HMR to Gene Distance") +
  ylab("log10(TPM)") +
  stat_compare_means(aes(group=HMRGroup), 
                     method="wilcox.test",  
                     method.args = list(alternative = "two.sided"),
                     label="p",
                     label.y=6.25)

ggplot(Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin, aes(x=HMRGroup, y=log10(TPM))) +
  geom_boxplot(aes(fill=HMRGroup)) +
  theme_classic() +
  ggtitle("ENSGnoVersion_withGENESYMBOL Bcell - All") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  xlab("HMR to Gene Distance") +
  ylab("log10(TPM)") +
  stat_compare_means(aes(group=HMRGroup), 
                     method="wilcox.test",  
                     method.args = list(alternative = "two.sided"),
                     label="p",
                     label.y=6.25)
```


![png](output_70_0.png)



![png](output_70_1.png)



```R
pdf("/data/hodges_lab/Tim/nnRNA.Clustered_vs_UnclusteredLoose.pdf")

ggplot(Bcell_clustersContainsCS_UnclusteredLoose.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin, aes(x=HMRGroup, y=log10(TPM))) +
  geom_boxplot(aes(fill=HMRGroup)) +
  theme_classic() +
  ggtitle("ENSGnoVersion_withGENESYMBOL Bcell - All") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  xlab("HMR to Gene Distance") +
  ylab("log10(TPM)") +
  stat_compare_means(aes(group=HMRGroup), 
                     method="wilcox.test",  
                     method.args = list(alternative = "two.sided"),
                     label="p",
                     label.y=6.25)

dev.off()
```


<strong>png:</strong> 2



```R
ggplot(Bcell_clustersContainsCS_Unclustered.2NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.uniqueENSGTSS_TPM.distBin, aes(x=distBin, y=log10(TPM))) +
  geom_boxplot(aes(fill=HMRGroup), width = .5, position=position_dodge(.75)) +
  theme_classic() +
  ggtitle("ENSGnoVersion_withGENESYMBOL B cell - Binned by Distance") +
  theme(plot.title = element_text(hjust = 0.5, face = "bold")) +
  xlab("HMR to Gene Distance") +
  ylab("log10(TPM)") +
  stat_compare_means(aes(group=HMRGroup), 
                     method="wilcox.test",  
                     method.args = list(alternative = "two.sided"),
                     label="p",
                     label.y=6.25,
                    size = 2.5) +
  theme(aspect.ratio = .6)
```


![png](output_72_0.png)



```R

```


```R

```

# Plot fraction HMRs - 1 NN

## Find 100NN


```R
HOME_DIR=/data/hodges_lab/Tim/nnRNA_TPM_EHGM/
mkdir -p ${HOME_DIR}
REF_DIR=${HOME_DIR}reference_files/

# Directory 
mkdir -p ${HOME_DIR}intermediate_files
cd ${HOME_DIR}intermediate_files

INTER_DIR=${HOME_DIR}intermediate_files/
REF_DIR=${HOME_DIR}reference_files/
OUT_DIR=${HOME_DIR}output_files/

echo "Done."
```

    Done.



```R
# Bcell 
bedtools sort -i ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{print }' - > ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt

echo "Done."
```

    Done.



```R

```

## Continue - CL - UN - UN_LOOSE


```R
WRK_DIR=/data/hodges_lab/Tim/ClusterTesting/
```


```R
bedtools intersect -u -a ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.txt -b /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_all_cellspecific_hpl.txt > ${WRK_DIR}Bcell_unclustered_loose_hpl.cellspecific.txt 
```


```R
# Initalize HMR files 
CLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt
UNCLUSTERED_CS_FILE=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_cellspecific_hpl.txt
UNCLUSTERED_LOOSE_CS_FILE=${WRK_DIR}Bcell_unclustered_loose_hpl.cellspecific.txt 

awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_ClusteredCS"}' ${CLUSTERED_CS_FILE} | bedtools sort -i - > ${INTER_DIR}Bcell.clustered_cs.tmp_sorted.txt
awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_UnclusteredCS"}' ${UNCLUSTERED_CS_FILE} | bedtools sort -i - > ${INTER_DIR}Bcell.unclustered_cs,.tmp_sorted.txt
awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_UnclusteredCS"}' ${UNCLUSTERED_LOOSE_CS_FILE} | bedtools sort -i - > ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt

echo "Done."

## How many clusters are represented by the individual clustered cell specific HMRs
bedtools intersect -u -a /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_hpl.txt -b /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_cellspecific_hpl.txt > ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt

wc -l ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt

awk 'BEGIN{OFS=FS="\t"}{print $1,$2,$3,"Bcell_ClusteredCS"}' ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.txt | bedtools sort -i - > ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt

echo "Done."
```

    Done.
    484 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_internalClusters_hpl.containsCellSpecificHMR.txt
    Done.



```R
bedtools closest -d -k 100 -a ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.



```R
bedtools closest -d -k 100 -a ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.



```R
bedtools closest -d -k 100 -a ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt -b ${REF_DIR}GM_ENSG_TPM_avg12_noVersion_hasHGNC_minTPM0.sorted.txt > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt

echo "Done."
```

    Done.


## Find denominators


```R
wc -l ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt
wc -l ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt
wc -l ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt
```

    484 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt
    1844 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell.unclustered_cs.tmp_sorted.txt
    2270 /data/hodges_lab/Tim/ClusterTesting/Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt



```R
awk 'BEGIN{OFS=FS="\t"}{if ($1=="chrY") print}' ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt | wc -l 

awk 'BEGIN{OFS=FS="\t"}{if ($1!="chrY") print}' ${INTER_DIR}Bcell_internalClusters_hpl.containsCellSpecificHMR.tmp_sorted.txt | wc -l 
```

    40
    444



```R
awk 'BEGIN{OFS=FS="\t"}{if ($1=="chrY") print}' ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt | wc -l 

awk 'BEGIN{OFS=FS="\t"}{if ($1!="chrY") print}' ${INTER_DIR}Bcell.unclustered_cs.tmp_sorted.txt | wc -l 
```

    223
    1621



```R
awk 'BEGIN{OFS=FS="\t"}{if ($1=="chrY") print}' ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt | wc -l 

awk 'BEGIN{OFS=FS="\t"}{if ($1!="chrY") print}' ${WRK_DIR}Bcell_unclustered_hpl.RefSeqFilterFirst.cellspecific.txt | wc -l 
```

    230
    2040


## TAD Filter


```R
# Intersect 2NN file with TADs

# First, create an HMR-Gene end-to-end BED file:
#"ChrHMRProm","StartHMRProm","EndHMRProm","ChrHMR","StartHMR","EndHMR","ChrProm","StartProm","EndProm","ENSEMBL","TPM","HMRPromDist","HMRGroup"

# Check if HMR is before the TSS, else, TSS before  
awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > b

awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt

#################### NEED TO EDIT
awk 'BEGIN{OFS=FS="\t"}{if ($2<$6)
print $1,$2,$7,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
else print $1,$6,$3,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12;
}' ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.txt | awk 'BEGIN{OFS=FS="\t"}{if ($2!~/-1/) print}' - > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt




echo "Made continuous BED file."

```

    Made continuous BED file.



```R
wc -l ${INTER_DIR}Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt 
wc -l ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
wc -l ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
```

    45165 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
    165145 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt
    207180 /data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt



```R
bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt

echo "Done."


bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt  \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt

echo "Done."


bedtools intersect -f 1.0 -a ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.ContinuousBEDFormat.txt  \
-b ${REF_DIR}GM12878_Lieberman-raw_TADs.txt > ${INTER_DIR}Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt

echo "Done."
```

    Done.
    Done.
    Done.


## Filter down to 1NN per HMR


```R
library(tidyverse)
library(ggplot2)
library(ggpubr)

#Set working directory 
setwd("/data/hodges_lab/Tim/nnRNA_TPM_EHGM/output_files/")

print("Loaded libraries.")
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    


    [1] "Loaded libraries."



```R
Bcell_clusters_containsCS <- read_tsv("/data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names = c("chr","start","end","numHMRs"))

Bcell_unclustered_CS <- 
read_tsv("/data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt",  col_names = c("chr","start","end"))

Bcell_unclustered_loose_CS <- 
read_tsv("/data/hodges_lab/Tim/nnRNA_TPM_EHGM/intermediate_files/Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt",  col_names = c("chr","start","end"))
```

    [1mRows: [22m[34m4210[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): chr, numHMRs, X7, X8, X13, X14
    [32mdbl[39m (9): start, end, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m11105[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): chr, X4, X7, X8, X13, X14
    [32mdbl[39m (9): start, end, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m15496[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): chr, X4, X7, X8, X13, X14
    [32mdbl[39m (9): start, end, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R

```


```R
Bcell_clusters_containsCS %>% filter(chr!="chrY") %>% nrow()
```


4210



```R
Bcell_unclustered_CS %>% filter(chr!="chrY") %>% nrow()
```


11105



```R
Bcell_unclustered_loose_CS %>% filter(chr!="chrY") %>% nrow()
```


15496



```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist")) 


Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist"))

Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered <- read_tsv("../intermediate_files/Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.txt", col_names=F) %>% magrittr::set_colnames(c("ChrHMRTSS","StartHMRTSS","EndHMRTSS","ChrHMR","StartHMR","EndHMR","HMRGroup","ChrTSS","StartTSS","EndTSS","TPM","strand","GENE_SYMBOL","ENSEMBL","HMRTSSDist"))
```

    [1mRows: [22m[34m4210[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m11105[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m15496[39m [1mColumns: [22m[34m15[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (6): X1, X4, X7, X8, X13, X14
    [32mdbl[39m (9): X2, X3, X5, X6, X9, X10, X11, X12, X15
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
#### Proportion of Clusters(w/ CS) (out of 444 - no chrY) - TAD FILTER
```


```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% 
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL) %>%  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
nrow()
```


424



```R
#### Proportion of Clusters(w/ CS) (out of 444 - no chrY) -  TAD FILTER
```


```R
Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>%
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL) %>%  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
nrow()
```


1480



```R
Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>%
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL) %>%  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
nrow()
```


1870



```R

```


```R

```


```R

```


```R

```


```R

```


```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% nrow()
```


4210



```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% group_by(ChrHMR, StartHMR) %>% top_n(n = 1, wt = -HMRTSSDist) %>% nrow()
```


426



```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% group_by(ChrHMR, StartHMR) %>% top_n(n = 1, wt = -HMRTSSDist) %>% top_n(n = 1, wt = TPM) %>% top_n(n = 1, wt = GENE_SYMBOL) %>% nrow()
```


424



```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% group_by(ChrHMR, StartHMR) %>% top_n(n = 1, wt = -HMRTSSDist) %>% top_n(n = 1, wt = TPM) %>% top_n(n = 1, wt = GENE_SYMBOL) %>% nrow()
```


424



```R
Bcell_clusters_containsCS %>% filter(chr!="chrY") %>% nrow()
Bcell_clusters_containsCS_noY <- Bcell_clusters_containsCS %>% filter(chr!="chrY")
Bcell_clusters_containsCS_noY %>% nrow()
```


444



444



```R

```


```R

```

### Filter down 


```R
Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN
```


<table class="dataframe">
<caption>A grouped_df: 1870 × 15</caption>
<thead>
	<tr><th scope=col>ChrHMRTSS</th><th scope=col>StartHMRTSS</th><th scope=col>EndHMRTSS</th><th scope=col>ChrHMR</th><th scope=col>StartHMR</th><th scope=col>EndHMR</th><th scope=col>HMRGroup</th><th scope=col>ChrTSS</th><th scope=col>StartTSS</th><th scope=col>EndTSS</th><th scope=col>TPM</th><th scope=col>strand</th><th scope=col>GENE_SYMBOL</th><th scope=col>ENSEMBL</th><th scope=col>HMRTSSDist</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 1385069</td><td> 1394334</td><td>chr1</td><td> 1394021</td><td> 1394334</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 1385069</td><td> 1385070</td><td>   0.525</td><td> 1</td><td>ATAD3C  </td><td>ENSG00000215915</td><td>  8952</td></tr>
	<tr><td>chr1</td><td> 1981909</td><td> 2032210</td><td>chr1</td><td> 2032031</td><td> 2032210</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 1981909</td><td> 1981910</td><td>   0.575</td><td> 1</td><td>PRKCZ   </td><td>ENSG00000067606</td><td> 50122</td></tr>
	<tr><td>chr1</td><td> 2263385</td><td> 2323147</td><td>chr1</td><td> 2263385</td><td> 2263443</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 2323146</td><td> 2323147</td><td>   2.535</td><td>-1</td><td>MORN1   </td><td>ENSG00000116151</td><td> 59704</td></tr>
	<tr><td>chr1</td><td> 3569325</td><td> 3573852</td><td>chr1</td><td> 3573086</td><td> 3573852</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 3569325</td><td> 3569326</td><td>  15.720</td><td>-1</td><td>WRAP73  </td><td>ENSG00000116213</td><td>  3761</td></tr>
	<tr><td>chr1</td><td> 6052533</td><td> 6073327</td><td>chr1</td><td> 6073217</td><td> 6073327</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 6052533</td><td> 6052534</td><td>   3.605</td><td>-1</td><td>NPHP4   </td><td>ENSG00000131697</td><td> 20684</td></tr>
	<tr><td>chr1</td><td> 6659636</td><td> 6673746</td><td>chr1</td><td> 6659636</td><td> 6660325</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 6673745</td><td> 6673746</td><td>   5.935</td><td> 1</td><td>PHF13   </td><td>ENSG00000116273</td><td> 13421</td></tr>
	<tr><td>chr1</td><td>12079523</td><td>12101107</td><td>chr1</td><td>12100074</td><td>12101107</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>12079523</td><td>12079524</td><td>  21.715</td><td> 1</td><td>MIIP    </td><td>ENSG00000116691</td><td> 20551</td></tr>
	<tr><td>chr1</td><td>12227060</td><td>12258322</td><td>chr1</td><td>12258053</td><td>12258322</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>12227060</td><td>12227061</td><td>  31.810</td><td> 1</td><td>TNFRSF1B</td><td>ENSG00000028137</td><td> 30993</td></tr>
	<tr><td>chr1</td><td>14925200</td><td>15040438</td><td>chr1</td><td>15040254</td><td>15040438</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>14925200</td><td>14925201</td><td>   1.670</td><td> 1</td><td>KAZN    </td><td>ENSG00000189337</td><td>115054</td></tr>
	<tr><td>chr1</td><td>18404348</td><td>18434241</td><td>chr1</td><td>18404348</td><td>18404580</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>18434240</td><td>18434241</td><td>   0.045</td><td> 1</td><td>IGSF21  </td><td>ENSG00000117154</td><td> 29661</td></tr>
	<tr><td>chr1</td><td>19186176</td><td>19195881</td><td>chr1</td><td>19195721</td><td>19195881</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>19186176</td><td>19186177</td><td>   0.005</td><td>-1</td><td>TAS1R2  </td><td>ENSG00000179002</td><td>  9545</td></tr>
	<tr><td>chr1</td><td>22087677</td><td>22110100</td><td>chr1</td><td>22087677</td><td>22089082</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22110099</td><td>22110100</td><td>  37.530</td><td>-1</td><td>USP48   </td><td>ENSG00000090686</td><td> 21018</td></tr>
	<tr><td>chr1</td><td>22106294</td><td>22110100</td><td>chr1</td><td>22106294</td><td>22106773</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22110099</td><td>22110100</td><td>  37.530</td><td>-1</td><td>USP48   </td><td>ENSG00000090686</td><td>  3327</td></tr>
	<tr><td>chr1</td><td>22470462</td><td>22482011</td><td>chr1</td><td>22481946</td><td>22482011</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22470462</td><td>22470463</td><td>   0.040</td><td>-1</td><td>WNT4    </td><td>ENSG00000162552</td><td> 11484</td></tr>
	<tr><td>chr1</td><td>24514449</td><td>24553751</td><td>chr1</td><td>24553383</td><td>24553751</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>24514449</td><td>24514450</td><td>   1.720</td><td>-1</td><td>IFNLR1  </td><td>ENSG00000185436</td><td> 38934</td></tr>
	<tr><td>chr1</td><td>24860964</td><td>24882603</td><td>chr1</td><td>24860964</td><td>24861150</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>24882602</td><td>24882603</td><td>   0.005</td><td> 1</td><td>NCMAP   </td><td>ENSG00000184454</td><td> 21453</td></tr>
	<tr><td>chr1</td><td>25242448</td><td>25291613</td><td>chr1</td><td>25242448</td><td>25242570</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25291612</td><td>25291613</td><td>  57.410</td><td>-1</td><td>RUNX3   </td><td>ENSG00000020633</td><td> 49043</td></tr>
	<tr><td>chr1</td><td>25291612</td><td>25373247</td><td>chr1</td><td>25372734</td><td>25373247</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25291612</td><td>25291613</td><td>  57.410</td><td>-1</td><td>RUNX3   </td><td>ENSG00000020633</td><td> 81122</td></tr>
	<tr><td>chr1</td><td>25943959</td><td>25956163</td><td>chr1</td><td>25955620</td><td>25956163</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25943959</td><td>25943960</td><td>   0.075</td><td> 1</td><td>MAN1C1  </td><td>ENSG00000117643</td><td> 11661</td></tr>
	<tr><td>chr1</td><td>26126667</td><td>26131354</td><td>chr1</td><td>26131133</td><td>26131354</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>26126667</td><td>26126668</td><td>   1.770</td><td> 1</td><td>SEPN1   </td><td>ENSG00000162430</td><td>  4466</td></tr>
	<tr><td>chr1</td><td>27433141</td><td>27493473</td><td>chr1</td><td>27433141</td><td>27433285</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27493472</td><td>27493473</td><td>   7.615</td><td>-1</td><td>SLC9A1  </td><td>ENSG00000090020</td><td> 60188</td></tr>
	<tr><td>chr1</td><td>27693383</td><td>27696751</td><td>chr1</td><td>27696156</td><td>27696751</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27693383</td><td>27693384</td><td>   0.795</td><td>-1</td><td>MAP3K6  </td><td>ENSG00000142733</td><td>  2773</td></tr>
	<tr><td>chr1</td><td>27768425</td><td>27816670</td><td>chr1</td><td>27768425</td><td>27769315</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27816669</td><td>27816670</td><td>  42.775</td><td>-1</td><td>WASF2   </td><td>ENSG00000158195</td><td> 47355</td></tr>
	<tr><td>chr1</td><td>27809797</td><td>27816670</td><td>chr1</td><td>27809797</td><td>27810107</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27816669</td><td>27816670</td><td>  42.775</td><td>-1</td><td>WASF2   </td><td>ENSG00000158195</td><td>  6563</td></tr>
	<tr><td>chr1</td><td>28199055</td><td>28217318</td><td>chr1</td><td>28216907</td><td>28217318</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>28199055</td><td>28199056</td><td>  20.935</td><td> 1</td><td>THEMIS2 </td><td>ENSG00000130775</td><td> 17852</td></tr>
	<tr><td>chr1</td><td>28835071</td><td>28838132</td><td>chr1</td><td>28837950</td><td>28838132</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>28835071</td><td>28835072</td><td>3464.135</td><td> 1</td><td>SNORA73B</td><td>ENSG00000200087</td><td>  2879</td></tr>
	<tr><td>chr1</td><td>32479430</td><td>32487531</td><td>chr1</td><td>32486412</td><td>32487531</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32479430</td><td>32479431</td><td>  76.815</td><td> 1</td><td>KHDRBS1 </td><td>ENSG00000121774</td><td>  6982</td></tr>
	<tr><td>chr1</td><td>32716840</td><td>32719857</td><td>chr1</td><td>32719399</td><td>32719857</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32716840</td><td>32716841</td><td>  51.700</td><td> 1</td><td>LCK     </td><td>ENSG00000182866</td><td>  2559</td></tr>
	<tr><td>chr1</td><td>32716840</td><td>32730715</td><td>chr1</td><td>32730435</td><td>32730715</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32716840</td><td>32716841</td><td>  51.700</td><td> 1</td><td>LCK     </td><td>ENSG00000182866</td><td> 13595</td></tr>
	<tr><td>chr1</td><td>32757687</td><td>32774677</td><td>chr1</td><td>32774187</td><td>32774677</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32757687</td><td>32757688</td><td>  58.740</td><td> 1</td><td>HDAC1   </td><td>ENSG00000116478</td><td> 16500</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrX</td><td> 55744172</td><td> 55821377</td><td>chrX</td><td> 55820159</td><td> 55821377</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 55744172</td><td> 55744173</td><td>  3.835</td><td> 1</td><td>RRAGB    </td><td>ENSG00000083750</td><td>  75987</td></tr>
	<tr><td>chrX</td><td> 55744172</td><td> 55945983</td><td>chrX</td><td> 55945745</td><td> 55945983</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 55744172</td><td> 55744173</td><td>  3.835</td><td> 1</td><td>RRAGB    </td><td>ENSG00000083750</td><td> 201573</td></tr>
	<tr><td>chrX</td><td> 62466185</td><td> 62569526</td><td>chrX</td><td> 62466185</td><td> 62466288</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 62569525</td><td> 62569526</td><td>  0.070</td><td> 1</td><td>SPIN4-AS1</td><td>ENSG00000233661</td><td> 103238</td></tr>
	<tr><td>chrX</td><td> 74144035</td><td> 74145283</td><td>chrX</td><td> 74144035</td><td> 74144156</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 74145282</td><td> 74145283</td><td>  2.810</td><td>-1</td><td>KIAA2022 </td><td>ENSG00000050030</td><td>   1127</td></tr>
	<tr><td>chrX</td><td> 74493920</td><td> 74580531</td><td>chrX</td><td> 74580334</td><td> 74580531</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 74493920</td><td> 74493921</td><td>  4.105</td><td> 1</td><td>UPRT     </td><td>ENSG00000094841</td><td>  86414</td></tr>
	<tr><td>chrX</td><td> 78964620</td><td> 79270256</td><td>chrX</td><td> 78964620</td><td> 78966457</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 79270255</td><td> 79270256</td><td>  0.005</td><td> 1</td><td>TBX22    </td><td>ENSG00000122145</td><td> 303799</td></tr>
	<tr><td>chrX</td><td> 80063348</td><td> 80065188</td><td>chrX</td><td> 80063348</td><td> 80063654</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80065187</td><td> 80065188</td><td>  4.925</td><td>-1</td><td>BRWD3    </td><td>ENSG00000165288</td><td>   1534</td></tr>
	<tr><td>chrX</td><td> 80457442</td><td> 80605724</td><td>chrX</td><td> 80605523</td><td> 80605724</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80457442</td><td> 80457443</td><td> 35.375</td><td> 1</td><td>SH3BGRL  </td><td>ENSG00000131171</td><td> 148081</td></tr>
	<tr><td>chrX</td><td> 80457442</td><td> 81153643</td><td>chrX</td><td> 81152857</td><td> 81153643</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80457442</td><td> 80457443</td><td> 35.375</td><td> 1</td><td>SH3BGRL  </td><td>ENSG00000131171</td><td> 695415</td></tr>
	<tr><td>chrX</td><td> 84258832</td><td> 84350826</td><td>chrX</td><td> 84350606</td><td> 84350826</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 84258832</td><td> 84258833</td><td>  5.420</td><td> 1</td><td>APOOL    </td><td>ENSG00000155008</td><td>  91774</td></tr>
	<tr><td>chrX</td><td> 86959307</td><td> 87442057</td><td>chrX</td><td> 87440824</td><td> 87442057</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 86959307</td><td> 86959308</td><td>  0.050</td><td>-1</td><td>RPSAP15  </td><td>ENSG00000237506</td><td> 481517</td></tr>
	<tr><td>chrX</td><td> 96090821</td><td> 96138908</td><td>chrX</td><td> 96090821</td><td> 96091558</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 96138907</td><td> 96138908</td><td>  0.245</td><td> 1</td><td>RPA4     </td><td>ENSG00000204086</td><td>  47350</td></tr>
	<tr><td>chrX</td><td> 99411771</td><td> 99668486</td><td>chrX</td><td> 99667367</td><td> 99668486</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 99411771</td><td> 99411772</td><td>  0.050</td><td>-1</td><td>RPSAP8   </td><td>ENSG00000230592</td><td> 255596</td></tr>
	<tr><td>chrX</td><td>102631268</td><td>102674865</td><td>chrX</td><td>102674776</td><td>102674865</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>102631268</td><td>102631269</td><td>  0.340</td><td> 1</td><td>NGFRAP1  </td><td>ENSG00000166681</td><td>  43508</td></tr>
	<tr><td>chrX</td><td>103411301</td><td>103498317</td><td>chrX</td><td>103497985</td><td>103498317</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>103411301</td><td>103411302</td><td>  3.740</td><td> 1</td><td>FAM199X  </td><td>ENSG00000123575</td><td>  86684</td></tr>
	<tr><td>chrX</td><td>103810996</td><td>103813358</td><td>chrX</td><td>103812931</td><td>103813358</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>103810996</td><td>103810997</td><td>  0.005</td><td> 1</td><td>IL1RAPL2 </td><td>ENSG00000189108</td><td>   1935</td></tr>
	<tr><td>chrX</td><td>107068985</td><td>107070514</td><td>chrX</td><td>107070119</td><td>107070514</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>107068985</td><td>107068986</td><td>  0.040</td><td> 1</td><td>MID2     </td><td>ENSG00000080561</td><td>   1134</td></tr>
	<tr><td>chrX</td><td>107979651</td><td>108313755</td><td>chrX</td><td>108312165</td><td>108313755</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>107979651</td><td>107979652</td><td>  0.010</td><td>-1</td><td>IRS4     </td><td>ENSG00000133124</td><td> 332514</td></tr>
	<tr><td>chrX</td><td>111540424</td><td>111923376</td><td>chrX</td><td>111540424</td><td>111540771</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>111923375</td><td>111923376</td><td>  0.155</td><td>-1</td><td>LHFPL1   </td><td>ENSG00000182508</td><td> 382605</td></tr>
	<tr><td>chrX</td><td>112084043</td><td>113028341</td><td>chrX</td><td>113028188</td><td>113028341</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>112084043</td><td>112084044</td><td>  5.185</td><td>-1</td><td>AMOT     </td><td>ENSG00000126016</td><td> 944145</td></tr>
	<tr><td>chrX</td><td>117629861</td><td>117631780</td><td>chrX</td><td>117630872</td><td>117631780</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>117629861</td><td>117629862</td><td>  9.130</td><td> 1</td><td>DOCK11   </td><td>ENSG00000147251</td><td>   1011</td></tr>
	<tr><td>chrX</td><td>118739858</td><td>118770984</td><td>chrX</td><td>118770255</td><td>118770984</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>118739858</td><td>118739859</td><td>  7.975</td><td>-1</td><td>NKRF     </td><td>ENSG00000186416</td><td>  30397</td></tr>
	<tr><td>chrX</td><td>122864707</td><td>122866907</td><td>chrX</td><td>122864707</td><td>122864772</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>122866906</td><td>122866907</td><td> 26.655</td><td>-1</td><td>THOC2    </td><td>ENSG00000125676</td><td>   2135</td></tr>
	<tr><td>chrX</td><td>124097666</td><td>125607233</td><td>chrX</td><td>125606843</td><td>125607233</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>124097666</td><td>124097667</td><td>  0.005</td><td>-1</td><td>TENM1    </td><td>ENSG00000009694</td><td>1509177</td></tr>
	<tr><td>chrX</td><td>130880224</td><td>131351176</td><td>chrX</td><td>130880224</td><td>130880690</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>131351175</td><td>131351176</td><td>  0.410</td><td> 1</td><td>RAP2C-AS1</td><td>ENSG00000232160</td><td> 470486</td></tr>
	<tr><td>chrX</td><td>133118185</td><td>133119923</td><td>chrX</td><td>133118185</td><td>133118258</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>133119922</td><td>133119923</td><td>  0.270</td><td>-1</td><td>GPC3     </td><td>ENSG00000147257</td><td>   1665</td></tr>
	<tr><td>chrX</td><td>137792247</td><td>138304940</td><td>chrX</td><td>137792247</td><td>137792647</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>138304939</td><td>138304940</td><td>  0.060</td><td>-1</td><td>FGF13    </td><td>ENSG00000129682</td><td> 512293</td></tr>
	<tr><td>chrX</td><td>152240819</td><td>152349916</td><td>chrX</td><td>152349590</td><td>152349916</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>152240819</td><td>152240820</td><td>  0.010</td><td> 1</td><td>PNMA6C   </td><td>ENSG00000235961</td><td> 108771</td></tr>
	<tr><td>chrX</td><td>153519895</td><td>153603007</td><td>chrX</td><td>153519895</td><td>153520410</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>153603006</td><td>153603007</td><td>241.275</td><td>-1</td><td>FLNA     </td><td>ENSG00000196924</td><td>  82597</td></tr>
	<tr><td>chrX</td><td>153526648</td><td>153603007</td><td>chrX</td><td>153526648</td><td>153526953</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>153603006</td><td>153603007</td><td>241.275</td><td>-1</td><td>FLNA     </td><td>ENSG00000196924</td><td>  76054</td></tr>
</tbody>
</table>




```R
Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN <-Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>% 
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL)  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
print("Done.")

Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN <-Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>%
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL)  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
print("Done.")

Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN <-Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered %>%
group_by(ChrHMR, StartHMR) %>% # Group by each HMR
top_n(n = 1, wt = -HMRTSSDist) %>%  # Take top row by lowest Distance
top_n(n = 1, wt = TPM) %>%  # Might overlap two genes or have a tie in dist. Take top TPM
top_n(n = 1, wt = GENE_SYMBOL)  # Might still overlap two genes with same TPM (often 0TPM), so take first alphabetically
print("Done.")
```

    [1] "Done."
    [1] "Done."
    [1] "Done."


## Calculate fractions


```R
Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN
```


<table class="dataframe">
<caption>A grouped_df: 1870 × 15</caption>
<thead>
	<tr><th scope=col>ChrHMRTSS</th><th scope=col>StartHMRTSS</th><th scope=col>EndHMRTSS</th><th scope=col>ChrHMR</th><th scope=col>StartHMR</th><th scope=col>EndHMR</th><th scope=col>HMRGroup</th><th scope=col>ChrTSS</th><th scope=col>StartTSS</th><th scope=col>EndTSS</th><th scope=col>TPM</th><th scope=col>strand</th><th scope=col>GENE_SYMBOL</th><th scope=col>ENSEMBL</th><th scope=col>HMRTSSDist</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 1385069</td><td> 1394334</td><td>chr1</td><td> 1394021</td><td> 1394334</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 1385069</td><td> 1385070</td><td>   0.525</td><td> 1</td><td>ATAD3C  </td><td>ENSG00000215915</td><td>  8952</td></tr>
	<tr><td>chr1</td><td> 1981909</td><td> 2032210</td><td>chr1</td><td> 2032031</td><td> 2032210</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 1981909</td><td> 1981910</td><td>   0.575</td><td> 1</td><td>PRKCZ   </td><td>ENSG00000067606</td><td> 50122</td></tr>
	<tr><td>chr1</td><td> 2263385</td><td> 2323147</td><td>chr1</td><td> 2263385</td><td> 2263443</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 2323146</td><td> 2323147</td><td>   2.535</td><td>-1</td><td>MORN1   </td><td>ENSG00000116151</td><td> 59704</td></tr>
	<tr><td>chr1</td><td> 3569325</td><td> 3573852</td><td>chr1</td><td> 3573086</td><td> 3573852</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 3569325</td><td> 3569326</td><td>  15.720</td><td>-1</td><td>WRAP73  </td><td>ENSG00000116213</td><td>  3761</td></tr>
	<tr><td>chr1</td><td> 6052533</td><td> 6073327</td><td>chr1</td><td> 6073217</td><td> 6073327</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 6052533</td><td> 6052534</td><td>   3.605</td><td>-1</td><td>NPHP4   </td><td>ENSG00000131697</td><td> 20684</td></tr>
	<tr><td>chr1</td><td> 6659636</td><td> 6673746</td><td>chr1</td><td> 6659636</td><td> 6660325</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td> 6673745</td><td> 6673746</td><td>   5.935</td><td> 1</td><td>PHF13   </td><td>ENSG00000116273</td><td> 13421</td></tr>
	<tr><td>chr1</td><td>12079523</td><td>12101107</td><td>chr1</td><td>12100074</td><td>12101107</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>12079523</td><td>12079524</td><td>  21.715</td><td> 1</td><td>MIIP    </td><td>ENSG00000116691</td><td> 20551</td></tr>
	<tr><td>chr1</td><td>12227060</td><td>12258322</td><td>chr1</td><td>12258053</td><td>12258322</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>12227060</td><td>12227061</td><td>  31.810</td><td> 1</td><td>TNFRSF1B</td><td>ENSG00000028137</td><td> 30993</td></tr>
	<tr><td>chr1</td><td>14925200</td><td>15040438</td><td>chr1</td><td>15040254</td><td>15040438</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>14925200</td><td>14925201</td><td>   1.670</td><td> 1</td><td>KAZN    </td><td>ENSG00000189337</td><td>115054</td></tr>
	<tr><td>chr1</td><td>18404348</td><td>18434241</td><td>chr1</td><td>18404348</td><td>18404580</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>18434240</td><td>18434241</td><td>   0.045</td><td> 1</td><td>IGSF21  </td><td>ENSG00000117154</td><td> 29661</td></tr>
	<tr><td>chr1</td><td>19186176</td><td>19195881</td><td>chr1</td><td>19195721</td><td>19195881</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>19186176</td><td>19186177</td><td>   0.005</td><td>-1</td><td>TAS1R2  </td><td>ENSG00000179002</td><td>  9545</td></tr>
	<tr><td>chr1</td><td>22087677</td><td>22110100</td><td>chr1</td><td>22087677</td><td>22089082</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22110099</td><td>22110100</td><td>  37.530</td><td>-1</td><td>USP48   </td><td>ENSG00000090686</td><td> 21018</td></tr>
	<tr><td>chr1</td><td>22106294</td><td>22110100</td><td>chr1</td><td>22106294</td><td>22106773</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22110099</td><td>22110100</td><td>  37.530</td><td>-1</td><td>USP48   </td><td>ENSG00000090686</td><td>  3327</td></tr>
	<tr><td>chr1</td><td>22470462</td><td>22482011</td><td>chr1</td><td>22481946</td><td>22482011</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>22470462</td><td>22470463</td><td>   0.040</td><td>-1</td><td>WNT4    </td><td>ENSG00000162552</td><td> 11484</td></tr>
	<tr><td>chr1</td><td>24514449</td><td>24553751</td><td>chr1</td><td>24553383</td><td>24553751</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>24514449</td><td>24514450</td><td>   1.720</td><td>-1</td><td>IFNLR1  </td><td>ENSG00000185436</td><td> 38934</td></tr>
	<tr><td>chr1</td><td>24860964</td><td>24882603</td><td>chr1</td><td>24860964</td><td>24861150</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>24882602</td><td>24882603</td><td>   0.005</td><td> 1</td><td>NCMAP   </td><td>ENSG00000184454</td><td> 21453</td></tr>
	<tr><td>chr1</td><td>25242448</td><td>25291613</td><td>chr1</td><td>25242448</td><td>25242570</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25291612</td><td>25291613</td><td>  57.410</td><td>-1</td><td>RUNX3   </td><td>ENSG00000020633</td><td> 49043</td></tr>
	<tr><td>chr1</td><td>25291612</td><td>25373247</td><td>chr1</td><td>25372734</td><td>25373247</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25291612</td><td>25291613</td><td>  57.410</td><td>-1</td><td>RUNX3   </td><td>ENSG00000020633</td><td> 81122</td></tr>
	<tr><td>chr1</td><td>25943959</td><td>25956163</td><td>chr1</td><td>25955620</td><td>25956163</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>25943959</td><td>25943960</td><td>   0.075</td><td> 1</td><td>MAN1C1  </td><td>ENSG00000117643</td><td> 11661</td></tr>
	<tr><td>chr1</td><td>26126667</td><td>26131354</td><td>chr1</td><td>26131133</td><td>26131354</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>26126667</td><td>26126668</td><td>   1.770</td><td> 1</td><td>SEPN1   </td><td>ENSG00000162430</td><td>  4466</td></tr>
	<tr><td>chr1</td><td>27433141</td><td>27493473</td><td>chr1</td><td>27433141</td><td>27433285</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27493472</td><td>27493473</td><td>   7.615</td><td>-1</td><td>SLC9A1  </td><td>ENSG00000090020</td><td> 60188</td></tr>
	<tr><td>chr1</td><td>27693383</td><td>27696751</td><td>chr1</td><td>27696156</td><td>27696751</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27693383</td><td>27693384</td><td>   0.795</td><td>-1</td><td>MAP3K6  </td><td>ENSG00000142733</td><td>  2773</td></tr>
	<tr><td>chr1</td><td>27768425</td><td>27816670</td><td>chr1</td><td>27768425</td><td>27769315</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27816669</td><td>27816670</td><td>  42.775</td><td>-1</td><td>WASF2   </td><td>ENSG00000158195</td><td> 47355</td></tr>
	<tr><td>chr1</td><td>27809797</td><td>27816670</td><td>chr1</td><td>27809797</td><td>27810107</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>27816669</td><td>27816670</td><td>  42.775</td><td>-1</td><td>WASF2   </td><td>ENSG00000158195</td><td>  6563</td></tr>
	<tr><td>chr1</td><td>28199055</td><td>28217318</td><td>chr1</td><td>28216907</td><td>28217318</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>28199055</td><td>28199056</td><td>  20.935</td><td> 1</td><td>THEMIS2 </td><td>ENSG00000130775</td><td> 17852</td></tr>
	<tr><td>chr1</td><td>28835071</td><td>28838132</td><td>chr1</td><td>28837950</td><td>28838132</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>28835071</td><td>28835072</td><td>3464.135</td><td> 1</td><td>SNORA73B</td><td>ENSG00000200087</td><td>  2879</td></tr>
	<tr><td>chr1</td><td>32479430</td><td>32487531</td><td>chr1</td><td>32486412</td><td>32487531</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32479430</td><td>32479431</td><td>  76.815</td><td> 1</td><td>KHDRBS1 </td><td>ENSG00000121774</td><td>  6982</td></tr>
	<tr><td>chr1</td><td>32716840</td><td>32719857</td><td>chr1</td><td>32719399</td><td>32719857</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32716840</td><td>32716841</td><td>  51.700</td><td> 1</td><td>LCK     </td><td>ENSG00000182866</td><td>  2559</td></tr>
	<tr><td>chr1</td><td>32716840</td><td>32730715</td><td>chr1</td><td>32730435</td><td>32730715</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32716840</td><td>32716841</td><td>  51.700</td><td> 1</td><td>LCK     </td><td>ENSG00000182866</td><td> 13595</td></tr>
	<tr><td>chr1</td><td>32757687</td><td>32774677</td><td>chr1</td><td>32774187</td><td>32774677</td><td>Bcell_UnclusteredCS</td><td>chr1</td><td>32757687</td><td>32757688</td><td>  58.740</td><td> 1</td><td>HDAC1   </td><td>ENSG00000116478</td><td> 16500</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrX</td><td> 55744172</td><td> 55821377</td><td>chrX</td><td> 55820159</td><td> 55821377</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 55744172</td><td> 55744173</td><td>  3.835</td><td> 1</td><td>RRAGB    </td><td>ENSG00000083750</td><td>  75987</td></tr>
	<tr><td>chrX</td><td> 55744172</td><td> 55945983</td><td>chrX</td><td> 55945745</td><td> 55945983</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 55744172</td><td> 55744173</td><td>  3.835</td><td> 1</td><td>RRAGB    </td><td>ENSG00000083750</td><td> 201573</td></tr>
	<tr><td>chrX</td><td> 62466185</td><td> 62569526</td><td>chrX</td><td> 62466185</td><td> 62466288</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 62569525</td><td> 62569526</td><td>  0.070</td><td> 1</td><td>SPIN4-AS1</td><td>ENSG00000233661</td><td> 103238</td></tr>
	<tr><td>chrX</td><td> 74144035</td><td> 74145283</td><td>chrX</td><td> 74144035</td><td> 74144156</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 74145282</td><td> 74145283</td><td>  2.810</td><td>-1</td><td>KIAA2022 </td><td>ENSG00000050030</td><td>   1127</td></tr>
	<tr><td>chrX</td><td> 74493920</td><td> 74580531</td><td>chrX</td><td> 74580334</td><td> 74580531</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 74493920</td><td> 74493921</td><td>  4.105</td><td> 1</td><td>UPRT     </td><td>ENSG00000094841</td><td>  86414</td></tr>
	<tr><td>chrX</td><td> 78964620</td><td> 79270256</td><td>chrX</td><td> 78964620</td><td> 78966457</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 79270255</td><td> 79270256</td><td>  0.005</td><td> 1</td><td>TBX22    </td><td>ENSG00000122145</td><td> 303799</td></tr>
	<tr><td>chrX</td><td> 80063348</td><td> 80065188</td><td>chrX</td><td> 80063348</td><td> 80063654</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80065187</td><td> 80065188</td><td>  4.925</td><td>-1</td><td>BRWD3    </td><td>ENSG00000165288</td><td>   1534</td></tr>
	<tr><td>chrX</td><td> 80457442</td><td> 80605724</td><td>chrX</td><td> 80605523</td><td> 80605724</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80457442</td><td> 80457443</td><td> 35.375</td><td> 1</td><td>SH3BGRL  </td><td>ENSG00000131171</td><td> 148081</td></tr>
	<tr><td>chrX</td><td> 80457442</td><td> 81153643</td><td>chrX</td><td> 81152857</td><td> 81153643</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 80457442</td><td> 80457443</td><td> 35.375</td><td> 1</td><td>SH3BGRL  </td><td>ENSG00000131171</td><td> 695415</td></tr>
	<tr><td>chrX</td><td> 84258832</td><td> 84350826</td><td>chrX</td><td> 84350606</td><td> 84350826</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 84258832</td><td> 84258833</td><td>  5.420</td><td> 1</td><td>APOOL    </td><td>ENSG00000155008</td><td>  91774</td></tr>
	<tr><td>chrX</td><td> 86959307</td><td> 87442057</td><td>chrX</td><td> 87440824</td><td> 87442057</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 86959307</td><td> 86959308</td><td>  0.050</td><td>-1</td><td>RPSAP15  </td><td>ENSG00000237506</td><td> 481517</td></tr>
	<tr><td>chrX</td><td> 96090821</td><td> 96138908</td><td>chrX</td><td> 96090821</td><td> 96091558</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 96138907</td><td> 96138908</td><td>  0.245</td><td> 1</td><td>RPA4     </td><td>ENSG00000204086</td><td>  47350</td></tr>
	<tr><td>chrX</td><td> 99411771</td><td> 99668486</td><td>chrX</td><td> 99667367</td><td> 99668486</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td> 99411771</td><td> 99411772</td><td>  0.050</td><td>-1</td><td>RPSAP8   </td><td>ENSG00000230592</td><td> 255596</td></tr>
	<tr><td>chrX</td><td>102631268</td><td>102674865</td><td>chrX</td><td>102674776</td><td>102674865</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>102631268</td><td>102631269</td><td>  0.340</td><td> 1</td><td>NGFRAP1  </td><td>ENSG00000166681</td><td>  43508</td></tr>
	<tr><td>chrX</td><td>103411301</td><td>103498317</td><td>chrX</td><td>103497985</td><td>103498317</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>103411301</td><td>103411302</td><td>  3.740</td><td> 1</td><td>FAM199X  </td><td>ENSG00000123575</td><td>  86684</td></tr>
	<tr><td>chrX</td><td>103810996</td><td>103813358</td><td>chrX</td><td>103812931</td><td>103813358</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>103810996</td><td>103810997</td><td>  0.005</td><td> 1</td><td>IL1RAPL2 </td><td>ENSG00000189108</td><td>   1935</td></tr>
	<tr><td>chrX</td><td>107068985</td><td>107070514</td><td>chrX</td><td>107070119</td><td>107070514</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>107068985</td><td>107068986</td><td>  0.040</td><td> 1</td><td>MID2     </td><td>ENSG00000080561</td><td>   1134</td></tr>
	<tr><td>chrX</td><td>107979651</td><td>108313755</td><td>chrX</td><td>108312165</td><td>108313755</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>107979651</td><td>107979652</td><td>  0.010</td><td>-1</td><td>IRS4     </td><td>ENSG00000133124</td><td> 332514</td></tr>
	<tr><td>chrX</td><td>111540424</td><td>111923376</td><td>chrX</td><td>111540424</td><td>111540771</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>111923375</td><td>111923376</td><td>  0.155</td><td>-1</td><td>LHFPL1   </td><td>ENSG00000182508</td><td> 382605</td></tr>
	<tr><td>chrX</td><td>112084043</td><td>113028341</td><td>chrX</td><td>113028188</td><td>113028341</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>112084043</td><td>112084044</td><td>  5.185</td><td>-1</td><td>AMOT     </td><td>ENSG00000126016</td><td> 944145</td></tr>
	<tr><td>chrX</td><td>117629861</td><td>117631780</td><td>chrX</td><td>117630872</td><td>117631780</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>117629861</td><td>117629862</td><td>  9.130</td><td> 1</td><td>DOCK11   </td><td>ENSG00000147251</td><td>   1011</td></tr>
	<tr><td>chrX</td><td>118739858</td><td>118770984</td><td>chrX</td><td>118770255</td><td>118770984</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>118739858</td><td>118739859</td><td>  7.975</td><td>-1</td><td>NKRF     </td><td>ENSG00000186416</td><td>  30397</td></tr>
	<tr><td>chrX</td><td>122864707</td><td>122866907</td><td>chrX</td><td>122864707</td><td>122864772</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>122866906</td><td>122866907</td><td> 26.655</td><td>-1</td><td>THOC2    </td><td>ENSG00000125676</td><td>   2135</td></tr>
	<tr><td>chrX</td><td>124097666</td><td>125607233</td><td>chrX</td><td>125606843</td><td>125607233</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>124097666</td><td>124097667</td><td>  0.005</td><td>-1</td><td>TENM1    </td><td>ENSG00000009694</td><td>1509177</td></tr>
	<tr><td>chrX</td><td>130880224</td><td>131351176</td><td>chrX</td><td>130880224</td><td>130880690</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>131351175</td><td>131351176</td><td>  0.410</td><td> 1</td><td>RAP2C-AS1</td><td>ENSG00000232160</td><td> 470486</td></tr>
	<tr><td>chrX</td><td>133118185</td><td>133119923</td><td>chrX</td><td>133118185</td><td>133118258</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>133119922</td><td>133119923</td><td>  0.270</td><td>-1</td><td>GPC3     </td><td>ENSG00000147257</td><td>   1665</td></tr>
	<tr><td>chrX</td><td>137792247</td><td>138304940</td><td>chrX</td><td>137792247</td><td>137792647</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>138304939</td><td>138304940</td><td>  0.060</td><td>-1</td><td>FGF13    </td><td>ENSG00000129682</td><td> 512293</td></tr>
	<tr><td>chrX</td><td>152240819</td><td>152349916</td><td>chrX</td><td>152349590</td><td>152349916</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>152240819</td><td>152240820</td><td>  0.010</td><td> 1</td><td>PNMA6C   </td><td>ENSG00000235961</td><td> 108771</td></tr>
	<tr><td>chrX</td><td>153519895</td><td>153603007</td><td>chrX</td><td>153519895</td><td>153520410</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>153603006</td><td>153603007</td><td>241.275</td><td>-1</td><td>FLNA     </td><td>ENSG00000196924</td><td>  82597</td></tr>
	<tr><td>chrX</td><td>153526648</td><td>153603007</td><td>chrX</td><td>153526648</td><td>153526953</td><td>Bcell_UnclusteredCS</td><td>chrX</td><td>153603006</td><td>153603007</td><td>241.275</td><td>-1</td><td>FLNA     </td><td>ENSG00000196924</td><td>  76054</td></tr>
</tbody>
</table>




```R
numGene_UNlooseCS_1NN
```


<table class="dataframe">
<caption>A tibble: 6 × 2</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_unclustered_loose</td></tr>
	<tr><td> 25000</td><td>Bcell_unclustered_loose</td></tr>
	<tr><td> 50000</td><td>Bcell_unclustered_loose</td></tr>
	<tr><td> 75000</td><td>Bcell_unclustered_loose</td></tr>
	<tr><td>100000</td><td>Bcell_unclustered_loose</td></tr>
	<tr><td>150000</td><td>Bcell_unclustered_loose</td></tr>
</tbody>
</table>




```R
threshold_list <- c(10000,25000,50000,75000,100000,150000)

numGene_CLcontainsCS_1NN <- tibble(
    thresholds = threshold_list,
    HMRGroup = "Bcell_clustersContainsCS"
)

numGene_UNCS_1NN <- tibble(
    thresholds = threshold_list,
    HMRGroup = "Bcell_unclustered"
)

numGene_UNlooseCS_1NN <- tibble(
    thresholds = threshold_list,
    HMRGroup = "Bcell_unclustered_loose"
)



get_numGenes_per_threshold <- function(thresh, df){
    df %>% dplyr::filter(HMRTSSDist < thresh) %>% nrow()
}
                                                    
print("Initialized.")
```

    [1] "Initialized."



```R
# Get numbers by threshold

# CLusters that contain Cell Specific 
CLcontainsCS_counts <- map(threshold_list, get_numGenes_per_threshold, df = Bcell_clusters_containsCS.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN)

numGene_CLcontainsCS_1NN$HMRCounts <- unlist(CLcontainsCS_counts)

print("Done.")




# UNclustered Cell specific 
UNCS_counts <- map(threshold_list, get_numGenes_per_threshold, df = Bcell_unclustered_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN)

numGene_UNCS_1NN$HMRCounts <- unlist(UNCS_counts)

print("Done.")



# UNclustered - All -  Cell specific 
UNCS_loose_counts <- map(threshold_list, get_numGenes_per_threshold, df = Bcell_unclustered_loose_cellspecific.100NN.GM_ENSGnoVersionGENESYMBOL_minTPM0.TAD_filtered.1NN)

numGene_UNlooseCS_1NN$HMRCounts <- unlist(UNCS_loose_counts)




print("Done.")
```

    [1] "Done."
    [1] "Done."
    [1] "Done."



```R
numGene_CLcontainsCS_1NN
numGene_UNCS_1NN
numGene_UNlooseCS_1NN
```


<table class="dataframe">
<caption>A tibble: 6 × 3</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup</th><th scope=col>HMRCounts</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_clustersContainsCS</td><td>138</td></tr>
	<tr><td> 25000</td><td>Bcell_clustersContainsCS</td><td>219</td></tr>
	<tr><td> 50000</td><td>Bcell_clustersContainsCS</td><td>290</td></tr>
	<tr><td> 75000</td><td>Bcell_clustersContainsCS</td><td>324</td></tr>
	<tr><td>100000</td><td>Bcell_clustersContainsCS</td><td>351</td></tr>
	<tr><td>150000</td><td>Bcell_clustersContainsCS</td><td>378</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A tibble: 6 × 3</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup</th><th scope=col>HMRCounts</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_unclustered</td><td> 122</td></tr>
	<tr><td> 25000</td><td>Bcell_unclustered</td><td> 403</td></tr>
	<tr><td> 50000</td><td>Bcell_unclustered</td><td> 737</td></tr>
	<tr><td> 75000</td><td>Bcell_unclustered</td><td> 906</td></tr>
	<tr><td>100000</td><td>Bcell_unclustered</td><td>1013</td></tr>
	<tr><td>150000</td><td>Bcell_unclustered</td><td>1143</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A tibble: 6 × 3</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup</th><th scope=col>HMRCounts</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_unclustered_loose</td><td> 389</td></tr>
	<tr><td> 25000</td><td>Bcell_unclustered_loose</td><td> 712</td></tr>
	<tr><td> 50000</td><td>Bcell_unclustered_loose</td><td>1083</td></tr>
	<tr><td> 75000</td><td>Bcell_unclustered_loose</td><td>1267</td></tr>
	<tr><td>100000</td><td>Bcell_unclustered_loose</td><td>1378</td></tr>
	<tr><td>150000</td><td>Bcell_unclustered_loose</td><td>1518</td></tr>
</tbody>
</table>




```R

```


```R
# Calc fraction
numGene_CLcontainsCS_1NN_fraction <- numGene_CLcontainsCS_1NN %>% mutate(fraction = (HMRCounts/444) )
numGene_UNCS_1NN_fraction <- numGene_UNCS_1NN %>% mutate(fraction = (HMRCounts/1621) )
numGene_UNlooseCS_1NN_fraction <- numGene_UNlooseCS_1NN %>% mutate(fraction = (HMRCounts/2040) )

numGene_CLcontainsCS_UNCS_1NN_fraction <- rbind(numGene_CLcontainsCS_1NN_fraction, numGene_UNCS_1NN_fraction )

numGene_CLcontainsCS_UNCS_UNCSloose_1NN_fraction <- rbind(numGene_CLcontainsCS_1NN_fraction, numGene_UNCS_1NN_fraction, numGene_UNlooseCS_1NN_fraction)

print("Done.")
```

    [1] "Done."


## Plot


```R
p_numGene_1NN <- numGene_CLcontainsCS_UNCS_1NN_fraction %>%
ggplot(aes(x = thresholds, y = fraction)) +
geom_point(aes(color = HMRGroup)) + 
geom_line(aes(color = HMRGroup)) +
theme_minimal() +
scale_color_manual(values=c("#B0DAB6", "#3990C0")) +
theme(aspect.ratio = .7, legend.position = "top") +
scale_x_continuous(breaks=threshold_list) +
ylab("Fraction HMRs with Gene Assignment")
p_numGene_1NN
```


![png](output_133_0.png)



```R
pdf("/data/hodges_lab/Tim/FractionGenesByDistance_Cl_Un_UnLoose.pdf")

p <- numGene_CLcontainsCS_UNCS_UNCSloose_1NN_fraction %>%
ggplot(aes(x = thresholds, y = fraction)) +
geom_point(aes(color = HMRGroup)) + 
geom_line(aes(color = HMRGroup)) +
theme_minimal() +
scale_color_manual(values=c("#B0DAB6", "#061638", "#3990C0")) +
theme(aspect.ratio = .7, legend.position = "top") +
scale_x_continuous(breaks=threshold_list) +
ylab("Fraction HMRs with Gene Assignment")
p

dev.off()
p
```


<strong>png:</strong> 2



![png](output_134_1.png)



```R
## Fraction of fractions
```


```R
numGene_CLcontainsCS_UNCS_1NN_fractionRatio <- merge(numGene_CLcontainsCS_1NN_fraction, numGene_UNCS_1NN_fraction, by = "thresholds") %>% mutate(fractionRatio = (fraction.x/fraction.y))

numGene_CLcontainsCS_UNCSLoose_1NN_fractionRatio <- merge(numGene_CLcontainsCS_1NN_fraction, numGene_UNlooseCS_1NN_fraction, by = "thresholds") %>% mutate(fractionRatio = (fraction.x/fraction.y))
```


```R

```


```R
p_numGeneFraction_1NN <- numGene_CLcontainsCS_UNCS_1NN_fractionRatio %>% 
ggplot(aes(x = thresholds, y = fractionRatio)) +
geom_point() + 
geom_line() +
geom_hline(yintercept = 1, color = "red") + 
coord_cartesian(ylim = c(1,4.5)) +
theme_minimal() +
scale_x_continuous(breaks=threshold_list) + 
theme(aspect.ratio = .25) +
ylab("FractionCL/FractionUN")

p_numGeneFraction_1NN
```


![png](output_138_0.png)



```R
ggpubr::ggarrange(p_numGene_1NN, p_numGeneFraction_1NN, nrow = 2, align = "v", heights = c(4, 1.539))
```


![png](output_139_0.png)


## Stats for fractions


```R
head(numGene_CLcontainsCS_UNCS_1NN_fractionRatio, 3)
```


<table class="dataframe">
<caption>A data.frame: 3 × 8</caption>
<thead>
	<tr><th></th><th scope=col>thresholds</th><th scope=col>HMRGroup.x</th><th scope=col>HMRCounts.x</th><th scope=col>fraction.x</th><th scope=col>HMRGroup.y</th><th scope=col>HMRCounts.y</th><th scope=col>fraction.y</th><th scope=col>fractionRatio</th></tr>
	<tr><th></th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>10000</td><td>Bcell_clustersContainsCS</td><td>138</td><td>0.3108108</td><td>Bcell_unclustered</td><td>122</td><td>0.07526218</td><td>4.129708</td></tr>
	<tr><th scope=row>2</th><td>25000</td><td>Bcell_clustersContainsCS</td><td>219</td><td>0.4932432</td><td>Bcell_unclustered</td><td>403</td><td>0.24861197</td><td>1.983988</td></tr>
	<tr><th scope=row>3</th><td>50000</td><td>Bcell_clustersContainsCS</td><td>290</td><td>0.6531532</td><td>Bcell_unclustered</td><td>737</td><td>0.45465762</td><td>1.436582</td></tr>
</tbody>
</table>




```R
# Cl vs. Un
numGene_CLcontainsCS_UNCS_1NN_fractionRatio_pvals <- numGene_CLcontainsCS_UNCS_1NN_fractionRatio %>% rowwise() %>% mutate(
    propTestP = prop.test(x = c(HMRCounts.x, HMRCounts.y), n = c(444, 1621))$p.value,
    propTestStat = prop.test(x = c(HMRCounts.x, HMRCounts.y), n = c(444, 1621))$statistic,
)
numGene_CLcontainsCS_UNCS_1NN_fractionRatio_pvals


# Cl vs. UnLoose
numGene_CLcontainsCS_UNCSLoose_1NN_fractionRatio_pvals <- numGene_CLcontainsCS_UNCSLoose_1NN_fractionRatio %>% rowwise() %>% mutate(
    propTestP = prop.test(x = c(HMRCounts.x, HMRCounts.y), n = c(444, 2040))$p.value,
    propTestStat = prop.test(x = c(HMRCounts.x, HMRCounts.y), n = c(444, 2040))$statistic,
)
numGene_CLcontainsCS_UNCSLoose_1NN_fractionRatio_pvals
```


<table class="dataframe">
<caption>A rowwise_df: 6 × 10</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup.x</th><th scope=col>HMRCounts.x</th><th scope=col>fraction.x</th><th scope=col>HMRGroup.y</th><th scope=col>HMRCounts.y</th><th scope=col>fraction.y</th><th scope=col>fractionRatio</th><th scope=col>propTestP</th><th scope=col>propTestStat</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_clustersContainsCS</td><td>138</td><td>0.3108108</td><td>Bcell_unclustered</td><td> 122</td><td>0.07526218</td><td>4.129708</td><td>1.224932e-39</td><td>173.57631</td></tr>
	<tr><td> 25000</td><td>Bcell_clustersContainsCS</td><td>219</td><td>0.4932432</td><td>Bcell_unclustered</td><td> 403</td><td>0.24861197</td><td>1.983988</td><td>4.320121e-23</td><td> 97.93652</td></tr>
	<tr><td> 50000</td><td>Bcell_clustersContainsCS</td><td>290</td><td>0.6531532</td><td>Bcell_unclustered</td><td> 737</td><td>0.45465762</td><td>1.436582</td><td>1.866878e-13</td><td> 54.14015</td></tr>
	<tr><td> 75000</td><td>Bcell_clustersContainsCS</td><td>324</td><td>0.7297297</td><td>Bcell_unclustered</td><td> 906</td><td>0.55891425</td><td>1.305620</td><td>1.168654e-10</td><td> 41.51675</td></tr>
	<tr><td>100000</td><td>Bcell_clustersContainsCS</td><td>351</td><td>0.7905405</td><td>Bcell_unclustered</td><td>1013</td><td>0.62492289</td><td>1.265021</td><td>9.607968e-11</td><td> 41.89965</td></tr>
	<tr><td>150000</td><td>Bcell_clustersContainsCS</td><td>378</td><td>0.8513514</td><td>Bcell_unclustered</td><td>1143</td><td>0.70512030</td><td>1.207385</td><td>8.423779e-10</td><td> 37.65945</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A rowwise_df: 6 × 10</caption>
<thead>
	<tr><th scope=col>thresholds</th><th scope=col>HMRGroup.x</th><th scope=col>HMRCounts.x</th><th scope=col>fraction.x</th><th scope=col>HMRGroup.y</th><th scope=col>HMRCounts.y</th><th scope=col>fraction.y</th><th scope=col>fractionRatio</th><th scope=col>propTestP</th><th scope=col>propTestStat</th></tr>
	<tr><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td> 10000</td><td>Bcell_clustersContainsCS</td><td>138</td><td>0.3108108</td><td>Bcell_unclustered_loose</td><td> 389</td><td>0.1906863</td><td>1.629959</td><td>2.912668e-08</td><td>30.76485</td></tr>
	<tr><td> 25000</td><td>Bcell_clustersContainsCS</td><td>219</td><td>0.4932432</td><td>Bcell_unclustered_loose</td><td> 712</td><td>0.3490196</td><td>1.413225</td><td>1.748548e-08</td><td>31.75548</td></tr>
	<tr><td> 50000</td><td>Bcell_clustersContainsCS</td><td>290</td><td>0.6531532</td><td>Bcell_unclustered_loose</td><td>1083</td><td>0.5308824</td><td>1.230316</td><td>3.430992e-06</td><td>21.55905</td></tr>
	<tr><td> 75000</td><td>Bcell_clustersContainsCS</td><td>324</td><td>0.7297297</td><td>Bcell_unclustered_loose</td><td>1267</td><td>0.6210784</td><td>1.174940</td><td>1.962262e-05</td><td>18.22557</td></tr>
	<tr><td>100000</td><td>Bcell_clustersContainsCS</td><td>351</td><td>0.7905405</td><td>Bcell_unclustered_loose</td><td>1378</td><td>0.6754902</td><td>1.170321</td><td>2.364742e-06</td><td>22.27328</td></tr>
	<tr><td>150000</td><td>Bcell_clustersContainsCS</td><td>378</td><td>0.8513514</td><td>Bcell_unclustered_loose</td><td>1518</td><td>0.7441176</td><td>1.144109</td><td>1.977369e-06</td><td>22.61691</td></tr>
</tbody>
</table>




```R
pdf("/data/hodges_lab/Tim/Bcell.TAD.1NN.UniqueGenes.ProportionOfHMRsbyDistance.July15.Cl_Un_UnLoose.pdf")

ps <- numGene_CLcontainsCS_UNCS_UNCSloose_1NN_fraction %>%
ggplot(aes(x = thresholds, y = fraction)) +
geom_point(aes(color = HMRGroup), size = 5) + 
geom_line(aes(color = HMRGroup), size = 2) +
theme_bw() +
scale_color_manual(values=c("#B0DAB6", "#061638", "#3990C0")) +
theme(aspect.ratio = .7, legend.position = "top") +
scale_x_continuous(breaks=threshold_list) +
ylab("Fraction HMRs with Gene Assignment") +
geom_text(data = numGene_CLcontainsCS_UNCS_1NN_fractionRatio_pvals, aes(x = thresholds+1000, y = .5, label = format(propTestP, digits=3))) +
geom_text(data = numGene_CLcontainsCS_UNCSLoose_1NN_fractionRatio_pvals, aes(x = thresholds+1000, y = .7, label = format(propTestP, digits=3)))
ps

dev.off()
ps
```


<strong>png:</strong> 2



![png](output_143_1.png)



```R
pdf("Bcell.TAD.1NN.UniqueGenes.ProportionOfHMRsbyDistance.June11.pdf")

p_numGene_1NN_stats <- numGene_CLcontainsCS_UNCS_1NN_fraction %>%
ggplot(aes(x = thresholds, y = fraction)) +
geom_point(aes(color = HMRGroup), size = 5) + 
geom_line(aes(color = HMRGroup), size = 2) +
theme_bw() +
scale_color_manual(values=c("#B0DAB6", "#3990C0")) +
theme(aspect.ratio = .7, legend.position = "top") +
scale_x_continuous(breaks=threshold_list) +
ylab("Fraction HMRs with Gene Assignment") +
geom_text(data = numGene_CLcontainsCS_UNCS_1NN_fractionRatio_pvals, aes(x = thresholds+1000, y = .5, label = format(propTestP, digits=3)))
p_numGene_1NN_stats

dev.off()
p_numGene_1NN_stats
```


<strong>png:</strong> 2



![png](output_144_1.png)



```R

```
