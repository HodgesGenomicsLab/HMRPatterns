# Accumulation

## HMR files to use:


```R
HMR_DIR=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/

H1_FILE=${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt
HSPC_FILE=${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt
MACRO_FILE=${HMR_DIR}Macrophage.minsize50.filtforrefseqTSSexons.txt
BCELL_FILE=${HMR_DIR}Bcell.minsize50.filtforrefseqTSSexons.txt
```

## R:

## Load libaries and files 


```R
library(tidyverse)
library(ggplot2)
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    



```R
setwd("/data/hodges_lab/Tim/ACCUMULATION_PERSISTENCE/")

# Load in to check numbers
H1_FILE <- read_tsv("/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/H1ESC.minsize50.filtforrefseqTSSexons.txt", col_names = FALSE)
HSPC_FILE <- read_tsv("/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/HSC.minsize50.filtforrefseqTSSexons.txt", col_names = FALSE)
MACRO_FILE <- read_tsv("/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/Macrophage.minsize50.filtforrefseqTSSexons.txt", col_names = FALSE)
BCELL_FILE <- read_tsv("/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/Bcell.minsize50.filtforrefseqTSSexons.txt", col_names = FALSE)
```

    [1mRows: [22m[34m18235[39m [1mColumns: [22m[34m4[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): X1
    [32mdbl[39m (3): X2, X3, X4
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m46056[39m [1mColumns: [22m[34m4[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): X1
    [32mdbl[39m (3): X2, X3, X4
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m54331[39m [1mColumns: [22m[34m4[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): X1
    [32mdbl[39m (3): X2, X3, X4
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m34070[39m [1mColumns: [22m[34m4[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): X1
    [32mdbl[39m (3): X2, X3, X4
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
H1_FILE
```


<table class="dataframe">
<caption>A spec_tbl_df: 18235 × 4</caption>
<thead>
	<tr><th scope=col>X1</th><th scope=col>X2</th><th scope=col>X3</th><th scope=col>X4</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 564470</td><td> 566570</td><td>2100</td></tr>
	<tr><td>chr1</td><td> 566713</td><td> 566879</td><td> 166</td></tr>
	<tr><td>chr1</td><td> 567112</td><td> 567402</td><td> 290</td></tr>
	<tr><td>chr1</td><td> 567500</td><td> 567696</td><td> 196</td></tr>
	<tr><td>chr1</td><td> 567881</td><td> 568325</td><td> 444</td></tr>
	<tr><td>chr1</td><td> 568459</td><td> 568587</td><td> 128</td></tr>
	<tr><td>chr1</td><td> 568760</td><td> 570301</td><td>1541</td></tr>
	<tr><td>chr1</td><td> 713671</td><td> 714779</td><td>1108</td></tr>
	<tr><td>chr1</td><td> 724205</td><td> 724285</td><td>  80</td></tr>
	<tr><td>chr1</td><td> 762112</td><td> 763166</td><td>1054</td></tr>
	<tr><td>chr1</td><td> 804991</td><td> 805519</td><td> 528</td></tr>
	<tr><td>chr1</td><td> 839667</td><td> 840422</td><td> 755</td></tr>
	<tr><td>chr1</td><td> 840554</td><td> 841039</td><td> 485</td></tr>
	<tr><td>chr1</td><td> 856108</td><td> 856782</td><td> 674</td></tr>
	<tr><td>chr1</td><td> 869169</td><td> 870599</td><td>1430</td></tr>
	<tr><td>chr1</td><td> 919594</td><td> 919883</td><td> 289</td></tr>
	<tr><td>chr1</td><td> 959987</td><td> 960282</td><td> 295</td></tr>
	<tr><td>chr1</td><td> 975314</td><td> 975598</td><td> 284</td></tr>
	<tr><td>chr1</td><td> 994206</td><td> 995434</td><td>1228</td></tr>
	<tr><td>chr1</td><td> 999276</td><td> 999705</td><td> 429</td></tr>
	<tr><td>chr1</td><td>1003815</td><td>1004981</td><td>1166</td></tr>
	<tr><td>chr1</td><td>1014625</td><td>1016391</td><td>1766</td></tr>
	<tr><td>chr1</td><td>1057486</td><td>1057736</td><td> 250</td></tr>
	<tr><td>chr1</td><td>1072028</td><td>1072128</td><td> 100</td></tr>
	<tr><td>chr1</td><td>1072293</td><td>1072879</td><td> 586</td></tr>
	<tr><td>chr1</td><td>1092879</td><td>1093824</td><td> 945</td></tr>
	<tr><td>chr1</td><td>1097958</td><td>1098103</td><td> 145</td></tr>
	<tr><td>chr1</td><td>1098196</td><td>1098266</td><td>  70</td></tr>
	<tr><td>chr1</td><td>1099940</td><td>1100122</td><td> 182</td></tr>
	<tr><td>chr1</td><td>1136220</td><td>1137152</td><td> 932</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrY</td><td>13459015</td><td>13459246</td><td> 231</td></tr>
	<tr><td>chrY</td><td>13459509</td><td>13459710</td><td> 201</td></tr>
	<tr><td>chrY</td><td>14532627</td><td>14532736</td><td> 109</td></tr>
	<tr><td>chrY</td><td>14773683</td><td>14776203</td><td>2520</td></tr>
	<tr><td>chrY</td><td>15096889</td><td>15097364</td><td> 475</td></tr>
	<tr><td>chrY</td><td>15159626</td><td>15161325</td><td>1699</td></tr>
	<tr><td>chrY</td><td>15204706</td><td>15206001</td><td>1295</td></tr>
	<tr><td>chrY</td><td>15850566</td><td>15850857</td><td> 291</td></tr>
	<tr><td>chrY</td><td>15862493</td><td>15865433</td><td>2940</td></tr>
	<tr><td>chrY</td><td>15914444</td><td>15916744</td><td>2300</td></tr>
	<tr><td>chrY</td><td>16522205</td><td>16522840</td><td> 635</td></tr>
	<tr><td>chrY</td><td>17349137</td><td>17349373</td><td> 236</td></tr>
	<tr><td>chrY</td><td>17536464</td><td>17536884</td><td> 420</td></tr>
	<tr><td>chrY</td><td>17622039</td><td>17623485</td><td>1446</td></tr>
	<tr><td>chrY</td><td>18248404</td><td>18249077</td><td> 673</td></tr>
	<tr><td>chrY</td><td>19189477</td><td>19189699</td><td> 222</td></tr>
	<tr><td>chrY</td><td>20831726</td><td>20831874</td><td> 148</td></tr>
	<tr><td>chrY</td><td>21154603</td><td>21154667</td><td>  64</td></tr>
	<tr><td>chrY</td><td>21196452</td><td>21197164</td><td> 712</td></tr>
	<tr><td>chrY</td><td>21203891</td><td>21205228</td><td>1337</td></tr>
	<tr><td>chrY</td><td>21237404</td><td>21238201</td><td> 797</td></tr>
	<tr><td>chrY</td><td>21238566</td><td>21238760</td><td> 194</td></tr>
	<tr><td>chrY</td><td>21540547</td><td>21540836</td><td> 289</td></tr>
	<tr><td>chrY</td><td>21589133</td><td>21590467</td><td>1334</td></tr>
	<tr><td>chrY</td><td>21728429</td><td>21730508</td><td>2079</td></tr>
	<tr><td>chrY</td><td>23454052</td><td>23455110</td><td>1058</td></tr>
	<tr><td>chrY</td><td>26921949</td><td>26922256</td><td> 307</td></tr>
	<tr><td>chrY</td><td>58977826</td><td>58979287</td><td>1461</td></tr>
	<tr><td>chrY</td><td>58981952</td><td>58982341</td><td> 389</td></tr>
	<tr><td>chrY</td><td>58987083</td><td>58987887</td><td> 804</td></tr>
</tbody>
</table>



## Create dataframe for plotting accumulation


```R
df_acc <- tibble(
    Celltype = c("H1 ESC", "HSPC", "Macrophage", "B cell"),
    Stage = c("H1ESC","HSPC","Differentiated","Differentiated"),
    Count = c(18235, 46056, 54331, 34070)
)

df_acc$Celltype <- factor(df_acc$Celltype, levels = c("H1 ESC", "HSPC", "Macrophage", "B cell"))
df_acc$Stage <- factor(df_acc$Stage, levels = c("H1ESC","HSPC","Differentiated"))

df_acc
```


<table class="dataframe">
<caption>A tibble: 4 × 3</caption>
<thead>
	<tr><th scope=col>Celltype</th><th scope=col>Stage</th><th scope=col>Count</th></tr>
	<tr><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>H1 ESC    </td><td>H1ESC         </td><td>18235</td></tr>
	<tr><td>HSPC      </td><td>HSPC          </td><td>46056</td></tr>
	<tr><td>Macrophage</td><td>Differentiated</td><td>54331</td></tr>
	<tr><td>B cell    </td><td>Differentiated</td><td>34070</td></tr>
</tbody>
</table>



## Plot


```R
pdf("Accumulation.byStage.plot.pdf")

p_a1 <- ggplot(df_acc, aes(x = Stage, y = Count)) +
    geom_bar(aes(fill = Celltype), stat = "identity", position = position_dodge2(width = 0.9, preserve = "single"), width = .75) +
    theme_classic() +
    theme(aspect.ratio = .5)
p_a1

dev.off()

p_a1
```


<strong>png:</strong> 2



![png](output_11_1.png)



```R
pdf("Accumulation.plot.pdf")

p_a <- ggplot(df_acc, aes(x = Celltype, y = Count)) +
    geom_bar(aes(fill = Celltype), stat = "identity", position = "dodge", width = .5) +
    theme_classic() +
    theme(aspect.ratio = .5)
p_a

dev.off()

p_a
```


<strong>png:</strong> 2



![png](output_12_1.png)


# Persistence

## Get numbers: H1 ESC


```R
HMR_DIR=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/
```


```R
## H1ESC starting
wc -l ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt
```

    18235 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/H1ESC.minsize50.filtforrefseqTSSexons.txt



```R
## H1ESC persist HSPC
bedtools intersect -u -a ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt | wc -l 
```

    11959



```R
## H1ESC persist HSPC - persist Macrophage
bedtools intersect -u -a ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt | bedtools intersect -u -a - -b ${HMR_DIR}Macrophage.minsize50.filtforrefseqTSSexons.txt | wc -l 
```

    11310



```R
## H1ESC persist HSPC - persist B cell 
```


```R
## H1ESC persist HSPC - persist Macrophage
bedtools intersect -u -a ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt | bedtools intersect -u -a - -b ${HMR_DIR}Bcell.minsize50.filtforrefseqTSSexons.txt | wc -l 
```

    10285


## Get numbers: HSPC


```R
HMR_DIR=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/filtRefSeqFiles/
```


```R
## HSPC NOT in H1 ESC
bedtools intersect -v -a ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt | wc -l 
```

    34605



```R
## HSPC NOT in H1 ESC - Persist B cell 
bedtools intersect -v -a ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt | bedtools intersect -u -a - -b ${HMR_DIR}Macrophage.minsize50.filtforrefseqTSSexons.txt | wc -l  
```

    27312



```R
## HSPC NOT in H1 ESC - Persist B cell 
bedtools intersect -v -a ${HMR_DIR}HSC.minsize50.filtforrefseqTSSexons.txt -b ${HMR_DIR}H1ESC.minsize50.filtforrefseqTSSexons.txt | bedtools intersect -u -a - -b ${HMR_DIR}Bcell.minsize50.filtforrefseqTSSexons.txt | wc -l  
```

    15185


## R: Create dataframes


```R
library(tidyverse)
library(ggplot2)

setwd("/data/hodges_lab/Tim/ACCUMULATION_PERSISTENCE/")
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    



```R
H1_persist <- tibble(
    Celltype = c("H1 ESC", "HSPC", "Macrophage", "B cell"),
    Stage = c("H1ESC","HSPC","Differentiated","Differentiated"),
    Count = c(18235, 11959, 11310, 10285)
)

H1_persist$Celltype <- factor(H1_persist$Celltype, levels = c("H1 ESC", "HSPC", "Macrophage", "B cell"))
H1_persist$Stage <- factor(H1_persist$Stage, levels = c("H1ESC","HSPC","Differentiated"))
```


```R
HSPC_persist <- tibble(
    Celltype = c("H1 ESC", "HSPC", "Macrophage", "B cell"),
    Stage = c("H1 ESC", "HSPC","Differentiated","Differentiated"),
    Count = c(0, 34605, 27312, 15185)
)

HSPC_persist$Celltype <- factor(HSPC_persist$Celltype, levels = c("H1 ESC","HSPC", "Macrophage", "B cell"))
HSPC_persist$Stage <- factor(HSPC_persist$Stage, levels = c("H1 ESC","HSPC","Differentiated"))
```

## Plot


```R
pdf("Persistence.H1ESC.pdf")

p_H1persist <- H1_persist %>%
ggplot(aes(x = Stage, y = Count)) +
    geom_bar(aes(fill = Celltype), stat = "identity", position = position_dodge2(width = 0.9, preserve = "single"), width = .75) +
    theme_classic() +
    theme(aspect.ratio = .4) 
p_H1persist

dev.off()
p_H1persist

```


<strong>png:</strong> 2



![png](output_31_1.png)



```R
pdf("Persistence.HSPC.pdf")

p_HSPCpersist <- HSPC_persist %>%
ggplot(aes(x = Stage, y = Count)) +
    geom_bar(aes(fill = Celltype), stat = "identity", position = position_dodge2(width = 0.9, preserve = "single"), width = .75) +
    theme_classic() +
    theme(aspect.ratio = .4) +
    scale_y_reverse() +
    scale_x_discrete(position = "top")
p_HSPCpersist

dev.off()
p_HSPCpersist
```


<strong>png:</strong> 2



![png](output_32_1.png)



```R

```
