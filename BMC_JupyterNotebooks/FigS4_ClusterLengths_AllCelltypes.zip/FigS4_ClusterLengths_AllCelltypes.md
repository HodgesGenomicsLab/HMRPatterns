# Load libraries


```R
library(tidyverse)
library(ggplot2)
```

    ── [1mAttaching packages[22m ─────────────────────────────────────── tidyverse 1.3.1 ──
    
    [32m✔[39m [34mggplot2[39m 3.3.6     [32m✔[39m [34mpurrr  [39m 1.0.1
    [32m✔[39m [34mtibble [39m 3.2.1     [32m✔[39m [34mdplyr  [39m 1.1.1
    [32m✔[39m [34mtidyr  [39m 1.3.0     [32m✔[39m [34mstringr[39m 1.5.0
    [32m✔[39m [34mreadr  [39m 2.1.2     [32m✔[39m [34mforcats[39m 0.5.1
    
    ── [1mConflicts[22m ────────────────────────────────────────── tidyverse_conflicts() ──
    [31m✖[39m [34mdplyr[39m::[32mfilter()[39m masks [34mstats[39m::filter()
    [31m✖[39m [34mdplyr[39m::[32mlag()[39m    masks [34mstats[39m::lag()
    



```R
setwd("/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/")
```

# Load files 


```R
list.files(pattern = "*internalClusters_hpl_BED.txt")
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'Adrenal_internalClusters_hpl_BED.txt'</li><li>'Bcell_internalClusters_hpl_BED.txt'</li><li>'BT_internalClusters_hpl_BED.txt'</li><li>'fHeart_internalClusters_hpl_BED.txt'</li><li>'fSpinal_internalClusters_hpl_BED.txt'</li><li>'H1ESC_internalClusters_hpl_BED.txt'</li><li>'HSC_internalClusters_hpl_BED.txt'</li><li>'Liver_internalClusters_hpl_BED.txt'</li><li>'Macrophage_internalClusters_hpl_BED.txt'</li><li>'MN_internalClusters_hpl_BED.txt'</li><li>'MNBT_internalClusters_hpl_BED.txt'</li><li>'Neutrophil_internalClusters_hpl_BED.txt'</li><li>'Tcell_internalClusters_hpl_BED.txt'</li></ol>




```R
list_of_input <- 
```


```R

```


```R
bed_heads <- c("chr","start", "end")

H1ESC_clusters <- read_tsv("H1ESC_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "H1ESC")

fSpinal_clusters <- read_tsv("fSpinal_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "fSpinal")

fHeart_clusters <- read_tsv("fHeart_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "fHeart")

Adrenal_clusters <- read_tsv("Adrenal_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Adrenal")

Liver_clusters <- read_tsv("Liver_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Liver")

HSPC_clusters <- read_tsv("HSC_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "HSPC")

Macrophage_clusters <- read_tsv("Macrophage_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Macrophage")

Neutrophil_clusters <- read_tsv("Neutrophil_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Neutrophil")

Tcell_clusters <- read_tsv("Tcell_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Tcell")

Bcell_clusters <- read_tsv("Bcell_internalClusters_hpl_BED.txt", col_names = bed_heads) %>% mutate(Length = (end - start), Celltype = "Bcell")


```

    [1mRows: [22m[34m470[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m2120[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m2021[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m1514[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m1639[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m2175[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m3275[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m2723[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m1150[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m1579[39m [1mColumns: [22m[34m3[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (1): chr
    [32mdbl[39m (2): start, end
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.



```R
fHeart_clusters
```


<table class="dataframe">
<caption>A tibble: 2021 × 5</caption>
<thead>
	<tr><th scope=col>chr</th><th scope=col>start</th><th scope=col>end</th><th scope=col>Length</th><th scope=col>Celltype</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 801044</td><td> 808630</td><td> 7586</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td> 839737</td><td> 856881</td><td>17144</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td> 993461</td><td>1005433</td><td>11972</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1012726</td><td>1016433</td><td> 3707</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1072028</td><td>1080069</td><td> 8041</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1092645</td><td>1106068</td><td>13423</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1173336</td><td>1176508</td><td> 3172</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1440368</td><td>1444451</td><td> 4083</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>1976097</td><td>1979262</td><td> 3165</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2055008</td><td>2065242</td><td>10234</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2164204</td><td>2183503</td><td>19299</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2201773</td><td>2211348</td><td> 9575</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2242916</td><td>2247075</td><td> 4159</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2374380</td><td>2383946</td><td> 9566</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2391240</td><td>2395097</td><td> 3857</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2464153</td><td>2485158</td><td>21005</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2595302</td><td>2632891</td><td>37589</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2687151</td><td>2695304</td><td> 8153</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>2991480</td><td>3001055</td><td> 9575</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3017438</td><td>3028534</td><td>11096</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3036211</td><td>3044232</td><td> 8021</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3051879</td><td>3062476</td><td>10597</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3070599</td><td>3079344</td><td> 8745</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3086360</td><td>3091718</td><td> 5358</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3227631</td><td>3246855</td><td>19224</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3262323</td><td>3269774</td><td> 7451</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3276534</td><td>3282944</td><td> 6410</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3456589</td><td>3465059</td><td> 8470</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3530099</td><td>3538023</td><td> 7924</td><td>fHeart</td></tr>
	<tr><td>chr1</td><td>3585301</td><td>3595150</td><td> 9849</td><td>fHeart</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrY</td><td>10033489</td><td>10043077</td><td> 9588</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>10049480</td><td>10083754</td><td>34274</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13126964</td><td>13143672</td><td>16708</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13194170</td><td>13200777</td><td> 6607</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13258137</td><td>13279768</td><td>21631</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13288287</td><td>13299302</td><td>11015</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13369501</td><td>13384722</td><td>15221</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13398764</td><td>13451759</td><td>52995</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13481640</td><td>13489061</td><td> 7421</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13507925</td><td>13552310</td><td>44385</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13559934</td><td>13575952</td><td>16018</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13614766</td><td>13641174</td><td>26408</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13889339</td><td>13903914</td><td>14575</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13936999</td><td>13955161</td><td>18162</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>13969159</td><td>14037546</td><td>68387</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14064467</td><td>14082333</td><td>17866</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14129555</td><td>14146089</td><td>16534</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14156790</td><td>14190751</td><td>33961</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14199922</td><td>14210348</td><td>10426</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14256817</td><td>14265655</td><td> 8838</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14309201</td><td>14336811</td><td>27610</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14532357</td><td>14543694</td><td>11337</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>14772720</td><td>14776041</td><td> 3321</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>22474401</td><td>22512677</td><td>38276</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>23734669</td><td>23742688</td><td> 8019</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>23773086</td><td>23786109</td><td>13023</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>23860137</td><td>23877430</td><td>17293</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>23971615</td><td>23988456</td><td>16841</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>28759176</td><td>28786115</td><td>26939</td><td>fHeart</td></tr>
	<tr><td>chrY</td><td>58968459</td><td>58982549</td><td>14090</td><td>fHeart</td></tr>
</tbody>
</table>




```R
Tcell_clusters
```


<table class="dataframe">
<caption>A tibble: 1150 × 5</caption>
<thead>
	<tr><th scope=col>chr</th><th scope=col>start</th><th scope=col>end</th><th scope=col>Length</th><th scope=col>Celltype</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td>  832618</td><td>  848444</td><td>15826</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>  867144</td><td>  871136</td><td> 3992</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>  993809</td><td> 1005100</td><td>11291</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 1012015</td><td> 1016295</td><td> 4280</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 1072023</td><td> 1080084</td><td> 8061</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2053317</td><td> 2065178</td><td>11861</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2165628</td><td> 2172304</td><td> 6676</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2183435</td><td> 2190860</td><td> 7425</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2243014</td><td> 2250614</td><td> 7600</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2472022</td><td> 2481004</td><td> 8982</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2583319</td><td> 2632561</td><td>49242</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 2684904</td><td> 2690116</td><td> 5212</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 3071940</td><td> 3078076</td><td> 6136</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 3085309</td><td> 3091718</td><td> 6409</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 3134446</td><td> 3142858</td><td> 8412</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 3237207</td><td> 3240234</td><td> 3027</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 3818858</td><td> 3827880</td><td> 9022</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 5890867</td><td> 5897488</td><td> 6621</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 7609352</td><td> 7616234</td><td> 6882</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td> 9251302</td><td> 9263933</td><td>12631</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>10999892</td><td>11004700</td><td> 4808</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>11410286</td><td>11415869</td><td> 5583</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>11954147</td><td>11959224</td><td> 5077</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>12210743</td><td>12222408</td><td>11665</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>12233495</td><td>12239529</td><td> 6034</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>12494183</td><td>12498887</td><td> 4704</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>15738615</td><td>15744453</td><td> 5838</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>16553452</td><td>16554780</td><td> 1328</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>17018683</td><td>17034774</td><td>16091</td><td>Tcell</td></tr>
	<tr><td>chr1</td><td>18919529</td><td>18926365</td><td> 6836</td><td>Tcell</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrX</td><td> 39942289</td><td> 39950079</td><td> 7790</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 40005007</td><td> 40018000</td><td>12993</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 40026864</td><td> 40032276</td><td> 5412</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 40398487</td><td> 40403660</td><td> 5173</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 40974421</td><td> 40979402</td><td> 4981</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 42802217</td><td> 42808432</td><td> 6215</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 45612877</td><td> 45631299</td><td>18422</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 47217944</td><td> 47226102</td><td> 8158</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 47879908</td><td> 47886441</td><td> 6533</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 48794376</td><td> 48799343</td><td> 4967</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 56788815</td><td> 56792333</td><td> 3518</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td> 78394354</td><td> 78423691</td><td>29337</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>106916152</td><td>106920454</td><td> 4302</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>118811315</td><td>118823690</td><td>12375</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>119123601</td><td>119135676</td><td>12075</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>128735139</td><td>128741297</td><td> 6158</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>129086513</td><td>129095934</td><td> 9421</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>129216157</td><td>129232066</td><td>15909</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>130197212</td><td>130208146</td><td>10934</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>135708434</td><td>135718188</td><td> 9754</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>139844123</td><td>139848475</td><td> 4352</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>149738972</td><td>149743954</td><td> 4982</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>152927634</td><td>152935001</td><td> 7367</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>153082160</td><td>153087909</td><td> 5749</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>153187470</td><td>153189333</td><td> 1863</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>153249977</td><td>153255759</td><td> 5782</td><td>Tcell</td></tr>
	<tr><td>chrX</td><td>153570236</td><td>153576296</td><td> 6060</td><td>Tcell</td></tr>
	<tr><td>chrY</td><td>  7140082</td><td>  7151381</td><td>11299</td><td>Tcell</td></tr>
	<tr><td>chrY</td><td> 13427307</td><td> 13436471</td><td> 9164</td><td>Tcell</td></tr>
	<tr><td>chrY</td><td> 13614766</td><td> 13633155</td><td>18389</td><td>Tcell</td></tr>
</tbody>
</table>




```R
df_of_infiles <- rbind(H1ESC_clusters,
                    fSpinal_clusters,
                    fHeart_clusters,
                    Adrenal_clusters,
                    Liver_clusters,
                    HSPC_clusters,
                    Macrophage_clusters,
                    Neutrophil_clusters,
                    Tcell_clusters,
                    Bcell_clusters)
```


```R
df_of_infiles$Celltype <- factor(df_of_infiles$Celltype, 
                                levels = c("H1ESC", "fSpinal", "fHeart", "Adrenal", "Liver",
                                           "HSPC", "Macrophage", "Neutrophil", "Tcell", "Bcell"))
```


```R
unique(df_of_infiles$Celltype)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>H1ESC</li><li>fSpinal</li><li>fHeart</li><li>Adrenal</li><li>Liver</li><li>HSPC</li><li>Macrophage</li><li>Neutrophil</li><li>Tcell</li><li>Bcell</li></ol>

<details>
	<summary style=display:list-item;cursor:pointer>
		<strong>Levels</strong>:
	</summary>
	<style>
	.list-inline {list-style: none; margin:0; padding: 0}
	.list-inline>li {display: inline-block}
	.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
	</style>
	<ol class=list-inline><li>'H1ESC'</li><li>'fSpinal'</li><li>'fHeart'</li><li>'Adrenal'</li><li>'Liver'</li><li>'HSPC'</li><li>'Macrophage'</li><li>'Neutrophil'</li><li>'Tcell'</li><li>'Bcell'</li></ol>
</details>


# Plot


```R
df_of_infiles %>%
    ggplot(aes(x=Celltype, y = Length)) +
        geom_violin() +
        geom_boxplot() +
        theme_minimal() +
        geom_hline(yintercept = 10500, linetype='dashed', size = 1, color = 'red')
```


![png](output_14_0.png)



```R
pdf("/data/hodges_lab/Tim/FigS4_clusterLengths_ggplot.July15.withNeutrophil.pdf")

df_of_infiles %>%
    ggplot(aes(x=Celltype, y = Length)) +
        geom_violin() +
        geom_boxplot() +
        theme_minimal() +
        geom_hline(yintercept = 10000, linetype='dashed', size = 1, color = 'red')

dev.off()
```


<strong>png:</strong> 2


# Stats for average cluster length


```R
mean(df_of_infiles$Length)
median(df_of_infiles$Length)
```


9764.58844958749



8313



```R
# Try a 50,000 length rheshold....
```


```R
df_of_infiles %>% filter(Length < 50000) %>% select(Length) %>% unlist() %>% mean()

df_of_infiles %>% filter(Length < 50000) %>% select(Length) %>% unlist() %>% median()
```


9650.80005041275



8380



```R

```


```R

```


```R

```


```R
df_of_infiles_6 <- df_of_infiles %>% filter(!Celltype %in% c("HSPC","Macrophage","Tcell"))
df_of_infiles_6 %>% select(Length) %>% unlist() %>% mean()
df_of_infiles_6 %>% select(Length) %>% unlist() %>% median()
```


10551.2385743337



8746

