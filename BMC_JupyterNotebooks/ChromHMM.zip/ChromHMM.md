```R
cd /data/hodges_lab/Tim/ChromHMM
```


```R

```


```R
CHMM_FILE=/data/hodges_lab/Tim/ChromHMM/wgEncodeBroadHmmGm12878HMM.bed
B_CLUST=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_hpl.txt
B_UNCLUST=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_hpl.txt
```


```R
ls
```

    wgEncodeBroadHmmGm12878HMM.bed



```R
head wgEncodeBroadHmmGm12878HMM.bed
```

    chr1	67001612	67113812	13_Heterochrom/lo	0	.	67001612	67113812
    chr1	201324577	201326777	12_Repressed	0	.	201324577	201326777
    chr1	8381013	8408813	13_Heterochrom/lo	0	.	8381013	8408813
    chr1	16777013	16777413	5_Strong_Enhancer	0	.	16777013	16777413
    chr1	25162013	25166013	11_Weak_Txn	0	.	25162013	25166013
    chr1	33554013	33554613	6_Weak_Enhancer	0	.	33554013	33554613
    chr1	41942213	41944013	11_Weak_Txn	0	.	41942213	41944013
    chr1	49401813	50512613	13_Heterochrom/lo	0	.	49401813	50512613
    chr1	58717812	58856412	13_Heterochrom/lo	0	.	58717812	58856412
    chr1	75324612	75592212	13_Heterochrom/lo	0	.	75324612	75592212



```R
wc -l wgEncodeBroadHmmGm12878HMM.bed
```

    571339 wgEncodeBroadHmmGm12878HMM.bed



```R
bedtools sort -i wgEncodeBroadHmmGm12878HMM.bed | bedtools merge -i - | wc -l 
```

    1330



```R
awk '{print $4}' wgEncodeBroadHmmGm12878HMM.bed | sort | uniq
```

    10_Txn_Elongation
    11_Weak_Txn
    12_Repressed
    13_Heterochrom/lo
    14_Repetitive/CNV
    15_Repetitive/CNV
    1_Active_Promoter
    2_Weak_Promoter
    3_Poised_Promoter
    4_Strong_Enhancer
    5_Strong_Enhancer
    6_Weak_Enhancer
    7_Weak_Enhancer
    8_Insulator
    9_Txn_Transition



```R
wc -l $B_CLUST
wc -l $B_UNCLUST
```

    5974 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_hpl.txt
    17185 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_hpl.txt



```R
bedtools intersect -wao -a $B_CLUST -b $CHMM_FILE | head
```

    chr1	564470	566009	1539	chr1	564137	570537	14_Repetitive/CNV	0	.	564137	570537	1539
    chr1	566458	566879	421	chr1	564137	570537	14_Repetitive/CNV	0	.	564137	570537	421
    chr1	567166	570301	3135	chr1	564137	570537	14_Repetitive/CNV	0	.	564137	570537	3135
    chr1	832618	833196	578	chr1	826537	834137	12_Repressed	0	.	826537	834137	578
    chr1	833785	834596	811	chr1	826537	834137	12_Repressed	0	.	826537	834137	352
    chr1	833785	834596	811	chr1	834137	834337	3_Poised_Promoter	0	.	834137	834337	200
    chr1	833785	834596	811	chr1	834337	834937	12_Repressed	0	.	834337	834937	259
    chr1	839724	841039	1315	chr1	839737	840137	6_Weak_Enhancer	0	.	839737	840137	400
    chr1	839724	841039	1315	chr1	840137	841137	2_Weak_Promoter	0	.	840137	841137	902
    chr1	839724	841039	1315	chr1	834937	839737	13_Heterochrom/lo	0	.	834937	839737	13


# Dirs and files


```R
CHMM_DIR=/data/hodges_lab/Tim/ChromHMM/
CHMM_FILE=/data/hodges_lab/Tim/ChromHMM/wgEncodeBroadHmmGm12878HMM.bed
B_CLUST=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_hpl.txt
B_UNCLUST=/data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_hpl.txt
```


```R
wc -l $B_CLUST
wc -l $B_UNCLUST
```

    5974 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_hpl.txt
    17185 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_hpl.txt


# Get ChromHMM


```R
cd /data/hodges_lab/Tim/ChromHMM/

wget http://hgdownload.cse.ucsc.edu/goldenpath/hg19/encodeDCC/wgEncodeBroadHmm/wgEncodeBroadHmmGm12878HMM.bed.gz

```

    --2023-07-18 13:26:53--  http://hgdownload.cse.ucsc.edu/goldenpath/hg19/encodeDCC/wgEncodeBroadHmm/wgEncodeBroadHmmGm12878HMM.bed.gz
    Resolving hgdownload.cse.ucsc.edu (hgdownload.cse.ucsc.edu)... 128.114.119.163
    Connecting to hgdownload.cse.ucsc.edu (hgdownload.cse.ucsc.edu)|128.114.119.163|:80... connected.
    HTTP request sent, awaiting response... 200 OK
    Length: 5540331 (5.3M) [application/x-gzip]
    Saving to: ‘wgEncodeBroadHmmGm12878HMM.bed.gz’
    
    100%[======================================>] 5,540,331   4.74MB/s   in 1.1s   
    
    2023-07-18 13:26:55 (4.74 MB/s) - ‘wgEncodeBroadHmmGm12878HMM.bed.gz’ saved [5540331/5540331]
    


## Unzip


```R
gunzip wgEncodeBroadHmmGm12878HMM.bed.gz
```

# Intersect 


```R
## Clustered
```


```R
bedtools intersect -wo -a $B_CLUST -b $CHMM_FILE > ${CHMM_DIR}Bcell_internalClusters_individualHMRs_hpl.ChromHMM.txt
```


```R
## Unclustered
```


```R
bedtools intersect -wo -a $B_UNCLUST -b $CHMM_FILE > ${CHMM_DIR}Bcell_unclustered_hpl.ChromHMM.txt
```

# R: Get values for Enhancers/Hetero/Insulators

## Libraries 


```R
library(tidyverse)
library(ggplot2)

setwd("/data/hodges_lab/Tim/ChromHMM/")
```

## Load files


```R

BCL_CHMM <- read_tsv("Bcell_internalClusters_individualHMRs_hpl.ChromHMM.txt", col_names = c("chrHMR","startHMR","endHMR","lengthHMR","chrChromHMM","startChromHMM","endChromHMM","ChromHMMGroup","value0strand","value1","startChromHMM_rep","endChromHMM_rep","values","value2"))


BUN_CHMM <- read_tsv("Bcell_unclustered_hpl.ChromHMM.txt", col_names = c("chrHMR","startHMR","endHMR","chrChromHMM","startChromHMM","endChromHMM","ChromHMMGroup","value0strand","value1","startChromHMM_rep","endChromHMM_rep","values","value2"))
```

    [1mRows: [22m[34m9266[39m [1mColumns: [22m[34m14[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (5): chrHMR, chrChromHMM, ChromHMMGroup, value1, values
    [32mdbl[39m (9): startHMR, endHMR, lengthHMR, startChromHMM, endChromHMM, value0stra...
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.
    [1mRows: [22m[34m27320[39m [1mColumns: [22m[34m13[39m
    [36m──[39m [1mColumn specification[22m [36m────────────────────────────────────────────────────────[39m
    [1mDelimiter:[22m "\t"
    [31mchr[39m (5): chrHMR, chrChromHMM, ChromHMMGroup, value1, values
    [32mdbl[39m (8): startHMR, endHMR, startChromHMM, endChromHMM, value0strand, startCh...
    
    [36mℹ[39m Use `spec()` to retrieve the full column specification for this data.
    [36mℹ[39m Specify the column types or set `show_col_types = FALSE` to quiet this message.


## Find #HMRs per group


```R
unique(BCL_CHMM$ChromHMMGroup)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>'14_Repetitive/CNV'</li><li>'12_Repressed'</li><li>'3_Poised_Promoter'</li><li>'6_Weak_Enhancer'</li><li>'2_Weak_Promoter'</li><li>'13_Heterochrom/lo'</li><li>'7_Weak_Enhancer'</li><li>'4_Strong_Enhancer'</li><li>'11_Weak_Txn'</li><li>'1_Active_Promoter'</li><li>'5_Strong_Enhancer'</li><li>'8_Insulator'</li><li>'9_Txn_Transition'</li><li>'15_Repetitive/CNV'</li><li>'10_Txn_Elongation'</li></ol>




```R
# 5974 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_internalClusters_individualHMRs_hpl.txt
# 17185 /data/hodges_lab/Tim/finalAnalyses_HMRs/hp_lineage/HMRs/Bcell_unclustered_hpl.txt
```

### Strong Enhancers


```R
BCL_CHMM_StrongEnh <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("4_Strong_Enhancer", "5_Strong_Enhancer")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_StrongEnh <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("4_Strong_Enhancer", "5_Strong_Enhancer")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_StrongEnh
BUN_CHMM_StrongEnh
```


1824



3334


### Weak Enhancers


```R
BCL_CHMM_WeakEnh <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("6_Weak_Enhancer", "7_Weak_Enhancer")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_WeakEnh <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("6_Weak_Enhancer", "7_Weak_Enhancer")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_WeakEnh
BUN_CHMM_WeakEnh
```


1410



4261


### Heterochromatin


```R
BCL_CHMM %>%
filter(ChromHMMGroup %in% c("13_Heterochrom/lo"))
```


<table class="dataframe">
<caption>A spec_tbl_df: 1255 × 14</caption>
<thead>
	<tr><th scope=col>chrHMR</th><th scope=col>startHMR</th><th scope=col>endHMR</th><th scope=col>lengthHMR</th><th scope=col>chrChromHMM</th><th scope=col>startChromHMM</th><th scope=col>endChromHMM</th><th scope=col>ChromHMMGroup</th><th scope=col>value0strand</th><th scope=col>value1</th><th scope=col>startChromHMM_rep</th><th scope=col>endChromHMM_rep</th><th scope=col>values</th><th scope=col>value2</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>chr1</td><td> 839724</td><td> 841039</td><td>1315</td><td>chr1</td><td> 834937</td><td> 839737</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td> 834937</td><td> 839737</td><td>245,245,245</td><td> 13</td></tr>
	<tr><td>chr1</td><td>1071770</td><td>1073219</td><td>1449</td><td>chr1</td><td>1058137</td><td>1071937</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1058137</td><td>1071937</td><td>245,245,245</td><td>167</td></tr>
	<tr><td>chr1</td><td>1092645</td><td>1093973</td><td>1328</td><td>chr1</td><td>1082337</td><td>1092937</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1082337</td><td>1092937</td><td>245,245,245</td><td>292</td></tr>
	<tr><td>chr1</td><td>1099552</td><td>1099651</td><td>  99</td><td>chr1</td><td>1094537</td><td>1101737</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1094537</td><td>1101737</td><td>245,245,245</td><td> 99</td></tr>
	<tr><td>chr1</td><td>1101641</td><td>1101896</td><td> 255</td><td>chr1</td><td>1094537</td><td>1101737</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1094537</td><td>1101737</td><td>245,245,245</td><td> 96</td></tr>
	<tr><td>chr1</td><td>1830655</td><td>1831404</td><td> 749</td><td>chr1</td><td>1831340</td><td>1837540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1831340</td><td>1837540</td><td>245,245,245</td><td> 64</td></tr>
	<tr><td>chr1</td><td>1833498</td><td>1833790</td><td> 292</td><td>chr1</td><td>1831340</td><td>1837540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>1831340</td><td>1837540</td><td>245,245,245</td><td>292</td></tr>
	<tr><td>chr1</td><td>2058380</td><td>2059042</td><td> 662</td><td>chr1</td><td>2058740</td><td>2063740</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2058740</td><td>2063740</td><td>245,245,245</td><td>302</td></tr>
	<tr><td>chr1</td><td>2581963</td><td>2582660</td><td> 697</td><td>chr1</td><td>2574940</td><td>2583540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2574940</td><td>2583540</td><td>245,245,245</td><td>697</td></tr>
	<tr><td>chr1</td><td>2583319</td><td>2584253</td><td> 934</td><td>chr1</td><td>2574940</td><td>2583540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2574940</td><td>2583540</td><td>245,245,245</td><td>221</td></tr>
	<tr><td>chr1</td><td>2631802</td><td>2634084</td><td>2282</td><td>chr1</td><td>2633740</td><td>2634140</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2633740</td><td>2634140</td><td>245,245,245</td><td>344</td></tr>
	<tr><td>chr1</td><td>3071819</td><td>3072326</td><td> 507</td><td>chr1</td><td>2991140</td><td>3097740</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2991140</td><td>3097740</td><td>245,245,245</td><td>507</td></tr>
	<tr><td>chr1</td><td>3073307</td><td>3073496</td><td> 189</td><td>chr1</td><td>2991140</td><td>3097740</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2991140</td><td>3097740</td><td>245,245,245</td><td>189</td></tr>
	<tr><td>chr1</td><td>3077478</td><td>3078076</td><td> 598</td><td>chr1</td><td>2991140</td><td>3097740</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>2991140</td><td>3097740</td><td>245,245,245</td><td>598</td></tr>
	<tr><td>chr1</td><td>3098599</td><td>3098867</td><td> 268</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>268</td></tr>
	<tr><td>chr1</td><td>3099970</td><td>3100669</td><td> 699</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>699</td></tr>
	<tr><td>chr1</td><td>3100945</td><td>3101018</td><td>  73</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td> 73</td></tr>
	<tr><td>chr1</td><td>3132181</td><td>3132355</td><td> 174</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>174</td></tr>
	<tr><td>chr1</td><td>3134446</td><td>3134745</td><td> 299</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>299</td></tr>
	<tr><td>chr1</td><td>3138554</td><td>3139286</td><td> 732</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>732</td></tr>
	<tr><td>chr1</td><td>3164029</td><td>3164172</td><td> 143</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>143</td></tr>
	<tr><td>chr1</td><td>3164251</td><td>3164526</td><td> 275</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>275</td></tr>
	<tr><td>chr1</td><td>3164571</td><td>3165028</td><td> 457</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>457</td></tr>
	<tr><td>chr1</td><td>3167772</td><td>3167896</td><td> 124</td><td>chr1</td><td>3098540</td><td>3223540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3098540</td><td>3223540</td><td>245,245,245</td><td>124</td></tr>
	<tr><td>chr1</td><td>3237207</td><td>3237801</td><td> 594</td><td>chr1</td><td>3237140</td><td>3306540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3237140</td><td>3306540</td><td>245,245,245</td><td>594</td></tr>
	<tr><td>chr1</td><td>3238767</td><td>3239045</td><td> 278</td><td>chr1</td><td>3237140</td><td>3306540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3237140</td><td>3306540</td><td>245,245,245</td><td>278</td></tr>
	<tr><td>chr1</td><td>3240054</td><td>3240366</td><td> 312</td><td>chr1</td><td>3237140</td><td>3306540</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3237140</td><td>3306540</td><td>245,245,245</td><td>312</td></tr>
	<tr><td>chr1</td><td>3513491</td><td>3513613</td><td> 122</td><td>chr1</td><td>3482340</td><td>3513740</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3482340</td><td>3513740</td><td>245,245,245</td><td>122</td></tr>
	<tr><td>chr1</td><td>3535639</td><td>3536327</td><td> 688</td><td>chr1</td><td>3535940</td><td>3537340</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>3535940</td><td>3537340</td><td>245,245,245</td><td>387</td></tr>
	<tr><td>chr1</td><td>5563453</td><td>5563990</td><td> 537</td><td>chr1</td><td>5462813</td><td>5569813</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>5462813</td><td>5569813</td><td>245,245,245</td><td>537</td></tr>
	<tr><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td><td>⋮</td></tr>
	<tr><td>chrX</td><td>124339910</td><td>124340241</td><td> 331</td><td>chrX</td><td>124338319</td><td>124458319</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>124338319</td><td>124458319</td><td>245,245,245</td><td> 331</td></tr>
	<tr><td>chrX</td><td>129067331</td><td>129067427</td><td>  96</td><td>chrX</td><td>129067119</td><td>129086319</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>129067119</td><td>129086319</td><td>245,245,245</td><td>  96</td></tr>
	<tr><td>chrX</td><td>130201483</td><td>130201972</td><td> 489</td><td>chrX</td><td>130129119</td><td>130201519</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>130129119</td><td>130201519</td><td>245,245,245</td><td>  36</td></tr>
	<tr><td>chrX</td><td>130206830</td><td>130207146</td><td> 316</td><td>chrX</td><td>130205319</td><td>130396719</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>130205319</td><td>130396719</td><td>245,245,245</td><td> 316</td></tr>
	<tr><td>chrX</td><td>130207281</td><td>130207434</td><td> 153</td><td>chrX</td><td>130205319</td><td>130396719</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>130205319</td><td>130396719</td><td>245,245,245</td><td> 153</td></tr>
	<tr><td>chrX</td><td>133305778</td><td>133306010</td><td> 232</td><td>chrX</td><td>133295734</td><td>133305934</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>133295734</td><td>133305934</td><td>245,245,245</td><td> 156</td></tr>
	<tr><td>chrX</td><td>133678626</td><td>133678758</td><td> 132</td><td>chrX</td><td>133663334</td><td>133682134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>133663334</td><td>133682134</td><td>245,245,245</td><td> 132</td></tr>
	<tr><td>chrX</td><td>133678990</td><td>133679247</td><td> 257</td><td>chrX</td><td>133663334</td><td>133682134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>133663334</td><td>133682134</td><td>245,245,245</td><td> 257</td></tr>
	<tr><td>chrX</td><td>136505583</td><td>136507290</td><td>1707</td><td>chrX</td><td>136376334</td><td>136506934</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136376334</td><td>136506934</td><td>245,245,245</td><td>1351</td></tr>
	<tr><td>chrX</td><td>136512106</td><td>136512544</td><td> 438</td><td>chrX</td><td>136512534</td><td>136514734</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136512534</td><td>136514734</td><td>245,245,245</td><td>  10</td></tr>
	<tr><td>chrX</td><td>136627385</td><td>136627760</td><td> 375</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td> 375</td></tr>
	<tr><td>chrX</td><td>136628420</td><td>136629516</td><td>1096</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td>1096</td></tr>
	<tr><td>chrX</td><td>136629596</td><td>136630060</td><td> 464</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td> 464</td></tr>
	<tr><td>chrX</td><td>136630532</td><td>136631024</td><td> 492</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td> 492</td></tr>
	<tr><td>chrX</td><td>136631194</td><td>136632195</td><td>1001</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td>1001</td></tr>
	<tr><td>chrX</td><td>136632269</td><td>136632332</td><td>  63</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td>  63</td></tr>
	<tr><td>chrX</td><td>136632602</td><td>136632966</td><td> 364</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td> 364</td></tr>
	<tr><td>chrX</td><td>136633027</td><td>136633212</td><td> 185</td><td>chrX</td><td>136520734</td><td>136646134</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136520734</td><td>136646134</td><td>245,245,245</td><td> 185</td></tr>
	<tr><td>chrX</td><td>136655808</td><td>136655952</td><td> 144</td><td>chrX</td><td>136655734</td><td>137108334</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136655734</td><td>137108334</td><td>245,245,245</td><td> 144</td></tr>
	<tr><td>chrX</td><td>136656500</td><td>136656738</td><td> 238</td><td>chrX</td><td>136655734</td><td>137108334</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136655734</td><td>137108334</td><td>245,245,245</td><td> 238</td></tr>
	<tr><td>chrX</td><td>136656845</td><td>136657217</td><td> 372</td><td>chrX</td><td>136655734</td><td>137108334</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>136655734</td><td>137108334</td><td>245,245,245</td><td> 372</td></tr>
	<tr><td>chrX</td><td>139591214</td><td>139591557</td><td> 343</td><td>chrX</td><td>139262134</td><td>139654734</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>139262134</td><td>139654734</td><td>245,245,245</td><td> 343</td></tr>
	<tr><td>chrX</td><td>139591829</td><td>139592351</td><td> 522</td><td>chrX</td><td>139262134</td><td>139654734</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>139262134</td><td>139654734</td><td>245,245,245</td><td> 522</td></tr>
	<tr><td>chrX</td><td>139593213</td><td>139593353</td><td> 140</td><td>chrX</td><td>139262134</td><td>139654734</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>139262134</td><td>139654734</td><td>245,245,245</td><td> 140</td></tr>
	<tr><td>chrX</td><td>149533850</td><td>149535108</td><td>1258</td><td>chrX</td><td>149534342</td><td>149550942</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>149534342</td><td>149550942</td><td>245,245,245</td><td> 766</td></tr>
	<tr><td>chrX</td><td>152194910</td><td>152195174</td><td> 264</td><td>chrX</td><td>152158344</td><td>152200344</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>152158344</td><td>152200344</td><td>245,245,245</td><td> 264</td></tr>
	<tr><td>chrX</td><td>152782897</td><td>152782978</td><td>  81</td><td>chrX</td><td>152773606</td><td>152804806</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>152773606</td><td>152804806</td><td>245,245,245</td><td>  81</td></tr>
	<tr><td>chrX</td><td>152783358</td><td>152783467</td><td> 109</td><td>chrX</td><td>152773606</td><td>152804806</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>152773606</td><td>152804806</td><td>245,245,245</td><td> 109</td></tr>
	<tr><td>chrX</td><td>152783637</td><td>152783965</td><td> 328</td><td>chrX</td><td>152773606</td><td>152804806</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>152773606</td><td>152804806</td><td>245,245,245</td><td> 328</td></tr>
	<tr><td>chrX</td><td>152928011</td><td>152928319</td><td> 308</td><td>chrX</td><td>152928006</td><td>152933206</td><td>13_Heterochrom/lo</td><td>0</td><td>.</td><td>152928006</td><td>152933206</td><td>245,245,245</td><td> 308</td></tr>
</tbody>
</table>




```R
BCL_CHMM_Hetero <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("13_Heterochrom/lo")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_Hetero <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("13_Heterochrom/lo")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_Hetero
BUN_CHMM_Hetero
```


1227



6017


### Repressed


```R
BCL_CHMM_Repr <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("12_Repressed")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_Repr <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("12_Repressed")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_Repr
BUN_CHMM_Repr
```


920



1584


### Insulators


```R
BCL_CHMM_Ins <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("8_Insulator")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_Ins <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("8_Insulator")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_Ins
BUN_CHMM_Ins
```


574



3424


### Weak Transcription


```R
BCL_CHMM_WeakTx <- BCL_CHMM %>%
filter(ChromHMMGroup %in% c("11_Weak_Txn")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BUN_CHMM_WeakTx <- BUN_CHMM %>%
filter(ChromHMMGroup %in% c("11_Weak_Txn")) %>% 
group_by(chrHMR, startHMR, endHMR) %>% top_n(n = 1, wt = startChromHMM) %>% nrow()

BCL_CHMM_WeakTx
BUN_CHMM_WeakTx
```


400



817


# Plot

## Generate data frame


```R
df_val <- tibble(
    HMRGroup = c(rep("B cell Clustered", 6), rep("B cell Unclustered", 6)),
    ChromHMM = rep(c("StrongEnhancer","WeakEnhancer","Heterochromatin","Repressed","Insulator","WeakTx"), 2),
    TotalHMRs = c(rep(5974, 6), rep(17185, 6))
)

df_val
```


<table class="dataframe">
<caption>A tibble: 12 × 3</caption>
<thead>
	<tr><th scope=col>HMRGroup</th><th scope=col>ChromHMM</th><th scope=col>TotalHMRs</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>B cell Clustered  </td><td>StrongEnhancer </td><td> 5974</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakEnhancer   </td><td> 5974</td></tr>
	<tr><td>B cell Clustered  </td><td>Heterochromatin</td><td> 5974</td></tr>
	<tr><td>B cell Clustered  </td><td>Repressed      </td><td> 5974</td></tr>
	<tr><td>B cell Clustered  </td><td>Insulator      </td><td> 5974</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakTx         </td><td> 5974</td></tr>
	<tr><td>B cell Unclustered</td><td>StrongEnhancer </td><td>17185</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakEnhancer   </td><td>17185</td></tr>
	<tr><td>B cell Unclustered</td><td>Heterochromatin</td><td>17185</td></tr>
	<tr><td>B cell Unclustered</td><td>Repressed      </td><td>17185</td></tr>
	<tr><td>B cell Unclustered</td><td>Insulator      </td><td>17185</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakTx         </td><td>17185</td></tr>
</tbody>
</table>




```R
df_val <- tibble(
    HMRGroup = c(rep("B cell Clustered", 6), rep("B cell Unclustered", 6)),
    ChromHMM = rep(c("StrongEnhancer","WeakEnhancer","Heterochromatin","Repressed","Insulator","WeakTx"), 2),
    TotalHMRs = c(rep(5974, 6), rep(17185, 6)),
    numHMRs = c(BCL_CHMM_StrongEnh, BCL_CHMM_WeakEnh, BCL_CHMM_Hetero, BCL_CHMM_Repr, BCL_CHMM_Ins, BCL_CHMM_WeakTx,
              BUN_CHMM_StrongEnh, BUN_CHMM_WeakEnh, BUN_CHMM_Hetero, BUN_CHMM_Repr, BUN_CHMM_Ins, BUN_CHMM_WeakTx)
)

df_val
```


<table class="dataframe">
<caption>A tibble: 12 × 4</caption>
<thead>
	<tr><th scope=col>HMRGroup</th><th scope=col>ChromHMM</th><th scope=col>TotalHMRs</th><th scope=col>numHMRs</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td>B cell Clustered  </td><td>StrongEnhancer </td><td> 5974</td><td>1824</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakEnhancer   </td><td> 5974</td><td>1410</td></tr>
	<tr><td>B cell Clustered  </td><td>Heterochromatin</td><td> 5974</td><td>1227</td></tr>
	<tr><td>B cell Clustered  </td><td>Repressed      </td><td> 5974</td><td> 920</td></tr>
	<tr><td>B cell Clustered  </td><td>Insulator      </td><td> 5974</td><td> 574</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakTx         </td><td> 5974</td><td> 400</td></tr>
	<tr><td>B cell Unclustered</td><td>StrongEnhancer </td><td>17185</td><td>3334</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakEnhancer   </td><td>17185</td><td>4261</td></tr>
	<tr><td>B cell Unclustered</td><td>Heterochromatin</td><td>17185</td><td>6017</td></tr>
	<tr><td>B cell Unclustered</td><td>Repressed      </td><td>17185</td><td>1584</td></tr>
	<tr><td>B cell Unclustered</td><td>Insulator      </td><td>17185</td><td>3424</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakTx         </td><td>17185</td><td> 817</td></tr>
</tbody>
</table>



## Calculate fraction


```R
df_frac <- df_val %>% mutate(ProportionHMRs = (numHMRs/TotalHMRs))
df_frac
```


<table class="dataframe">
<caption>A tibble: 12 × 5</caption>
<thead>
	<tr><th scope=col>HMRGroup</th><th scope=col>ChromHMM</th><th scope=col>TotalHMRs</th><th scope=col>numHMRs</th><th scope=col>ProportionHMRs</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>B cell Clustered  </td><td>StrongEnhancer </td><td> 5974</td><td>1824</td><td>0.30532307</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakEnhancer   </td><td> 5974</td><td>1410</td><td>0.23602277</td></tr>
	<tr><td>B cell Clustered  </td><td>Heterochromatin</td><td> 5974</td><td>1227</td><td>0.20539002</td></tr>
	<tr><td>B cell Clustered  </td><td>Repressed      </td><td> 5974</td><td> 920</td><td>0.15400067</td></tr>
	<tr><td>B cell Clustered  </td><td>Insulator      </td><td> 5974</td><td> 574</td><td>0.09608303</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakTx         </td><td> 5974</td><td> 400</td><td>0.06695681</td></tr>
	<tr><td>B cell Unclustered</td><td>StrongEnhancer </td><td>17185</td><td>3334</td><td>0.19400640</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakEnhancer   </td><td>17185</td><td>4261</td><td>0.24794879</td></tr>
	<tr><td>B cell Unclustered</td><td>Heterochromatin</td><td>17185</td><td>6017</td><td>0.35013093</td></tr>
	<tr><td>B cell Unclustered</td><td>Repressed      </td><td>17185</td><td>1584</td><td>0.09217341</td></tr>
	<tr><td>B cell Unclustered</td><td>Insulator      </td><td>17185</td><td>3424</td><td>0.19924353</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakTx         </td><td>17185</td><td> 817</td><td>0.04754146</td></tr>
</tbody>
</table>



## Order factor


```R
df_frac$ChromHMM <- factor(df_frac$ChromHMM, levels = 
                          c("StrongEnhancer", "WeakEnhancer", "Heterochromatin", "Repressed", "Insulator", "WeakTx"))
```

## Plot call


```R
df_frac %>%
ggplot(aes(x = ChromHMM, y = ProportionHMRs)) +
geom_bar(aes(fill = HMRGroup), width = .7, stat = "identity",  position = position_dodge(width=.8)) +
theme_minimal() +
theme(aspect.ratio = .5)
```


![png](output_52_0.png)


## Stats DF 


```R
df_frac
```


<table class="dataframe">
<caption>A tibble: 12 × 5</caption>
<thead>
	<tr><th scope=col>HMRGroup</th><th scope=col>ChromHMM</th><th scope=col>TotalHMRs</th><th scope=col>numHMRs</th><th scope=col>ProportionHMRs</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>B cell Clustered  </td><td>StrongEnhancer </td><td> 5974</td><td>1824</td><td>0.30532307</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakEnhancer   </td><td> 5974</td><td>1410</td><td>0.23602277</td></tr>
	<tr><td>B cell Clustered  </td><td>Heterochromatin</td><td> 5974</td><td>1227</td><td>0.20539002</td></tr>
	<tr><td>B cell Clustered  </td><td>Repressed      </td><td> 5974</td><td> 920</td><td>0.15400067</td></tr>
	<tr><td>B cell Clustered  </td><td>Insulator      </td><td> 5974</td><td> 574</td><td>0.09608303</td></tr>
	<tr><td>B cell Clustered  </td><td>WeakTx         </td><td> 5974</td><td> 400</td><td>0.06695681</td></tr>
	<tr><td>B cell Unclustered</td><td>StrongEnhancer </td><td>17185</td><td>3334</td><td>0.19400640</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakEnhancer   </td><td>17185</td><td>4261</td><td>0.24794879</td></tr>
	<tr><td>B cell Unclustered</td><td>Heterochromatin</td><td>17185</td><td>6017</td><td>0.35013093</td></tr>
	<tr><td>B cell Unclustered</td><td>Repressed      </td><td>17185</td><td>1584</td><td>0.09217341</td></tr>
	<tr><td>B cell Unclustered</td><td>Insulator      </td><td>17185</td><td>3424</td><td>0.19924353</td></tr>
	<tr><td>B cell Unclustered</td><td>WeakTx         </td><td>17185</td><td> 817</td><td>0.04754146</td></tr>
</tbody>
</table>




```R
df_frac_cl <- df_frac[1:6,]
df_frac_un <- df_frac[7:12,]
df_frac_wide <- merge(df_frac_cl, df_frac_un, by = "ChromHMM")
df_frac_wide
```


<table class="dataframe">
<caption>A data.frame: 6 × 9</caption>
<thead>
	<tr><th scope=col>ChromHMM</th><th scope=col>HMRGroup.x</th><th scope=col>TotalHMRs.x</th><th scope=col>numHMRs.x</th><th scope=col>ProportionHMRs.x</th><th scope=col>HMRGroup.y</th><th scope=col>TotalHMRs.y</th><th scope=col>numHMRs.y</th><th scope=col>ProportionHMRs.y</th></tr>
	<tr><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>Heterochromatin</td><td>B cell Clustered</td><td>5974</td><td>1227</td><td>0.20539002</td><td>B cell Unclustered</td><td>17185</td><td>6017</td><td>0.35013093</td></tr>
	<tr><td>Insulator      </td><td>B cell Clustered</td><td>5974</td><td> 574</td><td>0.09608303</td><td>B cell Unclustered</td><td>17185</td><td>3424</td><td>0.19924353</td></tr>
	<tr><td>Repressed      </td><td>B cell Clustered</td><td>5974</td><td> 920</td><td>0.15400067</td><td>B cell Unclustered</td><td>17185</td><td>1584</td><td>0.09217341</td></tr>
	<tr><td>StrongEnhancer </td><td>B cell Clustered</td><td>5974</td><td>1824</td><td>0.30532307</td><td>B cell Unclustered</td><td>17185</td><td>3334</td><td>0.19400640</td></tr>
	<tr><td>WeakEnhancer   </td><td>B cell Clustered</td><td>5974</td><td>1410</td><td>0.23602277</td><td>B cell Unclustered</td><td>17185</td><td>4261</td><td>0.24794879</td></tr>
	<tr><td>WeakTx         </td><td>B cell Clustered</td><td>5974</td><td> 400</td><td>0.06695681</td><td>B cell Unclustered</td><td>17185</td><td> 817</td><td>0.04754146</td></tr>
</tbody>
</table>




```R
# Cl vs. UnLoose
df_frac_stats <- df_frac_wide %>% rowwise() %>% mutate(
    propTestP = prop.test(x = c(numHMRs.x, numHMRs.y), n = c(5974, 17185))$p.value,
    propTestStat = prop.test(x = c(numHMRs.x, numHMRs.y), n = c(5974, 17185))$statistic,
)
df_frac_stats
```


<table class="dataframe">
<caption>A rowwise_df: 6 × 11</caption>
<thead>
	<tr><th scope=col>ChromHMM</th><th scope=col>HMRGroup.x</th><th scope=col>TotalHMRs.x</th><th scope=col>numHMRs.x</th><th scope=col>ProportionHMRs.x</th><th scope=col>HMRGroup.y</th><th scope=col>TotalHMRs.y</th><th scope=col>numHMRs.y</th><th scope=col>ProportionHMRs.y</th><th scope=col>propTestP</th><th scope=col>propTestStat</th></tr>
	<tr><th scope=col>&lt;fct&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th><th scope=col>&lt;dbl&gt;</th></tr>
</thead>
<tbody>
	<tr><td>Heterochromatin</td><td>B cell Clustered</td><td>5974</td><td>1227</td><td>0.20539002</td><td>B cell Unclustered</td><td>17185</td><td>6017</td><td>0.35013093</td><td>8.158921e-96</td><td>431.374944</td></tr>
	<tr><td>Insulator      </td><td>B cell Clustered</td><td>5974</td><td> 574</td><td>0.09608303</td><td>B cell Unclustered</td><td>17185</td><td>3424</td><td>0.19924353</td><td>1.191274e-73</td><td>329.571976</td></tr>
	<tr><td>Repressed      </td><td>B cell Clustered</td><td>5974</td><td> 920</td><td>0.15400067</td><td>B cell Unclustered</td><td>17185</td><td>1584</td><td>0.09217341</td><td>5.736333e-40</td><td>175.085048</td></tr>
	<tr><td>StrongEnhancer </td><td>B cell Clustered</td><td>5974</td><td>1824</td><td>0.30532307</td><td>B cell Unclustered</td><td>17185</td><td>3334</td><td>0.19400640</td><td>7.725492e-71</td><td>316.662347</td></tr>
	<tr><td>WeakEnhancer   </td><td>B cell Clustered</td><td>5974</td><td>1410</td><td>0.23602277</td><td>B cell Unclustered</td><td>17185</td><td>4261</td><td>0.24794879</td><td>6.738538e-02</td><td>  3.345589</td></tr>
	<tr><td>WeakTx         </td><td>B cell Clustered</td><td>5974</td><td> 400</td><td>0.06695681</td><td>B cell Unclustered</td><td>17185</td><td> 817</td><td>0.04754146</td><td>8.427047e-09</td><td> 33.173985</td></tr>
</tbody>
</table>




```R
prop.test(c(400, 817), c(5974, 17185))
```


    
    	2-sample test for equality of proportions with continuity correction
    
    data:  c(400, 817) out of c(5974, 17185)
    X-squared = 33.174, df = 1, p-value = 8.427e-09
    alternative hypothesis: two.sided
    95 percent confidence interval:
     0.01221071 0.02661999
    sample estimates:
        prop 1     prop 2 
    0.06695681 0.04754146 




```R
# Hand check
# Strong Enh
prop.test(c(1824, 3334), c(5974, 17185))

# Repressed
prop.test(c(920, 1584), c(5974, 17185))
```


    
    	2-sample test for equality of proportions with continuity correction
    
    data:  c(1824, 3334) out of c(5974, 17185)
    X-squared = 316.66, df = 1, p-value < 2.2e-16
    alternative hypothesis: two.sided
    95 percent confidence interval:
     0.09811415 0.12451918
    sample estimates:
       prop 1    prop 2 
    0.3053231 0.1940064 




    
    	2-sample test for equality of proportions with continuity correction
    
    data:  c(920, 1584) out of c(5974, 17185)
    X-squared = 175.09, df = 1, p-value < 2.2e-16
    alternative hypothesis: two.sided
    95 percent confidence interval:
     0.05159115 0.07206338
    sample estimates:
        prop 1     prop 2 
    0.15400067 0.09217341 



## Plot with stats


```R
p_chrom_stats <- df_frac %>%
ggplot(aes(x = ChromHMM, y = ProportionHMRs)) +
geom_bar(aes(fill = HMRGroup), width = .7, stat = "identity",  position = position_dodge(width=.8)) +
theme_minimal() +
theme(aspect.ratio = .5) +
scale_fill_manual(values=c("#B0DAB6", "#3990C0")) +
geom_text(data = df_frac_stats, aes(x = ChromHMM, y = .4, label = format(propTestP, digits=3)))


p_chrom_stats
```


![png](output_60_0.png)



```R
pdf("/data/hodges_lab/Tim/ChromHMM.withStats.pdf")

p_chrom_stats

dev.off()
```


<strong>png:</strong> 2



```R

```


```R

```


```R

```


```R

```
